/**
 * Created by wangyuanzhi on 16/3/23.
 */
(function() {
  'use strict';
  angular.module('passengerApp')
    .service('TripFeedbackService', function(HttpService) {
      var self = this;

      self.feedback = function(params,successHandle,faultHandle){
        HttpService.post(Api.feedback,params,successHandle,faultHandle);
      }
    });
})();
