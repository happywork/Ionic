ApiServer = {
    serverUrl: "https://test.api.karldash.com",
    version: "/1",
    learnmoreUrl:"http://test.karl.limo",
    flowUrl:"http://test.karldash.com",
    timeout:120000,
    env:"tst",
    stripeClientId : 'ca_An6OlgDObyhhW7csaDsTsmzfUiyTEmEN',
    repSalesId: 'EASYSIGNUP'
};
