(function () {
  'use strict';
  angular.module('starter')
    .service('MapService', function ($ionicLoading, $cordovaGeolocation, $http) {

      //initiating Service inside here its self
      var self = this;

      self.calculateAndDisplayRoute = function (map, directionsService, directionsDisplay, startLatLng, endLatLng) {
        directionsDisplay.setMap(map);
        directionsService.route({
          origin: startLatLng,
          destination: endLatLng,
          travelMode: google.maps.TravelMode.DRIVING
        }, function (response, status) {
          if (status === google.maps.DirectionsStatus.OK) {
            directionsDisplay.setDirections(response);
          } else {
            console.log('Directions request failed due to ' + status);
          }
        });
      };

      self.calculateAndDrawPolyline = function(map,directionsService,wayPoints,startLatLng,endLatLng) {
        directionsService.route({
          origin: startLatLng,
          destination: endLatLng,
          travelMode: google.maps.TravelMode.DRIVING,
          waypoints:wayPoints
        }, function(response, status) {
          if (status === google.maps.DirectionsStatus.OK) {
            console.log(response);
            var flightPath = new google.maps.Polyline({
              path: response.routes[0].overview_path,
              geodesic: true,
              strokeColor: 'green',
              strokeOpacity: 1.0,
              strokeWeight: 5
            });
            flightPath.setMap(map);
          }else {
            console.log('Directions request failed due to ' + status);
          }
        });
      };

      self.hideRoute = function () {
        directionsDisplay.setOptions({hideRouteList: true});
      };

      self.geocodeLatLng = function (latlng, successHandle, faultHandle) {
        var geocoder = new google.maps.Geocoder;
        geocoder.geocode({'location': latlng}, function (results, status) {
          if (status === google.maps.GeocoderStatus.OK) {
            if (results[0]) {
              var location = results[0];
              location.geometry.location = {
                lat:location.geometry.location.lat(),
                lng:location.geometry.location.lng()
              };
              successHandle(location);
            } else {
              faultHandle('No results found');
            }
          } else {
            faultHandle('Geocoder failed due to: ' + status);
          }
        });
      };

      self.getMapDistanceWithWaypoints = function (startLatlng, endLatlng, wayPoints, successHandle, faultHandle) {
        // console.log("====");
        // console.log(startLatlng);
        // console.log(endLatlng);
        // console.log(wayPoints);
        // console.log("====");

        var directionsService = new google.maps.DirectionsService;
        directionsService.route({
          origin: startLatlng,
          destination: endLatlng,
          travelMode: google.maps.TravelMode.DRIVING,
          waypoints:wayPoints
        }, function (response, status) {
          if (status === google.maps.DirectionsStatus.OK) {
            successHandle(response.routes[0].legs[0].distance.value);
          } else {
            faultHandle('Directions request failed due to ' + status);
          }
        });

      };

      //Computing distance and duration between startPoint and endPoint by "DRIVING" model
      self.getMapMatrixDistance = function (startLatlng, endLatlng, sucessHandle, faultHandle) {
        var origins = [startLatlng];
        var destinations = [endLatlng];
        var travelMode = "DRIVING";
        var distanceMatrixService = new google.maps.DistanceMatrixService;
        distanceMatrixService.getDistanceMatrix({
          origins: origins,
          destinations: destinations,
          travelMode: google.maps.TravelMode[travelMode]
        }, function (response, status) {
          if (status == google.maps.DistanceMatrixStatus.OK) {
            if (sucessHandle) {
              var result = {
                "distance": response.rows[0].elements[0].distance.value,
                "duration": response.rows[0].elements[0].duration.value
              };
              sucessHandle(result);
            }
          } else {
            if (faultHandle) {
              faultHandle(status);
            }
          }
        });
      }
    });

})();
