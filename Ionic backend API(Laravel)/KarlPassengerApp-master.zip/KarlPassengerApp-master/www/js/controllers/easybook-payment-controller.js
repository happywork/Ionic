/**
 * Created by wangyuanzhi on 16/3/12.
 */
(function () {
  'use strict';
  angular.module('passengerApp')
    .controller('EasybookPaymentCtrl',
      function ($scope, $ionicLoading, $ionicPopup, $state, $timeout, $filter, $ionicActionSheet, $ionicHistory, EasybookService, HttpService, LoginService, UserService) {
        $scope.$on('$ionicView.beforeEnter', function (event, data) {
          $scope.appointedTime = EasybookService.bookingParam.appointed_time;
          $scope.estimateDuration = EasybookService.bookingParam.estimate_duration;
          $scope.car = EasybookService.bookingCar;
          $scope.options = EasybookService.bookingParam.options;
          $scope.tripType = EasybookService.bookingParam.type;
          var amountOff = EasybookService.bookingParam.amountOff;
          var percentOff = EasybookService.bookingParam.percentOff;
          $scope.d_final_address = finalAddress(EasybookService.bookingParam.d_address);
          if($scope.tripType == 1){
            $scope.a_final_address = finalAddress(EasybookService.bookingParam.a_address);
          }
          $scope.totalPrice = EasybookService.bookingParam.showPrice ;//- amountOff - percentOff / 100 * (EasybookService.bookingParam.cost - amountOff);
          $scope.offer=EasybookService.bookingOffer;
          console.log($scope.offer)
          if (EasybookService.bookingParam.d_is_airport == 1 && !EasybookService.bookingParam.d_is_airport.icao) {
            $scope.dIsAirport = true;
            if (EasybookService.bookingParam.d_airline) {
              $scope.dAirLine = EasybookService.bookingParam.d_airline;
            } else {
              $scope.dAirLine = 'Unknow';
            }
            if (EasybookService.bookingParam.d_flight) {
              $scope.dAirFlight = EasybookService.bookingParam.d_flight;
            } else {
              $scope.dAirFlight = 'Unknow';
            }
          } else {
            $scope.dIsAirport = false;
          }

          if (EasybookService.bookingParam.a_is_airport == 1 && !EasybookService.bookingParam.a_is_airport.icao) {
            $scope.aIsAirport = true;
            if (EasybookService.bookingParam.a_airline) {
              $scope.aAirLine = EasybookService.bookingParam.a_airline;
            } else {
              $scope.aAirLine = 'Unknow';
            }
            if (EasybookService.bookingParam.a_flight) {
              $scope.aAirFlight = EasybookService.bookingParam.a_flight;
            } else {
              $scope.aAirFlight = 'Unknow';
            }
          } else {
            $scope.aIsAirport = false;
          }

          if ($scope.options.length == 0) {
            $scope.hasOptions = false;
          } else {
            $scope.hasOptions = true;
          }

          if ($scope.hasReturnService()) {
            $scope.rsAppointedTime = EasybookService.returnBookingParam.appointed_time;
            $scope.rsCar = EasybookService.returnBookingCar;
            $scope.rsOptions = EasybookService.returnBookingParam.options;
            // var rs_amountOff = EasybookService.returnBookingParam.amountOff;
            // var rs_percentOff = EasybookService.returnBookingParam.percentOff;
            // $scope.totalPrice = (EasybookService.bookingParam.showPrice + EasybookService.returnBookingParam.showPrice);
            $scope.rstotalPrice =  EasybookService.returnBookingParam.showPrice;
            $scope.rs_offer = EasybookService.rebookingOffer;
            console.log($scope.rs_offer);
            if ($scope.rsOptions.length == 0) {
              $scope.rsHasOptions = false;
            } else {
              $scope.rsHasOptions = true;
            }
          }

          getMyCards(data.direction);
        });

        var cards = [];
        var selectCard = undefined;

        function getMyCards(direction) {
          $ionicLoading.show();
          HttpService.get(Api.getCreditCards, {}, function (response) {
            $ionicLoading.hide();
            var code = response.code;
            var result = response.result;
            if (code == 2000) {
              if (result.length > 0) {
                cards = result;
                var type;
                var img;
                if (cards[0].card_type == 1) {
                  type = "VISA";
                  img = "img/card-visa.png"
                } else if (cards[0].card_type == 2) {
                  type = "MasterCard";
                  img = "img/card-mastercard.png"
                } else if (cards[0].card_type == 3) {
                  type = "AmericanExpress";
                  img = "img/card-american-express.png"
                } else {
                  type = "DISCOVER";
                  img = "img/card-discover.png"
                }
                $scope.cardString = " " + cards[0].card_number;
                $scope.card_check = cards[0].check_pass;
                $scope.cardImg = img;
                selectCard = cards[0];
              } else {
                //没有信用卡信息
                if (direction == 'forward') {
                  $scope.addCard();
                }
              }
            } else {
              //2100
              //没有信用卡信息
              if (direction == 'forward') {
                $scope.addCard();
              }
            }
          }, function (errorString, response) {
            $ionicLoading.hide();
            if (!LoginService.logoutWhenAuthExpired(response.code)) {
              if (errorString) {
                $ionicPopup.alert({
                  title: errorString,
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
              } else {
                $ionicPopup.alert({
                  title: $filter('translate')('easybook_payment.jsCheck_card_info'),
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
              }
            }
          });
        }

        $scope.addPayment = function () {
          $state.go('app.add-payment');
        };

        $scope.showCardsActionsheet = function () {
          if (cards.length > 0) {
            var buttons = [];
            for (var i = 0; i < cards.length; i++) {
              var type;
              if (cards[i].card_type == 1) {
                type = "VISA";
              } else if (cards[i].card_type == 2) {
                type = "MasterCard";
              } else if (cards[i].card_type == 3) {
                type = "AmericanExpress";
              } else {
                type = "DISCOVER";
              }
              var txt = '';
              if(cards[i].check_pass){
                txt = '<i class="credit_card"> '+type + " " + cards[i].card_number+' </i>';
              }else {
                txt = '<i class="ionic ion-alert-circled credit_card card_error">'+" "+type + " " + cards[i].card_number + '</i>️';
              }
              buttons.push({"text": txt});
            }
            $ionicActionSheet.show({
              titleText: $filter('translate')('easybook_payment.jsSelect_card'),
              buttons: buttons,
              cancelText: $filter('translate')('easybook_payment.jsCancel'),
              buttonClicked: function (index) {
                var type;
                var img;
                if (cards[index].card_type == 1) {
                  type = "VISA";
                  img = "img/card-visa.png"
                } else if (cards[index].card_type == 2) {
                  type = "MasterCard";
                  img = "img/card-mastercard.png"
                } else if (cards[index].card_type == 3) {
                  type = "AmericanExpress";
                  img = "img/card-american-express.png"
                } else {
                  type = "DISCOVER";
                  img = "img/card-discover.png"
                }
                $scope.cardString = " " + cards[index].card_number;
                $scope.card_check = cards[index].check_pass;
                $scope.cardImg = img;
                selectCard = cards[index];
                return true;
              }
            });
          } else {
            //nothing to do
          }
        };

        $scope.addCard = function () {
          $state.go('app.add-payment');
        };

        $scope.hasReturnService = function () {
          if (EasybookService.returnBookingParam && EasybookService.returnBookingParam.enable) {
            return true;
          } else {
            return false;
          }
        };

        $scope.form_pay_submit = function () {
          if (selectCard == undefined) {
            $ionicPopup.alert({
              title: $filter('translate')('easybook_payment.jsNo_payment_method'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
            return;
          }

          $ionicLoading.show({
            template: $filter('translate')('easybook_payment.jsProcessing_payment')
          });

          EasybookService.bookingParam.card_token = selectCard.card_token;
          EasybookService.booking(function (response, hasReturnService, returnServiceResponse) {
            $ionicLoading.hide();
            if (hasReturnService) {
              if (returnServiceResponse) {
                if (returnServiceResponse.code == 2000) {
                  $ionicPopup.alert({
                    title: $filter('translate')('easybook_payment.jsBooking_confirmed'),
                    okText: $filter('translate')('ionicPopup.jsOK')
                  }).then(function (res) {
                    $ionicHistory.clearCache();
                    $ionicHistory.nextViewOptions({
                      disableAnimate: true,
                      disableBack: true
                    });
                    $state.go('app.rides');
                  });
                } else if (returnServiceResponse.code == 8801) {
                  $ionicPopup.alert({
                    title: $filter('translate')('easybook_payment.jsBooking_confirmed_pay_fault'),
                    okText: $filter('translate')('ionicPopup.jsOK')
                  }).then(function (res) {
                    $ionicHistory.clearCache();
                    $ionicHistory.nextViewOptions({
                      disableAnimate: true,
                      disableBack: true
                    });
                    $state.go('app.rides');
                  });
                } else {
                  $ionicPopup.alert({
                    title: $filter('translate')('easybook_payment.jsBooking_confirmed_return_fault'),
                    okText: $filter('translate')('ionicPopup.jsOK')
                  }).then(function (res) {
                    $ionicHistory.clearCache();
                    $ionicHistory.nextViewOptions({
                      disableAnimate: true,
                      disableBack: true
                    });
                    $state.go('app.rides');
                  });
                }
              } else {
                $ionicPopup.alert({
                  title: $filter('translate')('easybook_payment.jsBooking_confirmed_return_fault'),
                  okText: $filter('translate')('ionicPopup.jsOK')
                }).then(function (res) {
                  $ionicHistory.clearCache();
                  $ionicHistory.nextViewOptions({
                    disableAnimate: true,
                    disableBack: true
                  });
                  $state.go('app.rides');
                });
              }
            } else {
              $ionicPopup.alert({
                title: $filter('translate')('easybook_payment.jsBooking_confirmed'),
                okText: $filter('translate')('ionicPopup.jsOK')
              }).then(function (res) {
                $ionicHistory.clearCache();
                $ionicHistory.nextViewOptions({
                  disableAnimate: true,
                  disableBack: true
                });
                $state.go('app.rides');
              });
            }
          }, function (errorString, response) {
            $ionicLoading.hide();
            if (!LoginService.logoutWhenAuthExpired(response.code)) {
              if (errorString) {
                $ionicPopup.alert({
                  title: errorString,
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
              } else {
                $ionicPopup.alert({
                  title: $filter('translate')('easybook_payment.jsBooking_fault'),
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
              }
            }
          });
        };


        var privacyPop;
        $scope.openPrivacyModel = function () {
          $timeout(function () {
            //这个方法如果跨域就不能加载页面
            //但是,齐海说绝对不存在跨域问题
            $('#disclaimer-div').load(Api.getCompanyDisclaimer);

          }, 0);
          privacyPop = $ionicPopup.show({
            templateUrl: "templates/privacy-policy-popup.html",
            scope: $scope,
            cssClass: "privacy-popstyle"
          })
        };

        $scope.onSetPrivacyCancel = function () {
          if (privacyPop) {
            privacyPop.close();
          }
        };

        function finalAddress(address) {
          var data = address.address_components;
          var finalAddressDate = [];

          //处理第一行
          //格式:'street_address route premise political'
          var line_1 = '';
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'street_number') {
              line_1 += data[i].long_name + '  ';
              break;
            }
          }
          var hasRoute = false;
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'route') {
              line_1 += data[i].long_name + ' ';
              hasRoute = true;
              break;
            }
          }

          if (!hasRoute) {
            for (var i = 0; i < data.length; i++) {
              if (data[i].types[0] == 'street_address') {
                line_1 += data[i].long_name + ' ';
                break;
              }
            }
          }

          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'premise') {
              line_1 += data[i].long_name + ' ';
              break;
            }
          }
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'political') {
              line_1 += data[i].long_name + ' ';
              break;
            }
          }
          finalAddressDate.push(line_1);

          //处理第二行
          //格式:'locality,administrative_area_level_1 postal_code'
          var line_2 = '';
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'locality') {
              line_2 += data[i].long_name;
              break;
            }
          }
          var hasState = false;
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'administrative_area_level_1') {
              line_2 += ',' + data[i].short_name;
              hasState = true;
              break;
            }
          }
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'postal_code') {
              if (hasState) {
                line_2 += ' ' + data[i].long_name;
              } else {
                line_2 += ',' + data[i].long_name;
              }
              break;
            }
          }
          finalAddressDate.push(line_2);
          return finalAddressDate;
        }
      });
})();
