// IIFE START //

(function () {
  'use strict';
  angular.module('passengerApp')
    .controller('NeedHelpCtrl',
      function ($scope, $state, $ionicLoading, $ionicPopup, $cordovaSms, ContactService, LoginService,$filter) {
        // if (window.cordova && window.cordova.plugins.Keyboard) {
        //   window.ga.startTrackerWithId('UA-89070126-1');
        //   window.ga.trackView('Need help');
        // }

      $scope.companyLogo=ApiServer.serverUrl+ApiServer.version+ '/companies/logo/' + ApiServer.companyId;

        $ionicLoading.show({
          template: $filter('translate')('need_help.jsFetching')
        });
        ContactService.getCompanyInfo(function (response) {
          $ionicLoading.hide();
          var userObject = response.result;
          $scope.telephone = userObject.phone1;
          $scope.companyEmail = userObject.email;
          $scope.smsPhone = userObject.phone1;
        }, function (errorString, response) {
          $ionicLoading.hide();
          if (!LoginService.logoutWhenAuthExpired(response.code)) {
            if(errorString){
              $ionicPopup.alert({
                title: errorString,
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            }else {
              $ionicPopup.alert({
                title: $filter('translate')('need_help.jsRequest_fault'),
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            }
          }
        });

        $scope.sendSMS = function () {
          ContactService.sendText($scope.smsPhone + '', '');
        };
      });
})();
