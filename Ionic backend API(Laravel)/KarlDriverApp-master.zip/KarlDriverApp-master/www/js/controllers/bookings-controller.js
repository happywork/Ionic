(function () {
  'use strict';

  angular.module('starter')

    .filter('CustomDateFilter', function ($filter) {
      return function (timeStamp) {
        var lang = localStorage.getItem('lang');
        var months = [$filter('translate')('bookings.jsJanuary'), $filter('translate')('bookings.jsFebruary'),
          $filter('translate')('bookings.jsMarch'), $filter('translate')('bookings.jsApril'),
          $filter('translate')('bookings.jsMay'), $filter('translate')('bookings.jsJune'),
          $filter('translate')('bookings.jsJuly'), $filter('translate')('bookings.jsAugust'),
          $filter('translate')('bookings.jsSeptember'), $filter('translate')('bookings.jsOctober'),
          $filter('translate')('bookings.jsNovemeber'),  $filter('translate')('bookings.jsDecember')];
        var weekdays = [$filter('translate')('bookings.jsSUNDAY'), $filter('translate')('bookings.jsMONDAY'),
          $filter('translate')('bookings.jsTUESDAY'), $filter('translate')('bookings.jsWEDNESDAY'),
          $filter('translate')('bookings.jsTHURSDAY'), $filter('translate')('bookings.jsFRIDAY'),
          $filter('translate')('bookings.jsSATURDAY')];
        var inputDate = new Date(timeStamp);
        var showToday = new Date();
        if (inputDate.getDate() === showToday.getDate() && inputDate.getMonth() === showToday.getMonth() && inputDate.getFullYear() === showToday.getFullYear()) {
          return $filter('translate')('bookings.jsTODAY');
        }
        if(lang==='fr'){
          return weekdays[inputDate.getDay()] + ", " + inputDate.getDate()  + ", " + months[inputDate.getMonth()];

        }else {
          return weekdays[inputDate.getDay()] + ", " + months[inputDate.getMonth()] + ", " + inputDate.getDate();
        }
      };
    })

    .controller("BookingsCtrl", function (MapService, $scope, $ionicSideMenuDelegate, $stateParams, $state, $ionicModal, $q, $ionicPopup, $ionicLoading, $timeout,
                                          BookingsService, TripService, UserService, $filter, LoginService,$localStorage) {
      $scope.$on('$ionicView.beforeEnter', function () {
        $scope.today = new Date($filter('date')(new Date(), "longDate"));
        $scope.loadBookings();
      });

      $scope.initWeekBookings = function (originalBookings) {
        if(originalBookings.length == 0){
          $scope.isDisplayCost = false;
        }else{
          if (originalBookings[0].hide_driver_fee == 1) {
            $scope.isDisplayCost = false;
          }
          if (originalBookings[0].hide_driver_fee == 0) {
            $scope.isDisplayCost = true;
          }
        }
        $scope.weekBookings = [];
        $scope.weekBookingsCount = 0;
        var numberOftoday = $scope.today.getDay();
        if (numberOftoday == 0) {
          numberOftoday = 7;
        }
        for (var i = 0; i < 7; i++) {
          var bookingPerDay = {};
          var otherDate = new Date($scope.today.getTime() + 24 * i * 60 * 60 * 1000);
          bookingPerDay.date = $filter('CustomDateFilter')(otherDate.getTime());
          bookingPerDay.bookings = [];
          for (var j = 0; j < originalBookings.length; j++) {
            var bookingDate = $filter('CustomDateFilter')(originalBookings[j].appointed_at * 1000);
            if (bookingDate === bookingPerDay.date) {
              if (originalBookings[j].gender == 2) {
                originalBookings[j].customerName = $filter('translate')('bookings.jsMr_space', {firstName: originalBookings[j].c_first_name, lastName: originalBookings[j].c_last_name});
              } else {
                originalBookings[j].customerName = $filter('translate')('bookings.jsMs_space', {firstName: originalBookings[j].c_first_name, lastName: originalBookings[j].c_last_name});
              }
              if (originalBookings[j].type == 1) {
                originalBookings[j].appointed_at_shortTime = $filter('dateFormatter')(originalBookings[j].appointed_at * 1000, "shortTime");
              } else {
                var startTime = $filter('dateFormatter')(originalBookings[j].appointed_at * 1000, "shortTime");
                var endTime = $filter('dateFormatter')(originalBookings[j].appointed_at * 1000 + originalBookings[j].estimate_time * 60 * 1000, "shortTime");
                originalBookings[j].appointed_at_shortTime = startTime + "-" + endTime;
              }
              originalBookings[j].option_data = JSON.parse(originalBookings[j].option_data);
              originalBookings[j].car_data = JSON.parse(originalBookings[j].car_data);
              bookingPerDay.bookings.push(originalBookings[j]);
              $scope.weekBookingsCount++;
            }
          }
          bookingPerDay.bookingCount = bookingPerDay.bookings.length;
          $scope.weekBookings.push(bookingPerDay);
        }
        for(var i = 0;i < $scope.weekBookings.length;i++){
          if($scope.weekBookings[i].bookings){
            for(var j = 0;j < $scope.weekBookings[i].bookings.length;j++){
              if($scope.weekBookings[i].bookings[j].a_address){
                if($scope.weekBookings[i].bookings[j].a_address.address_components){
                  $scope.weekBookings[i].bookings[j].a_address.final_address = finalAddress($scope.weekBookings[i].bookings[j].a_address);
                  $scope.weekBookings[i].bookings[j].d_address.final_address = finalAddress($scope.weekBookings[i].bookings[j].d_address);

                }
              }else{
                $scope.weekBookings[i].bookings[j].d_address.final_address = finalAddress($scope.weekBookings[i].bookings[j].d_address);
              }
            }
          }
        }
      };

      $scope.loadBookings = function () {
        $scope.bookings = [];
        $ionicLoading.show();

        //今天到1年后、正序
        //只选择trip_state为0、1、2、3、4
        var today = new Date($filter('date')(new Date(), "longDate"));
        var requestParams = {
          "start_time": parseInt(today.getTime() / 1000),
          "end_time": parseInt(today.getTime() / 1000 + 365 * 24 * 60 * 60),
          "order_by": 0,
          "trip_state": '0,1,2,3,4'
        };
        BookingsService.loadBookings(requestParams, function (response) {
          $ionicLoading.hide();
          $scope.$broadcast('scroll.refreshComplete');
          if (response.code == 2100) {
            $scope.initWeekBookings([]);
          } else {
            $scope.initWeekBookings(response.result.bookings);
          }
        }, function (errorString, response) {
          $ionicLoading.hide();
          $scope.$broadcast('scroll.refreshComplete');
          if (!LoginService.logoutWhenAuthExpired(response.code)) {
            if (errorString) {
              $ionicPopup.alert({
                title: errorString,
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            } else {
              $ionicPopup.alert({
                title: $filter('translate')('bookings.jsRequest_clients_fault'),
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            }
          }
        })
      };

      $scope.toggleGroup = function (group) {
        if ($scope.isGroupShown(group)) {
          $scope.shownGroup = null;
        } else {
          if (group.bookingCount == 0) {
            $scope.shownGroup = null;
          } else {
            $scope.shownGroup = group;
            // 如地图权限没有加载出弹框一次
            $scope.positionAlertContent = $filter('translate')('positionAlert.jsContent');
            if($localStorage.canPosition==2&&$localStorage.canNetWork==1){
              $localStorage.canPosition=1;
              $ionicPopup.show ({
                title: $filter('translate')('positionAlert.jsTitle'),
                template: '<div class="line"></div><p>{{positionAlertContent}}</p>',
                cssClass: 'location-permission-popup',
                scope: $scope,
                buttons: [ {
                  text: 'OK',
                  type: 'button-positive',
                  onTap: function(e) {
                    console.log(e);
                  }
                }]
              });
            }

          }
        }
      };

      $scope.isGroupShown = function (group) {
        return $scope.shownGroup === group;
      };

      $scope.enterBookingDetail = function (booking) {
        $state.go('app.booking-detail', {"booking": booking});
      };

      function finalAddress(address) {
        var data = address.address_components;
        var finalAddressDate = [];

        //处理第一行
        //格式:'street_address route premise political'
        var line_1 = '';
        for (var i = 0; i < data.length; i++) {
          if (data[i].types[0] == 'street_number') {
            line_1 += data[i].long_name + '  ';
            break;
          }
        }
        var hasRoute = false;
        for (var i = 0; i < data.length; i++) {
          if (data[i].types[0] == 'route') {
            line_1 += data[i].long_name + ' ';
            hasRoute = true;
            break;
          }
        }

        if (!hasRoute) {
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'street_address') {
              line_1 += data[i].long_name + ' ';
              break;
            }
          }
        }

        for (var i = 0; i < data.length; i++) {
          if (data[i].types[0] == 'premise') {
            line_1 += data[i].long_name + ' ';
            break;
          }
        }
        for (var i = 0; i < data.length; i++) {
          if (data[i].types[0] == 'political') {
            line_1 += data[i].long_name + ' ';
            break;
          }
        }
        finalAddressDate.push(line_1);

        //处理第二行
        //格式:'locality,administrative_area_level_1 postal_code'
        var line_2 = '';
        for (var i = 0; i < data.length; i++) {
          if (data[i].types[0] == 'locality') {
            line_2 += data[i].long_name;
            break;
          }
        }
        var hasState = false;
        for (var i = 0; i < data.length; i++) {
          if (data[i].types[0] == 'administrative_area_level_1') {
            line_2 += ',' + data[i].short_name;
            hasState = true;
            break;
          }
        }
        for (var i = 0; i < data.length; i++) {
          if (data[i].types[0] == 'postal_code') {
            if (hasState) {
              line_2 += ' ' + data[i].long_name;
            } else {
              line_2 += ',' + data[i].long_name;
            }
            break;
          }
        }
        finalAddressDate.push(line_2);
        return finalAddressDate;
      }
    });
})();
