id="com.inov.tdriver"
version="2.0.0"
<name>KARL Driver</name>
<description>KARL tDriver</description>
private static _appId = "88f5b25e-1d38-4929-8b86-861dc3463245";
private static _googleId = "AAAAq-J12rw:APA91bEX_8sejcOs1rzKIvdYVX-JX8b167XVEpz2HON6mkLmmgQ6a8jf_REd5MkXVIKmzw4DFbEl9-J8gWrZ_L3BDJRUYfpUM11Vo3GCzI70t9vLYm9godSrMwFRLY1yF9Gk3L4EfS8j";
private static _apiHost = "http://test.api.karldash.com/";
onesignalaccount: heroalur@qq.com
firebaseaccount: heroalur@gmail.com
