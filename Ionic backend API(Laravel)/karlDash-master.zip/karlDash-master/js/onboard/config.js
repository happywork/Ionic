StripeInfo={
    card_url:'https://api.stripe.com/v1/tokens',
    publish_key : 'pk_test_QmlWxSSnhvSrt5jLL3BGoOZt'
    // publish_key : 'pk_live_OPMfJbR7x1fu61Mf197QRiln',
};

WebsiteUrl = "http://dev.karl.limo";
DashboardUrl ="http://dev.karldash.com";