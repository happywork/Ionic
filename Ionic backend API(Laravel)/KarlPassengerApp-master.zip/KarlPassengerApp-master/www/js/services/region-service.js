/**
 * Created by wangyuanzhi on 16/5/21.
 */
(function () {
  "use strict";
  angular.module('passengerApp').service('RegionService', function (StorageService) {
    var self = this;

    /*region
     *region.country = 'US'
     *region.postalCode = '710000'
     *region.serverUrl = 'http://115.28.202.172:9000'
     */
    self.initialize = function(){
      var region = {};
      region.country = 'US';
      //region.country = 'CN';
      //region.country = 'GB';
      self.saveCurrentRegion(region);
    };

    //getCurrentRegion
    self.getCurrentRegion = function () {
      if (!this.region) {
        this.region = StorageService.getRegion();
      }
      return this.region;
    };

    //saveCurrentRegion
    self.saveCurrentRegion = function (regionObject) {
      this.region = regionObject;
      StorageService.setRegion(regionObject);
    };

    //clearCurrentRegion
    self.clearCurrentRegion = function () {
      StorageService.cleanUserInfo();
      StorageService.cleanRegion();
    };
  });
})();
