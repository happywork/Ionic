// Ionic Starter App
// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'

angular.module('starter',
  ['ionic', 'ionic.cloud',
    'ionic.service.core', 'ion-google-place', 'ngCordova', 'ngStorage', 'pascalprecht.translate',
    'ngMessages', 'ui.calendar', 'starter.services', 'starter.controllers',
    'starter.dateFilters','starter.filters', 'ionic.ion.showWhen', 'angular.filter', "ion-datetime-picker",'passengerApp.princeFilters'])
  .run(function ($ionicPlatform, PushService, BackgroundModeService, $ionicPush, $timeout, AppService,LocationService,$localStorage) {
    // AppService.checkAppUpdateService('1.0.7','android');
    $ionicPlatform.ready(function () {
      $timeout(function () {
        (function () {
          LocationService.getCurrentPosition(function (position) {
            if(!$localStorage.canPosition){
              $localStorage.canPosition=1;
            }
          }, function (error) {
            if(!$localStorage.canPosition){
              $localStorage.canPosition=2;
            }
          })
        })()
      },0);
      if (window.cordova && window.cordova.plugins.Keyboard) {
        $ionicPlatform.registerBackButtonAction(function () {
          //nothing to do
        }, 101);

        if (window.cordova.InAppBrowser) {
          window.open = window.cordova.InAppBrowser.open;
        }

        $timeout(function () {
          window.mixpanel.init('5bf8887a3803e42dcd780e75770d4173', function () {
            console.log('mixpanel init success');
          }, function () {
            console.log('mixpanel init fail');
          });
        }, 0);
        var push = PushNotification.init({
          android: {
            senderID: "250587079216"
          },
          ios: {
            alert: true,
            badge: true,
            sound: true
          }
        });

        push.on('registration', function (data) {
          console.log("ionic push registration event: " + data.registrationId);
          $ionicPush.register().then(function (t) {
            return $ionicPush.saveToken(t);
          }).then(function (t) {
            console.log('Token saved:' + t.token);
            PushService.savePushToken(t.token);
            PushService.tryUploadPushToken();
          });
        });

        push.on('notification', function (data) {
          console.log("ionic push notification event: " + data.message);
          console.log("ionic push notification event: " + data.title);
          console.log("ionic push notification event: " + data.count);
          console.log("ionic push notification event: " + data.sound);
          console.log("ionic push notification event: " + data.image);
          console.log("ionic push notification event: " + data.additionalData);
        });

        push.on('error', function (e) {
          console.log("ionic push error event: " + e.message);
        });
        // // Add push registration
        // var push = new Ionic.Push({
        //   "debug": true,
        //   "onNotification": function(notification) {
        //     console.log("onNotification callback:" + notification.text);
        //     console.log("onNotification callback:" + notification.payload.booking_id);
        //     console.log("onNotification callback:" + notification.app.asleep);
        //     console.log("onNotification callback:" + notification.app.closed);
        //   },
        //   "pluginConfig": {
        //     "ios": {
        //       "badge": true,
        //       "sound": true,
        //       "alert": true
        //     },
        //     "android": {
        //       "iconColor": "#343434"
        //     }
        //   }
        // });
        //
        // var callback = function(pushToken) {
        //   console.log("push.register callback:" + pushToken.token);
        //   // upload push token to server
        //   PushService.savePushToken(pushToken.token);
        //   PushService.tryUploadPushToken();
        // };
        //
        // push.register(callback);
        // // Push registration add finished

        // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
        // for form inputs)
        cordova.plugins.Keyboard.hideKeyboardAccessoryBar(false);

        // Don't remove this line unless you know what you are doing. It stops the viewport
        // from snapping when text inputs are focused. Ionic handles this internally for
        // a much nicer keyboard experience.
        cordova.plugins.Keyboard.disableScroll(true);

        if (cordova.plugins.Keyboard.isVisible) {
          cordova.plugins.Keyboard.closeKeyboard();
        }

        // Enable background mode
        cordova.plugins.backgroundMode.enable();

        // Called when background mode has been activated
        cordova.plugins.backgroundMode.onactivate = function () {
          BackgroundModeService.enterBackground();
        };

        // Called when background mode has been deactivated
        cordova.plugins.backgroundMode.ondeactivate = function () {
          BackgroundModeService.enterForeground();
        };


        window.cordova.getAppVersion.getVersionNumber(function (v) {
          //IOS上,是3位,比如1.0.7
          //安卓上,是4为,比如1.0.7.0
          var version = v.substr(0, 5);
          var android = 'android';
          var ios = 'ios';
          window.cordova.getAppVersion.getAppName(function (name) {
            if ($ionicPlatform.is(android)) {
              AppService.checkAppUpdateService(version, android, name);
            } else {
              AppService.checkAppUpdateService(version, ios, name);
            }
          }, function (error) {
          });
        }, function (error) {
        });
      }

      if (window.StatusBar) {
        StatusBar.styleLightContent();
      }

    });

  })


  .config(function ($translateProvider) {
    $translateProvider
      .useStaticFilesLoader({
        prefix:'languages/',
        suffix:'.json'
      })

      .registerAvailableLanguageKeys(['en', 'zh','fr'], {
        'en_*': 'en',
        "zh_*": 'zh',
        "fr_*": 'fr',
        '*': 'en'
      })

      .determinePreferredLanguage()

      .fallbackLanguage('en')

      .useSanitizeValueStrategy('escapeParameters');

    var lang;
// todo
    if(localStorage.getItem('lang')){
      lang=localStorage.getItem('lang')
    }else {
      lang=$translateProvider.preferredLanguage();
      if(lang != 'en'&&lang != 'fr'){
        lang = 'en'
      }
      localStorage.setItem('lang',lang);
    }


    $translateProvider.preferredLanguage(lang);
    // if (lang == 'zh') {
    //   lang = 'zh-cn';
    // }

    moment.locale(lang);
    console.log('momentLang is ', moment.locale());

    console.log('dateLang is ', lang);
  })


  .config(function ($stateProvider, $urlRouterProvider, $ionicCloudProvider, $ionicConfigProvider) {
    $ionicConfigProvider.backButton.text('');
    $ionicCloudProvider.init({
      "core": {
        "app_id": "03f35dea"
      },
      "push": {
        "sender_id": "250587079216",
        "pluginConfig": {
          "ios": {
            "badge": true,
            "sound": true,
            "alert": true
          },
          "android": {
            "iconColor": "#343434"
          }
        }
      }
    });
    $stateProvider
      .state('app', {
        cache: false,
        url: '/app',
        abstract: true,
        templateUrl: 'templates/menu.html',
        controller: 'AppCtrl'
      })

      .state('login', {
        url: '/login',
        templateUrl: 'templates/login.html',
        controller: 'LoginCtrl'
      })

      .state('app.bookings', {
        url: '/bookings',
        views: {
          'menu-content': {
            templateUrl: 'templates/bookings.html',
            controller: 'BookingsCtrl'
          }
        }
      })

      .state('app.booking-detail', {
        cache: false,
        params: {"booking": {}},
        url: '/booking-detail',
        views: {
          'menu-content': {
            templateUrl: 'templates/booking-detail.html',
            controller: 'BookingDetailCtrl'
          }
        }
      })

      .state('app.current-trip', {
        cache: false,
        params: {"booking": {}},
        url: '/current-trip',
        views: {
          'menu-content': {
            templateUrl: 'templates/current-trip.html',
            controller: 'TripCtrl'
          }
        }
      })

      .state('app.calendar', {
        url: '/calendar',
        views: {
          'menu-content': {
            templateUrl: 'templates/calendar.html',
            controller: 'BookingsCalendarCtrl'

          }
        },
        params: {
          auth: 'none'
        }
      })

      .state('app.map-locate', {
        params: {
          "locateSuccessEvent": function () {
          }
        },
        url: '/map-locate',
        views: {
          'menu-content': {
            templateUrl: 'templates/map-locate.html',
            controller: 'MapLocateCtrl',
            cache: false
          }
        }
      })

      .state('app.profile', {
        cache: false,
        url: '/profile',
        views: {
          'menu-content': {
            templateUrl: 'templates/profile.html',
            controller: 'ProfileCtrl'
          }
        },
        params: {
          auth: 'none'
        }
      })

      .state('app.event-add', {
        cache: false,
        url: '/event-add',
        views: {
          'menu-content': {
            templateUrl: 'templates/event-add.html',
            controller: 'AddEventCtrl'
          }
        }
      })

      .state('multilingual', {
        url: '/multilingual',
        templateUrl: 'templates/multilingual.html',
        controller: 'MultilingualCtrl'
      })
    ;

    $urlRouterProvider.otherwise('/login');
  });
