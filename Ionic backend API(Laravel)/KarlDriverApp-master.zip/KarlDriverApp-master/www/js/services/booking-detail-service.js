(function () {
  'use strict';
  angular.module('starter')
    .service('BookingDetailService', function ($state) {
      var self = this;

    });
})();
