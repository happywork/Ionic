/**
 * Created by wangyaunzhi on 16/11/22.
 */
angular.module('starter.dateFilters',[])
  .filter('dateFormatter', function ()
  {
    return function(date, format) {
      var lang = localStorage.getItem('lang')
      var formatStr;
      var formatDate = {
        "shortTime": {
          "en": "h:mm a",
          "fr": "H:mm"
        },
        "bookLongDate":{
          "en":"L LT",
          "fr":"L LT"
        }
      };
      if (format in formatDate) {
        formatStr = formatDate[format][lang];
      } else {
        formatStr = format
      }
      if (!date || !format) {
        return "";
      } else {
        return moment(date).format(formatStr); //in absence of format parameter, return the relative time from the given date
      }
    }
  });
