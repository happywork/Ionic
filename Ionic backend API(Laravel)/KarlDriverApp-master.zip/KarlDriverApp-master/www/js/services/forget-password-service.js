(function () {
  'use strict';

  angular.module('starter')
    .service('ForgetPwdService', function ($state, $ionicPopup, HttpService) {
      this.resetPassword = function (email, successHandler, faultHandler) {
        HttpService.post(Api.resetPassword, {email: email}, successHandler, faultHandler);
      }
    });
})();
