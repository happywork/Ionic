<?php

namespace App\Method\Money\Exceptions;

class CurrencyException extends \Exception
{
 
}

