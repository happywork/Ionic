// IIFE START //
(function () {
  'use strict';
  angular.module('passengerApp')
    .controller("TripCtrl",
      function ($scope, $state, $cordovaGeolocation, $timeout, $window, $ionicSideMenuDelegate, $ionicLoading, $filter, $ionicModal, $ionicPlatform, UserService, MapService, $ionicPopup, TripService, RidesService, $ionicHistory, LoginService) {

        var map;
        var latLngBounds;
        var driverLoction;
        var pickUpLoction;
        var dropOffLoction;
        var driverMaker;
        var pickUpMaker;
        var dropOffMaker;
        var realStartTripTime;
        var timeout;
        var isWatchingTrip = false;
        var carImg = "img/slide1-b.png";
        var carName = "";
        $scope.upcomingRides = [];
        $scope.currentTripList = [];
        $scope.isLoadding = true;
        $scope.remindString = null;
        $scope.langStyle=localStorage.getItem('lang')!=='en';
        console.log($scope.langStyle)
        //init map
        function loadMap() {
          $timeout(function () {
            if (!map) {
              map = new google.maps.Map(document.getElementById('trip-map'), {
                center: {lat: 34.1017614, lng: -118.3450541},
                zoom: 12,
                mapTypeControl: false,
                disableDefaultUI: true
              });
            } else {
              map.setZoom(12);
            }
          }, 0);
        }

        //enter trip
        var screenHeight = window.screen.availHeight;
        $scope.$on("$ionicView.enter", function () {
          if ($ionicPlatform.is('android')) {
            if (window.AndroidFullScreen) {
              AndroidFullScreen.isImmersiveModeSupported(function () {
                AndroidFullScreen.getAppScreenHeight(function (value) {
                  screenHeight = value;
                }, function (error) {
                });
              }, function (error) {
              });
            }
          }
          loadMap();
          resizeMapFixToHeight(screenHeight - 44.0);
          $scope.getCurrentTripList();
        });

        //leave trip
        $scope.$on("$ionicView.leave", function () {
          leaveCurrentTrip();
        });

        $scope.$on("SideMenuBackToContent", function () {
          if ($ionicSideMenuDelegate.isOpenLeft() && !$scope.isTripping) {
            $scope.getCurrentTripList();
          }
        });

        //Fix Map
        function resizeMapFixToHeight(height) {
          if(localStorage.getItem('lang')==='fr'){
            height=height-3;
          }
          angular.element($("#trip-map")).css("height", height + "px");
        }

        //add marker
        function addMarker(latLng) {
          var marker = new google.maps.Marker({
            position: latLng,
            map: map
          });
          return marker;
        }

        //make LatLngBounds
        function makeLatLngBounds(latLngs) {
          var bounds = new google.maps.LatLngBounds();
          for (var i = 0; i < latLngs.length; i++) {
            var latLng = new google.maps.LatLng({
              lat: latLngs[i].lat,
              lng: latLngs[i].lng
            });
            bounds.extend(latLng);
          }
          return bounds;
        }

        //获取正在执行的订单列表
        $scope.getCurrentTripList = function () {
          $scope.isLoadding = true;
          $ionicLoading.show();
          var requestParames = {};
          //过去到未来
          requestParames.start_time = 0;
          //查找trip状态为1,2,3的trip
          requestParames.trip_state = "1,2,3";
          //查找order状态为1的trip
          requestParames.order_state = "1";
          RidesService.getRidesData(requestParames, function (response) {
            $scope.isLoadding = false;
            var code = response.code;
            var result = response.result;
            if (code == 2000 && result.bookings) {
              if (result.bookings.length > 0) {
                if (result.bookings.length == 1) {
                  var booking = result.bookings[0];
                  TripService.refreshOrderState(booking.id, function (res) {
                    $ionicLoading.hide();
                    var orderStateObj = res.result;
                    $scope.currentTripList = result.bookings;
                    TripService.trippingbook = booking;
                    TripService.trippingbook.driver_data = JSON.parse(booking.driver_data);
                    TripService.trippingbook.car_data = JSON.parse(booking.car_data);
                    TripService.trippingbook.orderStateObj = orderStateObj;

                    $scope.isTripping = true;
                    if ($ionicPlatform.is('android')) {
                      resizeMapFixToHeight(screenHeight - 144.0);
                    } else {
                      resizeMapFixToHeight(screenHeight - 124.0);
                    }
                    map.initialBoundsBeforPickup = true;
                    map.initialBoundsAfterPickup = true;
                    $scope.driverData = angular.copy(TripService.trippingbook.driver_data);
                    var carData = TripService.trippingbook.car_data;
                    carImg = carData.img;
                    carName = carData.brand;
                    //set map state
                    console.log('order is ', TripService.trippingbook.orderStateObj);

                    setMapState(TripService.trippingbook.orderStateObj);
                    //start trip
                    startMyTrip();
                  }, function (errorString, errorRes) {
                    $ionicLoading.hide();
                    if (!LoginService.logoutWhenAuthExpired(errorRes.code)) {
                      $scope.remindString = '';
                      var titleString;
                      if (errorString) {
                        titleString = errorString + $filter('translate')('current_trip.jsCheck_again')
                      } else {
                        titleString = $filter('translate')('current_trip.jsFault_check_again')
                      }
                      $ionicPopup.confirm({
                        title: titleString,
                        okText: $filter('translate')('ionicPopup.jsOK'),
                        cancelText:$filter('translate')('ionicPopup.jsCancel')
                      }).then(function (res) {
                        if (res) {
                          $scope.getCurrentTripList();
                        } else {
                          $ionicSideMenuDelegate.toggleLeft();
                        }
                      });
                    }
                  });
                } else {
                  $ionicLoading.hide();
                  $scope.currentTripList = result.bookings;
                  $scope.remindString = $filter('translate')('current_trip.jsHave_trips', {length: result.bookings.length});
                }
              } else {
                $ionicLoading.hide();
                $scope.currentTripList = [];
                $scope.remindString = $filter('translate')('current_trip.jsHave_not_trips');
              }
            } else {
              //2100
              $ionicLoading.hide();
              $scope.currentTripList = [];
              $scope.remindString = $filter('translate')('current_trip.jsHave_not_trips');
            }
          }, function (errorString, response) {
            $ionicLoading.hide();
            if (!LoginService.logoutWhenAuthExpired(response.code)) {
              $scope.remindString = '';
              $scope.isLoadding = false;
              var titleString;
              if (errorString) {
                titleString = errorString + $filter('translate')('current_trip.jsCheck_again')
              } else {
                titleString = $filter('translate')('current_trip.jsFault_check_again')
              }
              $ionicPopup.confirm({
                title: titleString,
                okText: $filter('translate')('ionicPopup.jsOK'),
                cancelText:$filter('translate')('ionicPopup.jsCancel')
              }).then(function (res) {
                if (res) {
                  $scope.getCurrentTripList();
                } else {
                  $ionicSideMenuDelegate.toggleLeft();
                }
              });
            }
          })
        };

        $scope.selectRideToWatch = function (index) {
          $ionicLoading.show();
          var booking = $scope.currentTripList[index];
          TripService.refreshOrderState(booking.id, function (response) {
            $ionicLoading.hide();
            var orderStateObj = response.result;
            TripService.trippingbook = booking;
            TripService.trippingbook.driver_data = JSON.parse(booking.driver_data);
            TripService.trippingbook.car_data = JSON.parse(booking.car_data);
            TripService.trippingbook.orderStateObj = orderStateObj;

            $scope.isTripping = true;
            if ($ionicPlatform.is('android')) {
              resizeMapFixToHeight(screenHeight - 144.0);
            } else {
              resizeMapFixToHeight(screenHeight - 124.0);
            }
            map.initialBoundsBeforPickup = true;
            map.initialBoundsAfterPickup = true;
            $scope.driverData = angular.copy(TripService.trippingbook.driver_data);
            var carData = TripService.trippingbook.car_data;
            carImg = carData.img;
            carName = carData.brand;
            //set map state
            setMapState(TripService.trippingbook.orderStateObj);
            //start trip
            startMyTrip();
          }, function (errorString, response) {
            $ionicLoading.hide();
            if (!LoginService.logoutWhenAuthExpired(response.code)) {
              $scope.remindString = '';
              if (errorString) {
                $ionicPopup.alert({
                  title: errorString,
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
              } else {
                $ionicPopup.alert({
                  title: $filter('translate')('current_trip.jsRequest_fault'),
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
              }
            }
          });
        };

        //Start trip
        function startMyTrip() {
          isWatchingTrip = true;
          onTrip();
        }

        function onTrip() {
          if (isWatchingTrip == false) {
            return;
          }
          if (timeout) {
            $timeout.cancel(timeout);
          } else {
            //nothing to do...
          }

          timeout = $timeout(function () {
            if (!TripService.trippingbook) {
              if (timeout) {
                $timeout.cancel(timeout);
              } else {
                //nothing to do...
              }
              return;
            }
            getOrderState(function (response) {
              if (TripService.trippingbook) {
                var orderStateObj = response.result;
                TripService.trippingbook.orderStateObj = orderStateObj;
                setMapState(orderStateObj);
              } else {
                //nothing to do
              }
            }, function (errorString, response) {
              if (!LoginService.logoutWhenAuthExpired(response.code)) {
              }
            });
            onTrip();
          }, 5000);
        }


        //set map state
        function setMapState(orderStateObj) {
          if (!pickUpLoction) {
            pickUpLoction = {
              latlng: {lat: TripService.trippingbook.d_lat, lng: TripService.trippingbook.d_lng},
              address: TripService.trippingbook.d_address
            };
          }
          if (!dropOffLoction && TripService.trippingbook.type == 1) {
            dropOffLoction = {
              latlng: {lat: TripService.trippingbook.a_lat, lng: TripService.trippingbook.a_lng},
              address: TripService.trippingbook.a_address
            };
          }

          if ((!orderStateObj.last_report_lat || !orderStateObj.last_report_lng) && orderStateObj.trip_state < 4) {
            //提示司机地址不可用
            $scope.tripState = $filter('translate')('current_trip.jsRemind');
            $scope.tripStreet = [];
            $scope.tripStreet[0] = $filter('translate')('current_trip.jsDriver_address_not_available');
            //P2P显示起点和终点
            //HOURLY显示起点
            if (!pickUpMaker) {
              pickUpMaker = addMarker(pickUpLoction.latlng);
            } else {
              pickUpMaker.setPosition(pickUpLoction.latlng);
            }
            if (dropOffLoction) {
              if (!dropOffMaker) {
                dropOffMaker = addMarker(dropOffLoction.latlng);
              } else {
                dropOffMaker.setPosition(dropOffLoction.latlng);
              }
              latLngBounds = makeLatLngBounds([pickUpLoction.latlng, dropOffLoction.latlng]);
            } else {
              latLngBounds = makeLatLngBounds([pickUpLoction.latlng]);
            }
            google.maps.event.addListener(map, 'zoom_changed', function () {
              var zoomChangeBoundsListener = google.maps.event.addListener(map, 'bounds_changed', function (event) {
                if (map.getZoom() > 14 && map.initialZoom == true) {
                  // Change max/min zoom here
                  map.setZoom(14);
                  map.initialZoom = false;
                }
                google.maps.event.removeListener(zoomChangeBoundsListener);
              });
            });
            map.initialZoom = true;
            map.fitBounds(latLngBounds);

            if (TripService.trippingbook.type == 1) {
            } else {
              $scope.stateRemind = $filter('translate')('current_trip.jsLast');
              var duration = orderStateObj.last_time;
              $scope.durationRemind = JSON.stringify(Math.round(duration / 60)) + $filter('translate')('current_trip.jsMinutes');
            }
            if (orderStateObj.trip_cost) {
              // $scope.cost = "Cost: $" + orderStateObj.trip_cost.toFixed(2);
              $scope.cost = $filter('translate')('current_trip.jsCost') + $filter('princeTranslateFilters')(orderStateObj.trip_cost.toFixed(2),false,false,orderStateObj.ccy);
            } else {
              $scope.cost = $filter('translate')('current_trip.jsCost');
            }
            return;
          }
          driverLoction = {
            latlng: {lat: orderStateObj.last_report_lat, lng: orderStateObj.last_report_lng},
            address: orderStateObj.last_address
          };

          if (!driverMaker) {
            driverMaker = addMarker(driverLoction.latlng);
          } else {
            driverMaker.setPosition(driverLoction.latlng);
          }
          if (orderStateObj.trip_state == 0) {
            //impossible!!!!!!
          } else if (orderStateObj.trip_state == 1) {
            //driver set off
            if (!pickUpMaker) {
              pickUpMaker = addMarker(pickUpLoction.latlng);
            } else {
              pickUpMaker.setPosition(pickUpLoction.latlng);
            }
            driverMaker.setIcon('http://duanctest.sinaapp.com/a4c/image/car_blue.png');

            $scope.tripState = $filter('translate')('current_trip.jsCOME_TO_PICK_UP');
            if (orderStateObj.last_address == '') {
              MapService.geocodeLatLng(driverLoction.latlng, function (address) {
                $scope.tripStreet = finalAddress(address);
              }, function (error) {
                console.log('setMapState时地理编码失败,错误: ' + error);
              });
            } else {
              var address = JSON.parse(orderStateObj.last_address);
              $scope.tripStreet = finalAddress(address);
            }
            $scope.stateRemind = $filter('translate')('current_trip.jsDriver_ETA');
            if (orderStateObj.trip_cost) {
              // $scope.cost = "Cost: $" + orderStateObj.trip_cost.toFixed(2);
              $scope.cost = $filter('translate')('current_trip.jsCost') +  $filter('princeTranslateFilters')(orderStateObj.trip_cost.toFixed(2),false,false,orderStateObj.ccy);
            } else {
              $scope.cost = $filter('translate')('current_trip.jsCost');
            }

            var startLatlng = new google.maps.LatLng(driverLoction.latlng);
            var endLatlng = new google.maps.LatLng(pickUpLoction.latlng);
            MapService.getMapMatrixDistanceWithP2p(startLatlng, endLatlng, function (result) {
              var duration = result.duration;
              var nowDate = new Date();
              var etaDate = new Date(nowDate.getTime() + duration * 1000);
              $scope.durationRemind = JSON.stringify(Math.round(duration / 60)) + $filter('translate')('current_trip.jsMinutesRemind',{etaDate:$filter('dateFormatter')(etaDate, "shortTime")});
            }, function (error) {
              //nothing to do...
            });

            if (map.initialBoundsBeforPickup == true) {
              latLngBounds = makeLatLngBounds([driverLoction.latlng, pickUpLoction.latlng]);
              google.maps.event.addListener(map, 'zoom_changed', function () {
                var zoomChangeBoundsListener = google.maps.event.addListener(map, 'bounds_changed', function (event) {
                  if (map.getZoom() > 14 && map.initialZoom == true) {
                    // Change max/min zoom here
                    map.setZoom(14);
                    map.initialZoom = false;
                  }
                  google.maps.event.removeListener(zoomChangeBoundsListener);
                });
              });
              map.initialZoom = true;
              map.fitBounds(latLngBounds);
              map.initialBoundsBeforPickup = false;
            }
          } else if (orderStateObj.trip_state == 2) {
            //driver arrived
            driverMaker.setIcon('http://duanctest.sinaapp.com/a4c/image/car_blue.png');

            $scope.tripState = $filter('translate')('current_trip.jsAt_pick_up');
            if (orderStateObj.last_address == '') {
              MapService.geocodeLatLng(driverLoction.latlng, function (address) {
                $scope.tripStreet = finalAddress(address);
              }, function (error) {
                console.log('setMapState时地理编码失败,错误: ' + error);
              });
            } else {
              $scope.tripStreet.push(orderStateObj.last_address);
            }
            $scope.stateRemind = $filter('translate')('current_trip.jsArrive');
            if (orderStateObj.trip_cost) {
              // $scope.cost = "Cost: $" + orderStateObj.trip_cost.toFixed(2);
              $scope.cost = $filter('translate')('current_trip.jsCost') + $filter('princeTranslateFilters')(orderStateObj.trip_cost.toFixed(2),false,false,orderStateObj.ccy);
            } else {
              $scope.cost = $filter('translate')('current_trip.jsCost');
            }

            if (TripService.trippingbook.type == 1) {
              var startLatlng = new google.maps.LatLng(driverLoction.latlng);
              var endLatlng = new google.maps.LatLng(dropOffLoction.latlng);
              MapService.getMapMatrixDistanceWithP2p(startLatlng, endLatlng, function (result) {
                var duration = result.duration;
                var nowDate = new Date();
                var etaDate = new Date(nowDate.getTime() + duration * 1000);
                $scope.durationRemind = JSON.stringify(Math.round(duration / 60)) + $filter('translate')('current_trip.jsMinutesRemind',{etaDate:$filter('dateFormatter')(etaDate, "shortTime")});
              }, function (error) {
                //nothing to do...
              });
            } else {
              map.setCenter(driverLoction.latlng);
              $scope.durationRemind = '';
            }
          } else if (orderStateObj.trip_state == 3) {
            //passengers on the trip
            if (!realStartTripTime) {
              realStartTripTime = new Date();
            }
            if (pickUpMaker) {
              pickUpMaker.setMap(null);
            }
            if (TripService.trippingbook.type == 1) {
              if (!dropOffMaker) {
                dropOffMaker = addMarker(dropOffLoction.latlng);
              } else {
                dropOffMaker.setPosition(dropOffLoction.latlng);
              }
            }
            driverMaker.setIcon('http://duanctest.sinaapp.com/a4c/image/car_green.png');

            $scope.tripState = $filter('translate')('current_trip.jsOn_trip');
            if (orderStateObj.last_address == '') {
              MapService.geocodeLatLng(driverLoction.latlng, function (address) {
                $scope.tripStreet = finalAddress(address);
              }, function (error) {
                console.log('setMapState时地理编码失败,错误: ' + error);
              });
            } else {
              var address = JSON.parse(orderStateObj.last_address);
              $scope.tripStreet = finalAddress(address);
            }
            if (orderStateObj.trip_cost) {
              // $scope.cost = "Cost: $" + orderStateObj.trip_cost.toFixed(2);
              $scope.cost = $filter('translate')('current_trip.jsCost')  + $filter('princeTranslateFilters')(orderStateObj.trip_cost.toFixed(2),false,false,orderStateObj.ccy);
            } else {
              $scope.cost = $filter('translate')('current_trip.jsCost');
            }

            if (TripService.trippingbook.type == 1) {
              $scope.stateRemind = $filter('translate')('current_trip.jsArrive');
              var startLatlng = new google.maps.LatLng(driverLoction.latlng);
              var endLatlng = new google.maps.LatLng(dropOffLoction.latlng);
              MapService.getMapMatrixDistanceWithP2p(startLatlng, endLatlng, function (result) {
                var duration = result.duration;
                var nowDate = new Date();
                var etaDate = new Date(nowDate.getTime() + duration * 1000);
                // $scope.durationRemind = JSON.stringify(Math.round(duration / 60)) + " minutes (" + $filter('date')(etaDate, "shortTime") + ")";
                $scope.durationRemind = JSON.stringify(Math.round(duration / 60)) + $filter('translate')('current_trip.jsMinutesRemind',{etaDate:$filter('dateFormatter')(etaDate, "shortTime")});
              }, function (error) {
                //nothing to do...
              });

              if (map.initialBoundsAfterPickup) {
                latLngBounds = makeLatLngBounds([driverLoction.latlng, dropOffLoction.latlng]);
                google.maps.event.addListener(map, 'zoom_changed', function () {
                  var zoomChangeBoundsListener = google.maps.event.addListener(map, 'bounds_changed', function (event) {
                    if (map.getZoom() > 14 && map.initialZoom == true) {
                      // Change max/min zoom here
                      map.setZoom(14);
                      map.initialZoom = false;
                    }
                    google.maps.event.removeListener(zoomChangeBoundsListener);
                  });
                });
                map.initialZoom = true;
                map.fitBounds(latLngBounds);
                map.initialBoundsAfterPickup = false;
              }
            } else {
              $scope.stateRemind = $filter('translate')('current_trip.jsLast');
              var duration = orderStateObj.last_time;
              $scope.durationRemind = JSON.stringify(Math.round(duration / 60)) + $filter('translate')('current_trip.jsMinutes');
              map.setCenter(driverLoction.latlng);
            }
          } else {
            if (TripService.trippingbook.type == 1) {
              if (!dropOffMaker) {
                dropOffMaker = addMarker(dropOffLoction.latlng);
              } else {
                dropOffMaker.setPosition(dropOffLoction.latlng);
              }
            } else {
              map.setCenter(driverLoction.latlng);
            }

            $scope.tripState = $filter('translate')('current_trip.jsARRIVED');
            if (orderStateObj.last_address == '') {
              MapService.geocodeLatLng(driverLoction.latlng, function (address) {
                $scope.tripStreet = finalAddress(address);
              }, function (error) {
                console.log('setMapState时地理编码失败,错误: ' + error);
              });
            } else {
              var address = JSON.parse(orderStateObj.last_address);
              $scope.tripStreet = finalAddress(address);
            }
            $scope.stateRemind = $filter('translate')('current_trip.jsARRIVED');
            if (orderStateObj.trip_cost) {
              $scope.cost = $filter('translate')('current_trip.jsCost') + $filter('princeTranslateFilters')(orderStateObj.trip_cost.toFixed(2),false,false,orderStateObj.ccy);
            } else {
              $scope.cost = $filter('translate')('current_trip.jsCost');
            }

            var nowDate = new Date();
            $scope.durationRemind = $filter('dateFormatter')(nowDate, "shortTime");

            //end trip
            endCurrentTrip();
          }
        }

        //Get order state from remote server
        function getOrderState(successHandle, faultHandle) {
          TripService.refreshOrderState(TripService.trippingbook.id, successHandle, faultHandle);
        }

        //leave current trip
        function leaveCurrentTrip() {
          if (timeout) {
            $timeout.cancel(timeout);
          } else {
            //nothing to do...
          }
          isWatchingTrip = false;
          $scope.isTripping = false;
          cleanCurrentTripData();
        }

        //End trip
        function endCurrentTrip() {
          if (isWatchingTrip == false) {
            return;
          }
          var b_id = TripService.trippingbook.id;

          $timeout.cancel(timeout);
          TripService.endTrip();
          isWatchingTrip = false;

          //alert for end
          var alertPopup = $ionicPopup.alert({
            title: $filter('translate')('current_trip.jsEnd_trip'),
            okText: $filter('translate')('ionicPopup.jsOK')
          });
          alertPopup.then(function (res) {
            cleanCurrentTripData();
            $scope.isTripping = false;
            $state.go('app.trip-feedback', {
              "params": {
                bookingId: b_id,
                driverData: $scope.driverData,
                carName: carName,
                carImg: carImg
              }
            });
          });
        }

        function cleanCurrentTripData() {
          map.setCenter({lat: 34.1017614, lng: -118.3450541});
          map.setZoom(12);
          latLngBounds = undefined;
          pickUpLoction = undefined;
          dropOffLoction = undefined;
          driverLoction = undefined;
          realStartTripTime = undefined;
          if (pickUpMaker) {
            pickUpMaker.setMap(null);
            pickUpMaker = undefined;
          }
          if (dropOffMaker) {
            dropOffMaker.setMap(null);
            dropOffMaker = undefined;
          }
          if (driverMaker) {
            driverMaker.setMap(null);
            driverMaker = undefined;
          }
        }

        function finalAddress(address) {
          var data = address.address_components;
          var finalAddressDate = [];

          //处理第一行
          //格式:'street_address route premise political'
          var line_1 = '';
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'street_number') {
              line_1 += data[i].long_name + '  ';
              break;
            }
          }
          var hasRoute = false;
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'route') {
              line_1 += data[i].long_name + ' ';
              hasRoute = true;
              break;
            }
          }

          if (!hasRoute) {
            for (var i = 0; i < data.length; i++) {
              if (data[i].types[0] == 'street_address') {
                line_1 += data[i].long_name + ' ';
                break;
              }
            }
          }

          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'premise') {
              line_1 += data[i].long_name + ' ';
              break;
            }
          }
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'political') {
              line_1 += data[i].long_name + ' ';
              break;
            }
          }
          finalAddressDate.push(line_1);

          //处理第二行
          //格式:'locality,administrative_area_level_1 postal_code'
          var line_2 = '';
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'locality') {
              line_2 += data[i].long_name;
              break;
            }
          }
          var hasState = false;
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'administrative_area_level_1') {
              line_2 += ',' + data[i].short_name;
              hasState = true;
              break;
            }
          }
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'postal_code') {
              if (hasState) {
                line_2 += ' ' + data[i].long_name;
              } else {
                line_2 += ',' + data[i].long_name;
              }
              break;
            }
          }
          finalAddressDate.push(line_2);
          return finalAddressDate;
        }
      });
})();
