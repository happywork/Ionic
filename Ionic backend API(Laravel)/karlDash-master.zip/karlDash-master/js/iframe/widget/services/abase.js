/**
 * Created by wangyaunzhi on 16/11/26.
 */
'use strict';
angular.module('Widget.Services', []);