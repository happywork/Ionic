// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('passengerApp', ['ionic', 'ionic.service.core',
  'ion-google-place','pascalprecht.translate',
  'ngStorage', 'ngCordova', 'uiGmapgoogle-maps',
  'ngMessages', 'passengerApp.services',
  'passengerApp.filters', 'passengerApp.AppController',
  'ionic-ratings', 'ionic.rating', "ion-datetime-picker",
  'ui.bootstrap','passengerApp.dateFilters','passengerApp.princeFilters'])

  .run(function ($ionicPlatform, $location, $ionicPopup, $rootScope, $timeout,
                 AppService,LocationService,StorageService,
                 ContactService,$filter) {
    $ionicPlatform.ready(function () {
      if (window.cordova && window.cordova.plugins.Keyboard) {
        $ionicPlatform.registerBackButtonAction(function () {
          //nothing to do
        }, 101);

        if (window.cordova.InAppBrowser) {
          window.open = window.cordova.InAppBrowser.open;
        }
        /*
        window.mixpanel.init('5bf8887a3803e42dcd780e75770d4173', function () {
          console.log('mixpanel init success');
        }, function () {
          console.log('mixpanel init fail');
        });
        */
        
        // window.ga.startTrackerWithId('UA-89070126-1');
        // window.ga.trackView('Screen Title');
        // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
        // for form inputs)
        cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

        // Don't remove this line unless you know what you are doing. It stops the viewport
        // from snapping when text inputs are focused. Ionic handles this internally for
        // a much nicer keyboard experience.
        cordova.plugins.Keyboard.disableScroll(true);


        if (cordova.plugins.Keyboard.isVisible) {
          cordova.plugins.Keyboard.closeKeyboard();
        }

        window.cordova.getAppVersion.getVersionNumber(function (v) {
          //IOS上,是3位,比如1.0.7
          //安卓上,是4为,比如1.0.7.0
          var version = v.substr(0, 5);
          var android = 'android';
          var ios = 'ios';
          window.cordova.getAppVersion.getAppName(function (name) {
            if ($ionicPlatform.is(android)) {
              AppService.checkAppUpdateService(version, android, name);
            } else {
              AppService.checkAppUpdateService(version, ios, name);
            }
          }, function (error) {
          });
        }, function (error) {
        });
      }

      if (window.StatusBar) {
        StatusBar.styleLightContent();
      }

      LocationService.getCurrentPosition(function (position) {
        console.log("position is ",position)
      }, function (error) {
      });


      ContactService.getCompanyInfo(function (response) {
        console.log("contact service is ",response.result);
        StorageService.setCompanyInfo(response.result);
      }, function (errorString, response) {
          if(errorString){
            $ionicPopup.alert({
              title: errorString,
              okText: $filter('translate')('ionicPopup.jsOK')
            });
          }else {
            $ionicPopup.alert({
              title: $filter('translate')('need_help.jsRequest_fault'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
          }
      })

    });
  })

  .config(function ($translateProvider ) {
    $translateProvider
      .useStaticFilesLoader({
        prefix:'languages/',
        suffix:'.json'
      })

      .registerAvailableLanguageKeys(['en', 'zh','fr'], {
        'en_*': 'en',
        "zh_*": 'zh',
        "fr_*": 'fr',
        '*': 'en'
      })

      .determinePreferredLanguage()

      .fallbackLanguage('en')

      .useSanitizeValueStrategy('escapeParameters');


    var lang;
    // todo
    if(localStorage.getItem("lang")){
      lang=localStorage.getItem("lang");
    }else {
      lang=$translateProvider.preferredLanguage()
      if(lang != 'en'&&lang != 'fr'){
        lang = 'en'
      }
      localStorage.setItem("lang",lang);
    }


    $translateProvider.preferredLanguage(lang);
    moment.locale(lang);
    console.log('momentLang is ', moment.locale());

    console.log('dateLang is ', lang);

  })

  .config(function ($stateProvider, $urlRouterProvider, $ionicConfigProvider) {
    $ionicConfigProvider.backButton.text("");
    $ionicConfigProvider.backButton.previousTitleText(false);
    $stateProvider
      .state('app', {
        cache: false,
        url: '/app',
        abstract: true,
        templateUrl: 'templates/menu.html',
        controller: 'AppCtrl'
      })
      .state('login', {
        url: '/login',
        templateUrl: 'templates/login.html',
        controller: 'LoginCtrl'
      })
      .state('section', {
        url: '/section',
        templateUrl: 'templates/section.html',
        controller: 'SectionCtrl'
      })
      .state('signup', {
        cache: false,
        url: '/signup',
        templateUrl: 'templates/signup.html',
        controller: 'SignupCtrl'
      })
      .state('need-help', {
        url: '/need-help',
        templateUrl: 'templates/need-help.html',
        controller: 'NeedHelpCtrl'
      })
      .state('app.easybook', {
        url: '/easybook',
        views: {
          'menu-content': {
            templateUrl: 'templates/easybook.html',
            controller: 'EasybookCtrl'
          }
        }
      })
      .state('app.map-locate', {
        params: {"locateType": ""},
        url: '/map-locate',
        views: {
          'menu-content': {
            templateUrl: 'templates/map-locate.html',
            controller: 'MapLocateCtrl'
          }
        }
      })
      .state('app.easybook-cars', {
        params: {
          "offers": [],
          "is_airport": {}
        },
        url: '/easybook-cars',
        views: {
          'menu-content': {
            templateUrl: 'templates/easybook-cars.html',
            controller: 'EasybookCarsCtrl'
          }
        }
      })
      .state('app.easybook-return-cars', {
        params: {
          "offers": [],
          "car": {},
          "appointedTime": '',
          'passengerNumber': '',
          'passengers': [],
          'bagNumber': '',
          'cache': '',
          "is_airport": {}
        },
        url: '/easybook-return-cars',
        views: {
          'menu-content': {
            templateUrl: 'templates/easybook-return-cars.html',
            controller: 'EasybookReturnCarsCtrl'
          }
        }
      })
      .state('app.easybook-payment', {
        cache: false,
        url: '/easybook-payment',
        views: {
          'menu-content': {
            templateUrl: 'templates/easybook-payment.html',
            controller: 'EasybookPaymentCtrl'
          }
        }
      })

      .state('app.add-payment', {
        url: '/add-payment',
        views: {
          'menu-content': {
            templateUrl: 'templates/add-payment.html',
            controller: 'AddPaymentCtrl'
          }
        }
      })
      .state('app.contact', {
        url: '/contact',
        views: {
          'menu-content': {
            templateUrl: 'templates/contact.html',
            controller: 'ContactCtrl'
          }
        }
      })
      .state('app.current-trip', {
        url: '/current-trip',
        views: {
          'menu-content': {
            templateUrl: 'templates/current-trip.html',
            controller: 'TripCtrl'
          }
        }
      })
      .state('app.trip-feedback', {
        cache: false,
        params: {"params": {}},
        url: '/trip-feedback',
        views: {
          'menu-content': {
            templateUrl: 'templates/trip-feedback.html',
            controller: 'TripFeedBackCtrl'
          }
        }
      })
      .state('app.profile', {
        url: '/profile',
        cache: false,
        views: {
          'menu-content': {
            templateUrl: 'templates/profile.html',
            controller: 'ProfileCtrl'
          }
        }
      })
      .state('app.rides', {
        url: '/rides',
        views: {
          'menu-content': {
            templateUrl: 'templates/rides.html',
            controller: 'RidesCtrl'
          }
        }
      })
      .state('app.card-list', {
        url: '/card-list',
        views: {
          'menu-content': {
            templateUrl: 'templates/card-list.html',
            controller: 'CreditCardsCtrl'
          }
        }
      })
      .state('multilingual', {
        url: '/multilingual',
        templateUrl: 'templates/multilingual.html',
        controller: 'MultilingualCtrl'
      });
    // .state('app.billing-address-map', {
    //   params: {"locateType": ""},
    //   url: '/billing-address-map',
    //   views: {
    //     'menu-content': {
    //       templateUrl: 'templates/billing-address-map.html',
    //       controller: 'billingAddressMapCtrl'
    //     }
    //   }
    // });
    $urlRouterProvider.otherwise('/login');

  });
