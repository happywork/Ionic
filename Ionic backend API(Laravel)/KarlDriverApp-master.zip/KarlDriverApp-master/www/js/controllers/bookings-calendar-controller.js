(function () {
  "use strict";

  angular.module('starter').controller('BookingsCalendarCtrl',
    function ($scope, $ionicPopup, $filter, $state, $timeout, $ionicLoading, CalendarService, BookingsService,LoginService,UserService) {
      var dayGroupEvents = {};
      $scope.showCalendar = true;
      $scope.events = [];
      $scope.eventSources = [$scope.events];
      $scope.bookings = [];
      $scope.selectDate = undefined;
      var preDayCell;

      $scope.initEvent = function (date) {
        $scope.events.length = 0;
        var isFirst = true;
        angular.forEach(dayGroupEvents, function (value, key) {
          var year = new Date(key).getUTCFullYear();
          var month = new Date(key).getUTCMonth() + 1;
          var day = new Date(key).getUTCDate();
          var string = year + '/' + month + '/' + day;
          var keyDate = new Date(string);
          if (date.getFullYear() == keyDate.getFullYear() && date.getMonth() == keyDate.getMonth()) {
            //本月数据
            if (date.getDate() <= keyDate.getDate()) {
              //今天及以后
              if (isFirst) {
                $scope.events.push({
                  id: key,
                  title: value.length,
                  start: keyDate,
                  borderColor: "transparent",
                  backgroundColor: "red"
                });
                isFirst = false;
                $scope.bookings = dayGroupEvents[key];
              } else {
                $scope.events.push({
                  id: key,
                  title: value.length,
                  start: keyDate,
                  borderColor: "transparent"
                });
              }
            } else {
              //今天以前
              $scope.events.push({
                id: key,
                title: value.length,
                borderColor: "transparent",
                start: keyDate
              });
            }
          } else {
            //其他月份
            $scope.events.push({
              id: key,
              title: value.length,
              borderColor: "transparent",
              start: keyDate
            });
          }
        });
      };

      $scope.addEvent = function () {
        $state.go("app.event-add");
      };

      $scope.onNavCalendarClick = function () {
        $scope.showCalendar = true;
      };

      /* alert on eventClick */
      $scope.onEventClick = function (event, jsEvent, view) {
        $scope.bookings = dayGroupEvents[event.id];

        $("a.fc-day-grid-event").css('background-color', '');
        angular.element(this).css('background-color', 'red');
        preDayCell = this;
      };

      $scope.onDayClick = function (date, jsEvent, view) {
        var day = $filter('date')(date._d, "yyyy-MM-dd");
        if (dayGroupEvents[day]) {
          $scope.bookings = dayGroupEvents[day];

          $("a.fc-day-grid-event").css('background-color', '');
          $("a.fc-day-grid-event-" + day).css('background-color', 'red');
        }
      };

      $scope.deleteEvent = function (event, repeat, eventPopup) {
        console.log(event, repeat, eventPopup);
        $ionicPopup.confirm({
          title: $filter('translate')('calendar.jsDelete_event'),
          template: $filter('translate')('calendar.jsSure'),
          okText: $filter('translate')('ionicPopup.jsOK'),
          cancelText:$filter('translate')('ionicPopup.jsCancel')
        })
          .then(function (res) {
            if (res) {
              eventPopup.close();
              CalendarService.deleteCalendarEvent(event.id,
                {
                  repeat: repeat
                }, function (response) {
                  // eventPopup.close();
                  if ($scope.selectDate) {
                    loadData($scope.selectDate);
                  } else {
                    loadData(new Date());
                  }
                }, function (errorString,response) {
                  if(!LoginService.logoutWhenAuthExpired(response.code)){
                    console.log(errorString)
                  }else {
                    $ionicPopup.alert({
                      title: errorString,
                      okText: $filter('translate')('ionicPopup.jsOK')
                    });
                  }
                });
            }
          });

      };

      $scope.onBookRowClick = function (bookId) {
        $scope.event = $scope.bookings[bookId];
        $scope.event.delete = function (event, repeat) {
          $scope.deleteEvent(event, repeat, eventPopup);
        };
        $scope.event.getRepeatType = function (type) {
          if (type == 0) {
            return $filter('translate')('calendar.jsDay');

          } else if (type == 1) {
            return $filter('translate')('calendar.jsWeek');
          }
          else if (type == 2) {
            return $filter('translate')('calendar.jsMonth');
          }
          else if (type == 3) {
            return $filter('translate')('calendar.jsYear');
          }
          else {
            return $filter('translate')('calendar.jsNo_repeat');
          }
        };
        var eventPopup = $ionicPopup.show({
          templateUrl: "templates/event-popup.html",
          title: $filter('translate')('calendar.jsEvent'),
          scope: $scope,
          cssClass: "driveCalendarPopup",
          buttons: [
            {
              text: $filter('translate')('calendar.jsBack'),
              onTap: function () {
              }
            }
          ]
        })
      };

      /* config object */
      console.log($filter('translate')('fullCalendar_lang'))
      var initConfig = function () {
        $scope.uiConfig = {
          calendar: {
            height: 410,
            editable: false,
            timezone: 'local',
            lang: $filter('translate')('fullCalendar_lang'),
            timeFormat: ' ',
            header: {
              left: 'title',
              center: '',
              right: 'today prev,next'
            },
            eventClick: $scope.onEventClick,
            dayClick: $scope.onDayClick,
            nextChange: function (date) {
              $timeout(function () {
                if (date._d.getFullYear() == new Date().getFullYear() && date._d.getMonth() == new Date().getMonth()) {
                  loadData(new Date());
                  $scope.selectDate = new Date();
                } else {
                  loadData(date._d);
                  $scope.selectDate = date._d;
                }
              }, 0);
            }
          }
        };
      };

      function loadData(date) {
        $ionicLoading.show({
          template: $filter('translate')('calendar.jsLoading')
        });

        var year = date.getFullYear();
        var month = date.getMonth();
        var startDayOfMonth = new Date(year, month, 1);
        var endDayOfMonth = new Date(year, month + 1, 1);
        var requestParame = {
          "start_time": startDayOfMonth.getTime() / 1000,
          "end_time": endDayOfMonth.getTime() / 1000
        };
        BookingsService.loadBookingEvents(requestParame, function (result) {
          $ionicLoading.hide();
          if (result.code == 2100) {
            $scope.bookings = [];
          } else {
            dayGroupEvents = {};
            angular.forEach(result.result.events, function (item) {
              var startTime = new Date(item.start_time * 1000);
              var endTime = new Date(item.end_time * 1000);
              while (true) {
                var startDay = $filter('date')(startTime, "yyyy-MM-dd");
                var endDay = $filter('date')(endTime, "yyyy-MM-dd");
                var day = startDay;
                var dayGroup = dayGroupEvents[day];
                if (!dayGroup) {
                  dayGroup = [];
                  dayGroupEvents[day] = dayGroup;
                }
                dayGroup.push(item);
                startTime.setDate(startTime.getDate() + 1);
                if (startDay == endDay) {
                  break;
                }
              }
            });
            $timeout(function () {
              $scope.initEvent(date);
            }, 0);
          }
        }, function (errorString,response) {
          $ionicLoading.hide();
          LoginService.logoutWhenAuthExpired(response.code);
        });
      }

      // Init
      $timeout(function () {
        initConfig();
      }, 0);

      $scope.$on('$ionicView.enter', function () {
        if ($scope.selectDate) {
          loadData($scope.selectDate);
        } else {
          loadData(new Date());
        }
      });
    });
})();
