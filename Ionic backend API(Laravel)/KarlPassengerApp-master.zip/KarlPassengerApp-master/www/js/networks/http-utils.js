var HttpUtils = {
  //ADDED by Abel: but I am not sure if this is correct way..(Do we need this???)
  patch: function ($http, url, params, successHandler, faultHandler) {
    //console.log(params);
    $http({
        method: 'PATCH',
        url: url + "?" + HttpUtils.obj2params(params,url,'PATCH'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        responseType: 'json',
        timeout: 30000
      }
    ).then(successHandler, faultHandler);
  },
  post: function ($http, url, params, successHandler, faultHandler) {
    var timeout = 30000;
    if(url == Api.booking){
      timeout = 120000
    }
    $http({
        method: 'POST',
        url: url,
        data: HttpUtils.obj2params(params,url,'POST'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        responseType: 'json',
        timeout: timeout
      }
    ).then(successHandler, faultHandler);
  },
  get: function ($http, url, params, successHandler, faultHandler) {
    $http({
      method: 'GET',
      url: url + "?" + HttpUtils.obj2params(params,url,'GET'),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      responseType: 'json',
      timeout: 30000
    }).then(successHandler, faultHandler);
  },

  delete: function ($http, url, param, successHandler, faultHandler) {
    $http({
      method:'DELETE',
      url:url+"?"+HttpUtils.obj2params(param,url,'DELETE'),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      responseType: 'json',
      timeout: 30000
    }).then(successHandler,faultHandler);
  },

  obj2params: function (obj,url,method) {
    if((url == Api.booking && method == 'POST') || url === Api.profileUpdate){
      var requestData = 'token='+obj.token+'&'+'param='+encodeURIComponent(JSON.stringify(obj));
      return requestData;
    } else {
      var p = [];
      for (var key in obj) {
        p.push(key + '=' + encodeURIComponent(obj[key]));
      }
      return p.join('&');
    }
  }
};
