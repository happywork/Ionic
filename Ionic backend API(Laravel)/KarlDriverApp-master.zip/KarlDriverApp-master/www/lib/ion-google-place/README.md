ion-google-place
================

Ionic directive for a location dropdown that utilizes google maps
