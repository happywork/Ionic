<?php
/**
 * Created by PhpStorm.
 * User: lqh
 * Date: 2017/7/6
 * Time: 上午9:59
 */

return [
    "driverEvents"=>"Service de voiture pour :clientName qui dure :time",
    "carEvent"=>":driverName : Service de voiture pour :clientName qui dure :time",
];