StripeInfo={
    card_url:'https://api.stripe.com/v1/tokens',
    publish_key : 'pk_test_35LHI3hox2oHsF8FeU3LE6X0'
};


WebsiteUrl = "http://test.karl.limo";
DashboardUrl ='http://test.karldash.com';
