/**
 * Created by liqihai on 16/9/13.
 */
// IIFE START //
(function () {
  'use strict';

  angular.module('passengerApp')
    .controller("CreditCardsCtrl", function ($scope, $timeout, $ionicLoading, $ionicPopup, $ionicScrollDelegate, $state, $ionicHistory,CreditCardsService,LoginService,$filter) {

      $scope.$on('$ionicView.enter', function () {
        $scope.listCreditCards();
      });

      $scope.addNewCards = function () {
        $state.go('app.add-payment')
      };

      $scope.cardImg = {
        1:"img/card-visa.png",
        2:"img/card-mastercard.png",
        3:"img/card-american-express.png",
        4:"img/card-discover.png"
      };

      $scope.listCreditCards = function () {
        $ionicLoading.show();
        CreditCardsService.getMyCards(
          function (result) {
            $ionicLoading.hide();
            if(result.code == 2000){
              $scope.cardList = result.result;
            }else{
              //2100
              $scope.cardList = null;
            }
          }, function (errorString,response) {
            $ionicLoading.hide();
            if(!LoginService.logoutWhenAuthExpired(response.code)){
              $scope.cardList = null;
              if(errorString){
                $ionicPopup.alert({
                  title:errorString,
                  okText: $filter('translate')('ionicPopup.jsOK')
                }).then(function (res) {
                  $ionicHistory.goBack();
                });
              }else {
                $ionicPopup.alert({
                  title:$filter('translate')('card_list.jsTip_info'),
                  okText: $filter('translate')('ionicPopup.jsOK')
                }).then(function (res) {
                  $ionicHistory.goBack();
                });
              }
            }
          }
        );
      };

      $scope.deleteCard  = function (card) {
        var alert = $ionicPopup.confirm({
          title: $filter('translate')('card_list.jsDelete_tip', {card_number: card.card_number}),
          okText:$filter('translate')('card_list.jsYes'),
          okType:'button-positive',
          cancelText:$filter('translate')('card_list.jsNo'),
          cancelType:'button-default'
        });
        alert.then(function (res) {
            if(res){
              $ionicLoading.show();
              CreditCardsService.deleteCard(card.card_token,
                function () {
                  alert.close();
                  $ionicLoading.hide();
                  $scope.listCreditCards();
                }, function (errorString,response) {
                  alert.close();
                  $ionicLoading.hide();
                  if(!LoginService.logoutWhenAuthExpired(response.code)){
                    if(response.code == 3301){
                      $ionicPopup.alert({
                        title:$filter('translate')('card_list.jsCard_not_exist'),
                        okText: $filter('translate')('ionicPopup.jsOK')
                      });
                    }else {
                      if(errorString){
                        $ionicPopup.alert({
                          title:errorString,
                          okText: $filter('translate')('ionicPopup.jsOK')
                        });
                      } else {
                        $ionicPopup.alert({
                          title:$filter('translate')('card_list.jsDelete_card_fault'),
                          okText: $filter('translate')('ionicPopup.jsOK')
                        });
                      }
                    }
                  }
                });
            }
        });




      }
    });
})();
