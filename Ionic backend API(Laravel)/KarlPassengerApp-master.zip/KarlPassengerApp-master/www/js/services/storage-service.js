(function () {
  'use strict';

  angular.module('passengerApp')
    .service('StorageService', function () {
      this.setItem = function (name, data) {
        localStorage.setItem(name,data);
      };
      this.getItem = function (name) {
        return localStorage.getItem(name);
      };

      this.getCompanyInfo = function(){
        return JSON.parse(this.getItem("companyInfo"))
      };

      this.setCompanyInfo= function (companyInfo) {
        this.setItem("companyInfo",JSON.stringify(companyInfo))
      };
      this.setUserInfo = function (user) {
        this.setItem("userInfo",JSON.stringify(user))
      };
      this.getUserInfo = function () {
        var info = this.getItem("userInfo");
        if(info === "" || info === null){
          return null;
        }
        return JSON.parse(info)
      };

      this.cleanUserInfo = function () {
        this.setItem("userInfo","");
      };

      this.getBillingAddress = function () {
        var billingAddress = this.getItem("billingAddress");
        if(billingAddress === "" || billingAddress === null){
          return null;
        }
        return JSON.parse(billingAddress)
      };
      this.setBillingAddress = function (address) {
        return this.getItem("billingAddress",JSON.stringify(address))
      };

      this.cleanBillAddress = function () {
        this.setItem("billingAddress","");
      };
      this.getLang = function () {
        return this.getItem("lang")
      };
      this.setLang = function (lang) {
        this.setItem("lang",lang);
      };
      this.setPosition = function(position){
        this.setItem("position",JSON.stringify(position));
      };
      this.getPosition = function(){
        return JSON.parse(this.getItem("position"));
      };
      this.getLocationHistories = function () {
        var history = this.getItem("localHistory");
        if(history === "" || history === null){
          return null;
        }
        return JSON.parse(history)
      };
      this.setLocationHistories = function (histories) {
        this.setItem("localHistory",JSON.stringify(histories));
      };
      this.setRegion = function (region) {
        this.setItem("region",region);
      };
      this.cleanRegion = function () {
        this.setItem("region","");
      };
      this.getRegion = function () {
        var region = this.getItem("region");
        if(region === "" || region === null){
          return null;
        }
        return JSON.parse(region)
      }
    });

})();
