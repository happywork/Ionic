angular.module('passengerApp.services',[])
  .factory('HttpService', function ($http,UserService,$filter) {
    return {
      get: function (url, params, successHandler, faultHandler) {
        var loginUser = UserService.getLoginUser();
        if(loginUser){
          params.token = loginUser.token;
        }
        HttpUtils.get($http, url, params, function (response) {
          if (response.data == null) {
            if (faultHandler) {
              faultHandler(null,{code:''});
            }
            return;
          }

          if (response.data.code >= 2000 && response.data.code < 3000) {
            if (successHandler) {
              successHandler(response.data);
            }
          } else {
            var errMsg = $filter('translate')(response.data.code);
            if(errMsg*1){
              errMsg=false
            }
            if(response.data.code == 3808 || response.data.code == 3809 || response.data.code == 3810){
              errMsg = errMsg.replace('company_name',loginUser.company_name);
              errMsg = errMsg.replace('company_phone',loginUser.company_phone1);
            }
            if (faultHandler) {
              faultHandler(errMsg, response.data);
            }
          }
        }, function (error) {
          if (faultHandler) {
            faultHandler(null,{code:''});
          }
        });
      },

      post: function (url, params, successHandler, faultHandler) {
        var loginUser = UserService.getLoginUser();
        if(loginUser){
          params.token = loginUser.token;
        }
        HttpUtils.post($http, url, params, function (response) {
          if (response.data == null) {
            if (faultHandler) {
              faultHandler(null,{code:''});
            }
            return;
          }

          if (response.data.code >= 2000 && response.data.code < 3000) {
            if (successHandler) {
              successHandler(response.data);
            }
          } else {
            var errMsg = $filter('translate')(response.data.code);
            if(errMsg*1){
              errMsg=false
            }
            if (faultHandler) {
              faultHandler(errMsg, response.data);
            }
          }
        }, function (error) {
          if (faultHandler) {
            faultHandler(null,{code:''});
          }
        });
      },

      patch: function (url, params, successHandler, faultHandler) {
        var loginUser = UserService.getLoginUser();
        if(loginUser){
          params.token = loginUser.token;
        }
        HttpUtils.patch($http, url, params, function (response) {
          if (response.data == null) {
            if (faultHandler) {
              faultHandler(null,{code:''});
            }
            return;
          }

          if (response.data.code >= 2000 && response.data.code < 3000) {
            if (successHandler) {
              successHandler(response.data);
            }
          } else {
            var errMsg = $filter('translate')(response.data.code);
            if(errMsg*1){
              errMsg=false
            }
            if (faultHandler) {
              faultHandler(errMsg, response.data);
            }
          }
        }, function (error) {
          if (faultHandler) {
            faultHandler(null,{code:''});
          }
        });
      },

      delete: function (url, params, successHandler, faultHandler) {
        var loginUser = UserService.getLoginUser();
        if(loginUser){
          params.token = loginUser.token;
        }
        params.token = loginUser.token;
        HttpUtils.delete($http, url, params, function (response) {
          if (response.data == null) {
            if (faultHandler) {
              faultHandler(null,{code:''});
            }
            return;
          }

          if (response.data.code >= 2000 && response.data.code < 3000) {
            if (successHandler) {
              successHandler(response.data);
            }
          } else {
            var errMsg = $filter('translate')(response.data.code);
            if(errMsg*1){
              errMsg=false
            }
            if (faultHandler) {
              faultHandler(errMsg, response.data);
            }
          }
        }, function (error) {
          if (faultHandler) {
            faultHandler(null,{code:''});
          }
        });
      }
    }
  });

