// ApiServer = {
//     serverUrl: "http://192.168.137.1:804",
//     version: "/1",
//     learnmoreUrl:"http://test.karl.limo",
//     flowUrl:"http://test.karldash.com",
//     timeout:120000,
//     env:"tst",
//     stripeClientId : 'ca_An6OlgDObyhhW7csaDsTsmzfUiyTEmEN',
//     repSalesId: 'EASYSIGNUP'
// };

//serverUrl: "http://test.api.karldash.com",
//serverUrl: "http://127.0.0.1:805",
ApiServer = {
    serverUrl: "http://test.api.karldash.com",
    version: "/1",
    learnmoreUrl:"http://test.karl.limo",
    flowUrl:"http://test.karldash.com",
    timeout:120000,
    env:"tst",
    stripeClientId : 'ca_An6OlgDObyhhW7csaDsTsmzfUiyTEmEN',
    repSalesId: 'EASYSIGNUP'
};
