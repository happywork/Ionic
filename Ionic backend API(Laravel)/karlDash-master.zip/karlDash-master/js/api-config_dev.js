ApiServer = {
    serverUrl: "https://dev.api.karldash.com",
    version: "/1",
    learnmoreUrl:"http://dev.karl.limo",
    flowUrl:"http://dev.karldash.com",
    timeout:120000,
    env:"dev",
    stripeClientId : 'ca_9P5fUNpkEydzuc4SweK0vNf3QlQD5mzj',
    repSalesId: 'EASYSIGNUP'

};
