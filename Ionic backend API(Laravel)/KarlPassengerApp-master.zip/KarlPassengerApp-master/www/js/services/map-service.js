(function() {
  'use strict';

  angular.module('passengerApp')
    .service('MapService', function(HttpService) {

      //initiating Service inside here its self
      var self = this;

      self.calculateAndDisplayRoute = function(
        directionsService,
        startLatLng,endLatLng,
        timestamp,resultFunction) {
        var date = new Date();
        date.setTime(timestamp*1000)
        directionsService.route({
          origin: startLatLng,
          destination: endLatLng,
          travelMode: google.maps.TravelMode.DRIVING,
          drivingOptions:{
            departureTime:date
          }
        }, function(response, status) {
          if(resultFunction){
            resultFunction(response, status)
          }
        });
      };

      self.calculateAndDrawPolyline = function(map,directionsService,startLatLng,endLatLng) {
        directionsService.route({
          origin: startLatLng,
          destination: endLatLng,
          travelMode: google.maps.TravelMode.DRIVING
        }, function(response, status) {
          if (status === google.maps.DirectionsStatus.OK) {
            console.log(response);
            var flightPath = new google.maps.Polyline({
              path: response.routes[0].overview_path,
              geodesic: true,
              strokeColor: 'green',
              strokeOpacity: 1.0,
              strokeWeight: 5
            });
            flightPath.setMap(map);
          }else {
            console.log('Directions request failed due to ' + status);
          }
        });
      };

      self.hideRoute = function(directionsDisplay){
        directionsDisplay.setMap(null);
      };

      self.geocodeLatLng = function (latlng, successHandle, faultHandle) {
        var geocoder = new google.maps.Geocoder;
        geocoder.geocode({'location': latlng}, function (results, status) {
          if (status === google.maps.GeocoderStatus.OK) {
            if (results[0]) {
              var location = results[0];
              location.geometry.location = {
                lat:location.geometry.location.lat(),
                lng:location.geometry.location.lng()
              };
              successHandle(location);
            } else {
              faultHandle('No results found');
            }
          } else {
            faultHandle('Geocoder failed due to: ' + status);
          }
        });
      };

      //Computing distance and duration between startPoint and endPoint by "DRIVING" model
      self.getMapMatrixDistanceWithP2p = function (startLatlng,endLatlng,sucessHandle,faultHandle) {
        var origins = [startLatlng];
        var destinations = [endLatlng];
        var travelMode = "DRIVING";
        var distanceMatrixService = new google.maps.DistanceMatrixService;
        distanceMatrixService.getDistanceMatrix({
          origins:origins,
          destinations:destinations,
          travelMode: google.maps.TravelMode[travelMode]
        }, function(response, status){
          if(status == google.maps.DistanceMatrixStatus.OK){
            if(sucessHandle){
              var result = {"distance":response.rows[0].elements[0].distance.value,"duration":response.rows[0].elements[0].duration.value};
              sucessHandle(result);
            }
          }else  {
            if (faultHandle){
              faultHandle(status);
            }
          }
        });
      };

      self.getMapMatrixDistancesWithPoints = function (startLatlngs,endLatlngs,sucessHandle,faultHandle) {
        var distanceMatrixService = new google.maps.DistanceMatrixService;
        distanceMatrixService.getDistanceMatrix({
          origins:startLatlngs,
          destinations:endLatlngs,
          travelMode: google.maps.TravelMode["DRIVING"]
        }, function(response, status){
          if(status == google.maps.DistanceMatrixStatus.OK){
            if(sucessHandle){
              sucessHandle(response.rows);
            }
          }else  {
            if (faultHandle){
              faultHandle(status);
            }
          }
        });
      };

      self.getFlightsList = function (lat,lng,type,time,successHandle,faultHandle) {
        HttpService.get(Api.getFlightsList,{
          "lat":lat,
          "lng":lng,
          "type":type,
          "time":time
        }, successHandle, faultHandle);
      }
    });

})();
