(function () {
  'use strict';

  angular.module('passengerApp')
    .controller('EasybookCtrl',
      function ($stateParams, $scope, $state,
                $ionicSlideBoxDelegate, $ionicModal, $ionicActionSheet, $ionicPopup, $ionicLoading, $ionicScrollDelegate, $filter, $timeout, UserService, MapService, EasybookService, LocationService, LoginService, StorageService, $ionicPlatform) {

        if (window.cordova && window.cordova.plugins.Keyboard) {
          //监听键盘事件
          window.addEventListener('native.keyboardshow', keyboardShowHandler);
          window.addEventListener('native.keyboardhide', keyboardHideHandler);
        }

        $scope.pickerTitle = $filter('translate')('easybook.jsPickerTitle');
        $scope.buttonOk = $filter('translate')('easybook.jsButtonOk');
        $scope.buttonCancel = $filter('translate')('easybook.jsButtonCancel');
        
        var estDistance = 0;
        var estDuration = 0;

        function cleanData() {
          $scope.aIsAirport = false;
          dAirLineObj = undefined;
          dAirFlightObj = undefined;
          dAirLineObjList = undefined;

          $scope.dIsAirport = false;
          aAirLineObj = undefined;
          aAirFlightObj = undefined;
          aAirLineObjList = undefined;

          estDistance = 0;
          estDuration = 0;

          lastSelectPickupAddress = undefined;
          lastSelectDropoffAddress = undefined;

          $scope.pickupLocation = undefined;
          EasybookService.savePickupLocation(undefined);
          $scope.dropoffLocation = undefined;
          EasybookService.saveDropoffLocation(undefined);
        }

        function keyboardShowHandler(e) {
          $('.popup-container').children('.popup').css('margin-top', -window.screen.availHeight * 0.35 + 'px');
        }

        function keyboardHideHandler() {
          $('.popup-container').children('.popup').css('margin-top', 0 + 'px');
        }

        var lastSelectPickupAddress = undefined;
        var lastSelectDropoffAddress = undefined;
        $scope.$on('$ionicView.beforeEnter', function () {
          $scope.pickupLocation = EasybookService.getPickupLocation();
          $scope.dropoffLocation = EasybookService.getDropoffLocation();

          if (currentLocateType == 'pickup') {
            //处理起点airportpop
            if ($scope.pickupLocation && lastSelectPickupAddress != $scope.pickupLocation.address.formatted_address) {
              dAirLineObj = undefined;
              dAirLineObjList = undefined;
              dAirFlightObj = undefined;
              if ($scope.pickupLocation.address.isAirport) {
                $scope.dIsAirport = true;
                showAirportPop(0);
                var time = (Date.parse($scope.dateAndTime.dateAndTime) + "").substr(0, 10);
                MapService.getFlightsList($scope.pickupLocation.lat, $scope.pickupLocation.lng, 0, time, function (result) {
                  console.log(result);
                  if (result.code == '2000') {
                    dAirLineObjList = result.result;
                    $scope.editAirport.airLineObjList = dAirLineObjList;
                  }
                }, function (error) {
                  console.log(error);
                });
              } else {
                $scope.dIsAirport = false;
              }
            } else {
              //nothing to do
            }
            if ($scope.pickupLocation) {
              lastSelectPickupAddress = $scope.pickupLocation.address.formatted_address;
            }
          } else if (currentLocateType == 'dropoff') {
            //处理终点airportpop
            if ($scope.dropoffLocation && lastSelectDropoffAddress != $scope.dropoffLocation.address.formatted_address) {
              aAirLineObj = undefined;
              aAirLineObjList = undefined;
              aAirFlightObj = undefined;
              if ($scope.dropoffLocation.address.isAirport) {
                $scope.aIsAirport = true;
                showAirportPop(1);
                var time = (Date.parse($scope.dateAndTime.dateAndTime) + "").substr(0, 10);
                console.log('mapservice', MapService);
                MapService.getFlightsList($scope.dropoffLocation.lat, $scope.dropoffLocation.lng, 0, time, function (result) {
                  console.log(result);
                  if (result.code == '2000') {
                    aAirLineObjList = result.result;
                    $scope.editAirport.airLineObjList = aAirLineObjList;
                  }
                }, function (error) {
                  console.log(error);
                });
              } else {
                $scope.aIsAirport = false;
              }
            } else {
              //nothing to do
            }
            if ($scope.dropoffLocation) {
              lastSelectDropoffAddress = $scope.dropoffLocation.address.formatted_address;
            }
          } else {
            //nothing to do
          }
          currentLocateType = undefined;
          changeMapState();
        });

        $scope.getAirlineCompany = function (val) {
          $scope.editAirport.airFlightObjList = undefined;
          $scope.editAirport.airFlightObj = undefined;
          return EasybookService.matchingAirlineCompany(val, $scope.editAirport.airLineObjList);
        };

        $scope.onAirlineCompanySearchSelect = function ($item) {
          $scope.editAirport.airLineObj = $item;
          $scope.editAirport.airFlightObjList = $item.flights;
        };

        $scope.getAirlineNumber = function (val) {
          return EasybookService.matchingAirlineNumber(val, $scope.editAirport.airFlightObjList);
        };

        $scope.onAirlineNumberSearchSelect = function ($item) {
          $scope.editAirport.airFlightObj = $item;
        };

        //Fix Map
        function resizeMapFix() {
          angular.element($("#easy-map")).css("height", window.screen.availHeight * 0.4 + "px");
        }

        resizeMapFix();

        //init DirectionsService,DirectionsRenderer,Map
        var directionsService = new google.maps.DirectionsService;
        var directionsDisplay = new google.maps.DirectionsRenderer;
        var map;
        var mapCenter;
        if (localStorage.getItem('ngStorage-currentPosition')) {
          var positions = JSON.parse(localStorage.getItem('ngStorage-currentPosition'));
          mapCenter = {lat: positions.coords.latitude, lng: positions.coords.longitude}
        } else {
          var companyLat = StorageService.getCompanyInfo().lat;
          var companyLng = StorageService.getCompanyInfo().lng;
          mapCenter = {lat: companyLat, lng: companyLng};
        }
        var pickUpMaker;

        console.log(JSON.parse(localStorage.getItem('ngStorage-currentPosition')))
        $scope.dIsAirport = false;
        $scope.aIsAirport = false;

        $scope.editAirport = {
          isAirPort: false,
          airLineObj: undefined,
          airLineObjList: undefined,
          airFlightObj: undefined,
          airFlightObjList: undefined
        };

        var dAirLineObj = undefined;
        var dAirFlightObj = undefined;
        var dAirLineObjList = undefined;
        var aAirLineObj = undefined;
        var aAirFlightObj = undefined;
        var aAirLineObjList = undefined;

        //load map
        function loadMap() {
          map = new google.maps.Map(document.getElementById('easy-map'), {
            zoom: 12,
            center: mapCenter,
            draggable: false,
            mapTypeControl: false,
            disableDefaultUI: true
          });

          if (localStorage.getItem('ngStorage-currentPosition')) {
            console.log(map.center.lat())
            console.log(map.center.lng())
            var marker = new google.maps.Marker({
              position: map.center
            });
            marker.setMap(map);
          }

          LocationService.getCurrentPosition(function (position) {
            var latlng = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            map.setCenter(latlng);
          }, function (error) {
            console.log('Locate fault!!!!');
          });
        }

        loadMap();

        //draw route on map or set map center
        function changeMapState() {
          if ($scope.selelctedTripTypeIndex == 1) {
            MapService.hideRoute(directionsDisplay);
            if ($scope.pickupLocation != undefined) {
              map.setCenter({lat: $scope.pickupLocation.lat, lng: $scope.pickupLocation.lng});
              map.setZoom(12);
              if (pickUpMaker) {
                pickUpMaker.setPosition({lat: $scope.pickupLocation.lat, lng: $scope.pickupLocation.lng});
              } else {
                pickUpMaker = new google.maps.Marker({
                  position: {lat: $scope.pickupLocation.lat, lng: $scope.pickupLocation.lng}
                });
              }
              pickUpMaker.setMap(map);
            } else {
              if (pickUpMaker) {
                pickUpMaker.setMap(null);
              }
            }
          } else {
            if (pickUpMaker) {
              pickUpMaker.setMap(null);
            }
            MapService.hideRoute(directionsDisplay);
            if ($scope.pickupLocation != undefined && $scope.dropoffLocation != undefined) {
              var startPoint = {
                placeId: $scope.pickupLocation.address.place_id
              };
              var endPoint = {
                placeId: $scope.dropoffLocation.address.place_id
              };

              directionsDisplay.setMap(map);
              MapService.calculateAndDisplayRoute(
                directionsService,
                startPoint,
                endPoint,
                $scope.dateAndTime.dateAndTime,
                function (response, status) {
                  console.log("response is ", response);
                  if (status === google.maps.DirectionsStatus.OK) {
                    directionsDisplay.setDirections(response);
                    estDistance = response.routes[0].legs[0].distance.value / 1000;
                    estDuration = response.routes[0].legs[0].duration.value / 60;
                  } else {
                    console.log('Directions request failed due to ' + status);
                  }
                });
            }
          }
        }

        //Push to map locate view
        var currentLocateType = undefined;
        $scope.pustToMapLocateView = function (locateType) {
          currentLocateType = locateType;
          $state.go('app.map-locate', {"locateType": locateType});
        };

        //设置航班信息
        //0:pickup 1:dropoff
        var airportPop;
        var setAirportType;
        $scope.openAirportModel = function (type) {
          if (type) {
            if ($scope.dropoffLocation) {
              $scope.content = $filter('translate')('easybook.jsdropoff_Is_airport');
              showAirportPop(type);
            } else {
              //nothing to do
            }
          } else {
            if ($scope.pickupLocation) {
              $scope.content = $filter('translate')('easybook.jspickup_Is_airport');
              showAirportPop(type);
            } else {
              //nothing to do
            }
          }
        };

        var showAirportPop = function (type) {
          if (type) {
            $scope.content = $filter('translate')('easybook.jsdropoff_Is_airport');
          } else {
            $scope.content = $filter('translate')('easybook.jspickup_Is_airport');
          }
          $scope.type = type;
          setAirportType = type;
          if (setAirportType == 0) {
            //pickup
            $scope.editAirport = {
              isAirPort: $scope.dIsAirport,
              airLineObj: dAirLineObj,
              airLineObjList: dAirLineObjList,
              airFlightObj: dAirFlightObj
            };
          } else {
            //dropoff
            $scope.editAirport = {
              isAirPort: $scope.aIsAirport,
              airLineObj: aAirLineObj,
              airLineObjList: aAirLineObjList,
              airFlightObj: aAirFlightObj
            };
          }

          airportPop = $ionicPopup.show({
            templateUrl: "templates/input-airport-popup.html",
            scope: $scope,
            cssClass: "airport-popstyle"
          })
        };


        $scope.onChangeEditIsAirport = function () {
          $scope.editAirport.isAirPort = !$scope.editAirport.isAirPort;
          if (!$scope.editAirport.isAirPort) {
            $scope.editAirport.airLineObj = undefined;
            $scope.editAirport.airFlightObjList = undefined;
            $scope.editAirport.airFlightObj = undefined;
          }
        };

        $scope.onSetAirportCancel = function () {
          if (airportPop) {
            airportPop.close();
          }
          if (setAirportType == 0) {
            //pickup
            if (needDropOffAirportPop) {
              showAirportPop(1);
              var time = (Date.parse($scope.dateAndTime.dateAndTime) + "").substr(0, 10);
              MapService.getFlightsList($scope.dropoffLocation.lat, $scope.dropoffLocation.lng, 1, time, function (result) {
                if (result.code == '2000') {
                  aAirLineObjList = result.result;
                  $scope.editAirport.airLineObjList = aAirLineObjList;
                }
              }, function (error) {
                console.log(error);
              });
              needDropOffAirportPop = false;
            }
          } else {
            //dropoff
            needDropOffAirportPop = false;
          }
        };

        $scope.onSetAirportSuccess = function () {
          if (setAirportType == 0) {
            //pickup
            $scope.dIsAirport = $scope.editAirport.isAirPort;
            dAirLineObj = angular.copy($scope.editAirport.airLineObj);
            dAirFlightObj = angular.copy($scope.editAirport.airFlightObj);

            console.log(dAirLineObj);
            console.log(dAirFlightObj);
          } else {
            //dropoff
            $scope.aIsAirport = $scope.editAirport.isAirPort;
            aAirLineObj = angular.copy($scope.editAirport.airLineObj);
            aAirFlightObj = angular.copy($scope.editAirport.airFlightObj);
          }
          $scope.onSetAirportCancel();
        };

        //get offers from remote
        $scope.form_preBook_submit = function () {
          var now = new Date();
          var nowTimestamp = now.getTime();
          var appointedTimestamp = Date.parse($scope.dateAndTime.dateAndTime);
          if (appointedTimestamp <= nowTimestamp) {
            $ionicPopup.alert({
              title: $filter('translate')('easybook.jsAppointed_time_invalid'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
            return;
          }

          var requestParams = {};
          if ($scope.selelctedTripTypeIndex == 0) {
            //p2p
            if (!$scope.pickupLocation || !$scope.dropoffLocation) {
              $ionicPopup.alert({
                title: $filter('translate')('easybook.jsMissing_fields'),
                okText: $filter('translate')('ionicPopup.jsOK')
              });
              return false;
            }
            requestParams.type = 1;
            requestParams.unit = 2;
            requestParams.d_lat = $scope.pickupLocation.lat;
            requestParams.d_lng = $scope.pickupLocation.lng;
            requestParams.d_address = $scope.pickupLocation.address;
            requestParams.a_lat = $scope.dropoffLocation.lat;
            requestParams.a_lng = $scope.dropoffLocation.lng;
            requestParams.a_address = $scope.dropoffLocation.address;
            requestParams.car_category = 0;
            requestParams.appointed_time = $scope.dateAndTime.dateAndTime;
            requestParams.estimate_distance = estDistance;
            requestParams.estimate_duration = estDuration;
            requestParams.d_is_airport = $scope.dIsAirport ? 1 : 0;
            if (dAirLineObj && dAirLineObj.name && dAirLineObj.name.length > 0) {
              requestParams.d_airline = dAirLineObj.name;
              if (dAirLineObj.fs) {
                requestParams.d_fs = dAirLineObj.fs;
              } else {
                requestParams.d_fs = dAirLineObj.name;
              }
              if (dAirFlightObj && dAirFlightObj.flightNumber) {
                requestParams.d_flight = dAirFlightObj.flightNumber;
              }
            }
            requestParams.a_is_airport = $scope.aIsAirport ? 1 : 0;
            if (aAirLineObj && aAirLineObj.name && aAirLineObj.name.length > 0) {
              requestParams.a_airline = aAirLineObj.name;
              if (aAirLineObj.fs) {
                requestParams.a_fs = aAirLineObj.fs;
              } else {
                requestParams.a_fs = aAirLineObj.name;
              }
              if (aAirFlightObj && aAirFlightObj.flightNumber) {
                requestParams.a_flight = aAirFlightObj.flightNumber;
              }
            }
          } else {
            //hourly
            if (!$scope.pickupLocation) {
              $ionicPopup.alert({
                title: $filter('translate')('easybook.jsMissing_fields'),
                okText: $filter('translate')('ionicPopup.jsOK')
              });
              return false;
            }
            requestParams.type = 2;
            requestParams.unit = 2;
            requestParams.d_lat = $scope.pickupLocation.lat;
            requestParams.d_lng = $scope.pickupLocation.lng;
            requestParams.d_address = $scope.pickupLocation.address;
            requestParams.estimate_duration = $scope.duration.duration * 60;
            requestParams.car_category = 0;
            requestParams.appointed_time = $scope.dateAndTime.dateAndTime;
            requestParams.d_is_airport = $scope.dIsAirport ? 1 : 0;
            if (dAirLineObj && dAirLineObj.name && dAirLineObj.name.length > 0) {
              requestParams.d_airline = dAirLineObj.name;
              if (dAirLineObj.fs) {
                requestParams.d_fs = dAirLineObj.fs;
              } else {
                requestParams.d_fs = dAirLineObj.name;
              }
              if (dAirFlightObj && dAirFlightObj.flightNumber) {
                requestParams.d_flight = dAirFlightObj.flightNumber;
              }
            }
            requestParams.a_is_airport = 0;
          }

          $ionicLoading.show({
            template: $filter('translate')('easybook.jsLoading_offers')
          });
          EasybookService.getOffersFromRemote(requestParams,
            function (response) {
              $ionicLoading.hide();
              $state.go('app.easybook-cars', {"offers": response.result, "is_airport": requestParams})
            },
            function (errorString, response) {
              $ionicLoading.hide();
              if (!LoginService.logoutWhenAuthExpired(response.code)) {
                if (errorString) {
                  $ionicPopup.alert({
                    title: errorString,
                    okText: $filter('translate')('ionicPopup.jsOK')
                  });
                } else {
                  $ionicPopup.alert({
                    title: $filter('translate')('easybook.jsRequest_fault'),
                    okText: $filter('translate')('ionicPopup.jsOK')
                  });
                }
              }
            }
          );
        };

        //service type
        var tripTypes = [$filter('translate')('easybook.jsTransfer'), $filter('translate')('easybook.jsHourly')];
        $scope.selelctedTripTypeIndex = 0;
        $scope.selelctedTripType = tripTypes[0];
        $scope.showTripTypeActionSheet = function () {
          $ionicActionSheet.show({
            titleText: $filter('translate')('easybook.jsSelect'),
            buttons: [{
              text: tripTypes[0]
            }, {
              text: tripTypes[1]
            }],
            cancelText: $filter('translate')('easybook.jsCancel'),
            cancel: function () {
              console.log('CANCELLED');
            },
            buttonClicked: function (index) {
              $scope.selelctedTripTypeIndex = index;
              $scope.selelctedTripType = tripTypes[index];
              cleanData();
              changeMapState();
              return true;
            },
            destructiveButtonClicked: function () {
              console.log('DESTRUCT');
              return true;
            }
          });
        };

        //date&time
        $scope.defaultDate = function () {
          var curDate = new Date();
          var dateString = $filter('date')(curDate, "yyyy-MM-dd");
          curDate = new Date(dateString);
          var nextDate = new Date(curDate.getTime() + 28 * 60 * 60 * 1000);
          return nextDate;
        };


        var lastSelectTime = undefined;
        var needDropOffAirportPop = false;
        $scope.onDateTimeChange = function () {
          //如果时间改变,做下一步操作
          //如果时间没有改变,什么都不做
          if (lastSelectTime != $scope.dateAndTime.dateAndTime) {
            //判断是否需要弹起起点airportpop
            if ($scope.pickupLocation && $scope.dIsAirport) {
              dAirLineObj = undefined;
              dAirLineObjList = undefined;
              dAirFlightObj = undefined;

              showAirportPop(0);
              var time = (Date.parse($scope.dateAndTime.dateAndTime) + "").substr(0, 10);
              MapService.getFlightsList($scope.pickupLocation.lat, $scope.pickupLocation.lng, 0, time, function (result) {
                console.log(result);
                if (result.code == '2000') {
                  dAirLineObjList = result.result;
                  $scope.editAirport.airLineObjList = dAirLineObjList;
                }
              }, function (error) {
                console.log(error);
              });
            }

            if ($scope.dropoffLocation && $scope.aIsAirport) {
              aAirLineObj = undefined;
              aAirLineObjList = undefined;
              aAirFlightObj = undefined;
              if ($scope.pickupLocation && $scope.dIsAirport) {
                needDropOffAirportPop = true;
              } else {
                showAirportPop(1);
                var time = (Date.parse($scope.dateAndTime.dateAndTime) + "").substr(0, 10);
                MapService.getFlightsList($scope.dropoffLocation.lat, $scope.dropoffLocation.lng, 1, time, function (result) {
                  console.log(result);
                  if (result.code == '2000') {
                    aAirLineObjList = result.result;
                    $scope.editAirport.airLineObjList = aAirLineObjList;
                  }
                }, function (error) {
                  console.log(error);
                });
              }
            }
            changeMapState();
          } else {
          }

          //更新lastSelectTime
          lastSelectTime = angular.copy($scope.dateAndTime.dateAndTime);
        };

        $scope.dateAndTime = {};
        $scope.dateAndTime.dateAndTime = $scope.defaultDate();

        //duration
        $scope.duration = {};
        $scope.duration.duration = 1;
      });
})();
