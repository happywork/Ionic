/**
 * Created by wangyuanzhi on 16/7/9.
 */
(function () {
  'use strict';
  angular.module('starter')
    .service("BackgroundModeService", function (TripService) {
      var self = this;
      self.enterBackground = function(){
        TripService.backgroundModeChanged(true);
      };
      self.enterForeground = function(){
        TripService.backgroundModeChanged(false);
      }
    });
})();
