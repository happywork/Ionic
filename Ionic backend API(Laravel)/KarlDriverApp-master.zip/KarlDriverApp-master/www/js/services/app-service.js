(function () {
  'use strict';
  angular.module('starter')
    .service('AppService', function ($state, $ionicPopup,$rootScope ,$ionicViewSwitcher, HttpService,$filter,$localStorage) {
      this.checkAppUpdateService = function (version, plate,appName) {
        // var message = 'Please tap below to download the latest version of the ' + appName + ' App.';
        var message = $filter('translate')('appUpdate.jsGreat_News',{appName:appName});
        HttpService.get(Api.checkAppVersion+plate, {
          version: version
        }, function (response) {
          $localStorage.canNetWork=1;
          if(response.code == 2000){
            if(response.result.update == 1){
              var pop = {
                title: $filter('translate')('appUpdate.jsGreat_News'),
                cssClass:"update-popup",
                subTitle:$filter('translate')('appUpdate.jsHas_upgraded'),
                template: message,
                scope:$rootScope,
                buttons:[
                  {text: $filter('translate')('appUpdate.jsDownload_Now'),
                    type: 'button-positive',
                    onTap: function(e) {
                      $rootScope.updatePop.close();
                      window.open(Api.getAppUrl+plate,"_system")
                    }
                  }
                ]
              };
              if(response.result.support == 1){
                pop.buttons.push({
                  text: $filter('translate')('appUpdate.jsLater'),
                  type: 'button-default',
                  onTap: function(e) {
                    $rootScope.updatePop.close();
                  }
                })
              }
              $rootScope.updatePop = $ionicPopup.show(pop);
            }
          }
        }, function (errorString) {
          $localStorage.canNetWork=2;
        });
      };

    });
})();
