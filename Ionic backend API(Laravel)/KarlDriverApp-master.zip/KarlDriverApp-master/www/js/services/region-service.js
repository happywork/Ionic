/**
 * Created by wangyuanzhi on 16/5/21.
 */
(function () {
  "use strict";
  angular.module('starter').service('RegionService', function ($localStorage) {
    var self = this;

    /*region
     *region.country = 'US'
     *region.postalCode = '710000'
     *region.serverUrl = 'http://115.28.202.172:9000'
     */
    self.initialize = function(){
      var region = {};
      region.country = 'US';
      self.saveCurrentRegion(region);
    };

    //getCurrentRegion
    self.getCurrentRegion = function () {
      if (!this.region) {
        this.region = $localStorage.region;
      }
      return this.region;
    };

    //saveCurrentRegion
    self.saveCurrentRegion = function (regionObject) {
      this.region = regionObject;
      $localStorage.region = regionObject;
    };

    //clearCurrentRegion
    self.clearCurrentRegion = function () {
      delete $localStorage.user;
      delete this.region;
    };
  });
})();
