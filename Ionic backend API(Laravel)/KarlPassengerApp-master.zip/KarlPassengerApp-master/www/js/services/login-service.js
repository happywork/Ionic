(function () {
  'use strict';

  angular.module('passengerApp')
    .service('LoginService', function ($state, $ionicPopup, $ionicViewSwitcher,UserService, EasybookService,
                                       HttpService, TripService, LocationService,$filter) {

      //login
      this.login = function (userName, userPassword, successHandler, faultHandler) {
        HttpService.post(Api.login, {
            "username": userName,
            "password": userPassword
          },
          function (response) {
            console.log(response)
            var code = response.code;
            var user = response.result;
            if (!user.customer || !user.customer.customer_id) {
              if (faultHandler) {
                faultHandler($filter('translate')('login.jsLogin_Fault'));
              }
              return;
            }
            console.log("watching log is .......");
            user.loginAccount = userName;
            user.loginPwd = userPassword;
            UserService.saveLoginUser(user);
            // LocationService.watchPosition();
            if (successHandler) {
              successHandler();
            }
          }, function (errorString) {
            if (faultHandler) {
              if(errorString){
                faultHandler(errorString);
              }else {
                faultHandler($filter('translate')('login.jsLogin_Fault'));
              }
            }
          });
      };

      //logout
      this.logout = function () {
        HttpService.post(Api.logout, {}, function () {
        }, function () {
        });
        UserService.clearLoginUser();
        EasybookService.clearBookingData();
        TripService.endTrip();
        LocationService.clearWatch();
      };

      //异点登录被踢
      this.logoutWhenAuthExpired = function (errorCode) {
        if (errorCode == 3007) {
          UserService.clearLoginUser();
          EasybookService.clearBookingData();
          TripService.endTrip();
          LocationService.clearWatch();
          // var errorString = ErrorCode.getErrorMessage(3007);
          var errorString =  $filter('translate')(3007);
          $ionicPopup.alert({
            title: errorString,
            okText: $filter('translate')('ionicPopup.jsOK')
          }).then(function (res) {
            $state.go('login');
            $ionicViewSwitcher.nextDirection("back")
          });
          return true;
        } else {
          return false;
        }
      };

      this.getUpdatedVersion = function (plate, version, successHandler, faultHandler) {
        HttpService.get(Api.getUpdatedVersion + plate, {
          "version": version
        },successHandler, faultHandler);
      };

      this.goUpdate = function (plate) {
        return Api.goUpdate + plate;
      };
    });
})();
