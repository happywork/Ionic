/**
 * Created by jian on 17-6-28.
 */
angular.module('passengerApp')
.controller('MultilingualCtrl',function ($scope,$state,$timeout) {
  $scope.$on('$ionicView.beforeEnter', function () {
    function autoJump(){
      $timeout(function () {
        $state.go("app.easybook");
      },200)
    }
    autoJump()
  })

});
