# KARL Dashboard

This project is dashboard for KARL. 

This project contains:
- Admin Dashboard;
- SuperAdmin Dashboard;
- Onboard;
- Other pages.  


## About KARL

For more information, see http://www.karl.limo

## About Dashboard

This project is private property of KARL, which is technical support by Inov.tech, 
see http://www.inov.tech

This project is:
- Language: JavaScript, CSS;
- IDE: WebStorm;
- Main Framework: Angular, Bootstrap.


## Contact

CTO of Inov.tech: heroalur@qq.com