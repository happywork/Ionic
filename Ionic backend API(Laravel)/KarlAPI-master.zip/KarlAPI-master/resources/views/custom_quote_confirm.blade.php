<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{{\Illuminate\Support\Facades\Lang::get("booking.customBookingTitle")}}</title>
    <script type="text/javascript">
        function message(msg) {
            alert(msg);
            window.open("", "_self").close()
        }
    </script>
</head>
<body style="background-color: #000;" onload="message('{{$message}}')">

</body>
</html>
