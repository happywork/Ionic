(function () {
  'use strict';
  angular.module('passengerApp')
    .controller('EasybookReturnCarsCtrl',
      function ($stateParams, $scope, $ionicActionSheet, $timeout, $state,
                $ionicSlideBoxDelegate, $ionicPopup, $ionicLoading, $ionicHistory, EasybookService, UserService,$filter) {

        //限制notes字数为999
        $("#easybook-return-notes-textarea").on("input propertychange", function () {
          var $this = $(this),
            _val = $this.val();
          if (_val.length > 999) {
            $this.val(_val.substring(0, 999));
          }
        });
        $scope.langStyle=localStorage.getItem('lang')!=='en';
        var User = UserService.getLoginUser();
        $scope.re_d_is_airport = $stateParams.is_airport.is_airport.a_is_airport;
        $scope.re_a_is_airport = $stateParams.is_airport.is_airport.d_is_airport;
        var appointedTimeWatch;
        $scope.$on("$ionicView.enter", function () {
          appointedTimeWatch = $scope.$watch('rs.returnAppointedTime', function (newValue, oldValue, scope) {
            $timeout(function () {
              if (Date.parse(oldValue) != Date.parse(newValue) && Date.parse(newValue) != Date.parse(lastUseTime)) {
                var now = new Date();
                var nowTimestamp = now.getTime();
                var appointedTimestamp = Date.parse($scope.rs.returnAppointedTime);
                if (appointedTimestamp <= nowTimestamp) {
                  $ionicPopup.alert({
                    title: $filter('translate')('easybook_return_cars.jsAppointed_time_invalid'),
                    okText: $filter('translate')('ionicPopup.jsOK')
                  });
                  $scope.rs.returnAppointedTime = lastUseTime;
                  return;
                }
                $ionicLoading.show();
                EasybookService.getReturnServiceOffersFromRemote($scope.rs.returnAppointedTime,
                  function (response) {
                    $ionicLoading.hide();
                    $timeout(function () {
                      lastUseTime = $scope.rs.returnAppointedTime;
                      $scope.initialize(response.result,
                        $stateParams.car,
                        $scope.rs.returnAppointedTime,
                        $stateParams.passengerNumber,
                        $stateParams.passengers,
                        $stateParams.bagNumber,
                        false);
                    }, 0);
                  }, function (errorString, response) {
                    $ionicLoading.hide();
                    $scope.rs.returnAppointedTime = lastUseTime;
                    if (!LoginService.logoutWhenAuthExpired(response.code)) {
                      if (errorString) {
                        $ionicPopup.alert({
                          title: errorString,
                          okText: $filter('translate')('ionicPopup.jsOK')
                        });
                      } else {
                        $ionicPopup.alert({
                          title: $filter('translate')('easybook_return_cars.jsRequest_fault'),
                          okText: $filter('translate')('ionicPopup.jsOK')
                        });
                      }
                    }
                  }
                );
              }
            }, 0);
          });
        });

        $scope.$on("$ionicView.leave", function () {
          appointedTimeWatch();
        });

        var originalOffers;
        var allCars;
        var allCategorys;
        var allBrands;
        var lastUseTime;
        var selectedCarCategoryIndex;
        var selectedCarBrandIndex;
        var selectedCarIndex;
        $scope.initialize = function (offers, bookingCar, appointedTime, passengerNumber, passengers, bagNumber, cache) {
          EasybookService.returnServiceCache.offers = offers;
          originalOffers = offers;
          allCars = [];
          allCategorys = [];
          allBrands = [];
          $scope.rs = {};
          $scope.rs.returnAppointedTime = appointedTime;
          lastUseTime = appointedTime;
          $scope.d_final_address = finalAddress(EasybookService.bookingParam.a_address);
          $scope.a_final_address = finalAddress(EasybookService.bookingParam.d_address);
          $scope.optionsTotalPrice = 0;
          $scope.hadSelectedOption = false;
          $scope.notesToggle = {};
          $scope.notes = {};
          $scope.initCarsAndCategorysAndBrands(originalOffers);
          $scope.hasCars = true;

          if (cache) {
            var selectedCache = EasybookService.returnServiceCache.selects;
            $scope.notesToggle.isOpen = selectedCache.noteIsOpen;
            $scope.notes.text = selectedCache.note;
            $scope.selectedCarCategory = allCategorys[selectedCache.carCategoryIndex];
            $scope.selectedCarBrand = allBrands[selectedCache.carBrandIndex];
            $scope.cars = filterCars();
            $scope.integrateCarData(selectedCache.carIndex);
            $timeout(function () {
              $ionicSlideBoxDelegate.$getByHandle('car-slider-box-return').update();
              $ionicSlideBoxDelegate.$getByHandle('car-slider-box-return').slide(selectedCache.carIndex);
            }, 0);
            $scope.selectedCar.options = selectedCache.options;
            $scope.selectedCar.selectedOptions = selectedCache.selectedOptions;
            $scope.optionsTotalPrice = $scope.calculateOptionsCost();
            if ($scope.optionsTotalPrice == 0) {
              $scope.hadSelectedOption = false;
            } else {
              $scope.hadSelectedOption = true;
            }

            if ($scope.re_d_is_airport == 1) {
              if ($scope.re_a_is_airport == 1) {
                $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost + $scope.offer.d_port_price + $scope.offer.a_port_price) * (1 + $scope.offer.tva / 100);
              } else {
                $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost + $scope.offer.d_port_price) * (1 + $scope.offer.tva / 100);
              }
            } else {
              if ($scope.re_a_is_airport == 1) {
                $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost + $scope.offer.a_port_price) * (1 + $scope.offer.tva / 100);
              } else {
                $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost) * (1 + $scope.offer.tva / 100);
              }
            }
            // $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost) * (1 + $scope.offer.tva / 100);
            if ($scope.totalCost > 0 && $scope.totalCost < 1) {
              $scope.totalCost = 1.00;
            }
            $scope.countInput = angular.copy(selectedCache.countInput);
            $scope.passengers = angular.copy(selectedCache.passengers);

            selectedCarCategoryIndex = selectedCache.carCategoryIndex;
            selectedCarBrandIndex = selectedCache.carBrandIndex;
            selectedCarIndex = selectedCache.carIndex;
          } else {
            $scope.notesToggle.isOpen = true;
            $scope.notes.text = '';
            $scope.selectedCarCategory = allCategorys[0];
            $scope.selectedCarBrand = allBrands[0];
            $scope.cars = filterCars();

            //优先匹配去程车辆
            //再匹配去程车系
            //再匹配去程车make
            //以上3者匹配不上,则匹配第1辆车
            var index = 0;
            var findCar = false;
            var findModel = false;
            var findBrand = false;
            for (var i = 0; i < $scope.cars.length; i++) {
              if ($scope.cars[i].car_id == bookingCar.car_id) {
                index = i;
                findCar = true;
                break;
              }
              if ($scope.cars[i].model == bookingCar.model) {
                if (findModel) {
                  continue;
                } else {
                  findModel = true;
                  index = i;
                }
              }
              if ($scope.cars[i].brand == bookingCar.brand) {
                if (findBrand) {
                  continue;
                } else {
                  findBrand = true;
                  if (!findModel) {
                    index = i;
                  }
                }
              }
            }

            if (findCar) {
              $scope.countInput = {maxPassengers: passengerNumber, maxBags: bagNumber};
              $scope.passengers = angular.copy(passengers);
            } else {
              $scope.countInput = {maxPassengers: 0, maxBags: 0};
              $scope.passengers = [];
            }

            $scope.integrateCarData(index);
            $timeout(function () {
              $ionicSlideBoxDelegate.$getByHandle('car-slider-box-return').update();
              $ionicSlideBoxDelegate.$getByHandle('car-slider-box-return').slide(index);
            }, 0);


            if ($scope.re_d_is_airport == 1) {
              if ($scope.re_a_is_airport == 1) {
                $scope.totalCost = ($scope.offer.basic_cost + $scope.offer.d_port_price + $scope.offer.a_port_price) * (1 + $scope.offer.tva / 100);
              } else {
                $scope.totalCost = ($scope.offer.basic_cost + $scope.offer.d_port_price) * (1 + $scope.offer.tva / 100);
              }
            } else {
              if ($scope.re_a_is_airport == 1) {
                $scope.totalCost = ($scope.offer.basic_cost + $scope.offer.a_port_price) * (1 + $scope.offer.tva / 100);
              } else {
                $scope.totalCost = ($scope.offer.basic_cost) * (1 + $scope.offer.tva / 100);
              }
            }
            // $scope.totalCost = $scope.offer.basic_cost * (1 + $scope.offer.tva / 100);
            if ($scope.totalCost > 0 && $scope.totalCost < 1) {
              $scope.totalCost = 1.00;
            }
            selectedCarCategoryIndex = 0;
            selectedCarBrandIndex = 0;
            selectedCarIndex = index;
          }
        };

        //集合所有的car到allCars中
        //集合所有的category到allCategorys中
        //集合所有的brand到allBrands中
        $scope.initCarsAndCategorysAndBrands = function (offers) {
          for (var i = 0; i < offers.length; i++) {
            var option = $scope.initOptionData(offers[i].options);
            for (var j = 0; j < offers[i].car_categories.length; j++) {
              var category = {};
              category.car_category_id = offers[i].car_categories[j].category_id;
              category.car_category_name = offers[i].car_categories[j].category;

              var carArray = [];

              for (var k = 0; k < offers[i].car_categories[j].cars.length; k++) {

                //Added by Pham 3/29/2018
                var eachCar = Object();
                eachCar.car_brand_id = offers[i].car_categories[j].cars[k].car_brand_id;
                eachCar.car_model_id = offers[i].car_categories[j].cars[k].car_model_id;

                var is_car_brandId_exist = carArray.findIndex(x => x.car_brand_id == eachCar.car_brand_id);
                var is_car_modelId_exist = carArray.findIndex(x => x.car_model_id == eachCar.car_model_id);
                
                if(is_car_brandId_exist == -1 || is_car_modelId_exist == -1)
                {
                  carArray.push(eachCar);
                  //集合allCars
                  offers[i].car_categories[j].cars[k].offer_id = offers[i].offer_id;
                  offers[i].car_categories[j].cars[k].company_id = offers[i].company_id;
                  offers[i].car_categories[j].cars[k].combine = offers[i].combine;
                  offers[i].car_categories[j].cars[k].options = jQuery.extend(true, {}, option);
                  offers[i].car_categories[j].cars[k].selectedOptions = [];
                  allCars.push(offers[i].car_categories[j].cars[k]);

                  //集合allBrands
                  var findBrand = false;
                  for (var m = 0; m < allBrands.length; m++) {
                    if (allBrands[m].car_brand_id == offers[i].car_categories[j].cars[k].car_brand_id) {
                      findBrand = true;
                    }
                  }
                  if (findBrand == false) {
                    var brand = {};
                    brand.car_brand_id = offers[i].car_categories[j].cars[k].car_brand_id;
                    brand.car_brand_name = offers[i].car_categories[j].cars[k].brand;
                    allBrands.push(brand);
                  }
                }
              }

              //集合allCategorys
              var findCategory = false;
              for (var k = 0; k < allCategorys.length; k++) {
                if (allCategorys[k].car_category_id == category.car_category_id) {
                  findCategory = true;
                }
              }
              if (findCategory == false) {
                allCategorys.push(category);
              }
            }
          }

          //添加"All categorys"到allCategorys的第一项
          if (allCategorys.length > 1) {
            var allCategory = {"car_category_name": $filter('translate')('easybook_cars.jsAll_categorys'), "car_category_id": -1};
            allCategorys.splice(0, 0, allCategory);
          }

          //添加"All makes"到allBrands的第一项
          if (allBrands.length > 1) {
            var allBrand = {"car_brand_name": $filter('translate')('easybook_cars.jsAll_makes'), "car_brand_id": -1};
            allBrands.splice(0, 0, allBrand);
          }
        };

        $scope.integrateCarData = function (selectedIndex) {
          if ($scope.selectedCar && $scope.selectedCar.car_id != $scope.cars[selectedIndex].car_id) {
            $scope.countInput = {maxPassengers: 0, maxBags: 0};
            $scope.passengers = [];
          }

          $scope.selectedCar = $scope.cars[selectedIndex];
          for (var i = 0; i < originalOffers.length; i++) {
            if (originalOffers[i].offer_id == $scope.selectedCar.offer_id) {
              $scope.offer = originalOffers[i];
              $scope.company_id = $scope.offer.company_id;
              break;
            }
          }
          if ($scope.offer.options.length > 0) {
            $scope.hasOptions = true;
          } else {
            $scope.hasOptions = false;
          }
        };

        $scope.initOptionData = function (options) {
          var formatOptions = {number: [], checkBox: [], radioGroup: [], checkBoxGroup: [], numberGroup: []};
          for (var i = 0; i < options.length; i++) {
            var option = options[i];
            if (option.type == "NUMBER") {
              if (option.add_max > 1) {
                option.count = 0;
                formatOptions.number.push(option);
              } else {
                option.selected = false;
                formatOptions.checkBox.push(option);
              }
            } else if (option.type == "CHECKBOX") {
              option.selected = false;
              formatOptions.checkBox.push(option);
            } else if (option.type == "GROUP") {
              if (option.group == undefined) {
                continue;
              }
              if (option.group[0].type == "NUMBER") {
                for (var j = 0; j < option.group.length; j++) {
                  option.group[j].count = 0;
                }
                formatOptions.numberGroup.push(option);
              } else if (option.group[0].type == "RADIO") {
                option.selectedOptionIndex = 0;
                var noNeed = {
                  "option_id": -1,
                  "type": option.group[0].type,
                  "parent_id": option.group[0].parent_id,
                  "price": "0",
                  "name": ""
                };
                option.group.unshift(noNeed);
                formatOptions.radioGroup.push(option);
              } else if (option.group[0].type == "CHECKBOX") {
                for (var j = 0; j < option.group.length; j++) {
                  option.group[j].selected = false;
                }
                formatOptions.checkBoxGroup.push(option);
              }
            }
          }
          return formatOptions;
        };

        function filterCars() {
          var resultCars = [];
          if ($scope.selectedCarCategory.car_category_id == -1) {
            if ($scope.selectedCarBrand.car_brand_id == -1) {
              resultCars = jQuery.extend(true, [], allCars);
            } else {
              for (var i = 0; i < allCars.length; i++) {
                if (allCars[i].car_brand_id == $scope.selectedCarBrand.car_brand_id) {
                  resultCars.push(jQuery.extend(true, {}, allCars[i]));
                }
              }
            }
          } else {
            if ($scope.selectedCarBrand.car_brand_id == -1) {
              for (var i = 0; i < allCars.length; i++) {
                if (allCars[i].car_category_id == $scope.selectedCarCategory.car_category_id) {
                  resultCars.push(jQuery.extend(true, {}, allCars[i]));
                }
              }
            } else {
              for (var i = 0; i < allCars.length; i++) {
                if (allCars[i].car_category_id == $scope.selectedCarCategory.car_category_id && allCars[i].car_brand_id == $scope.selectedCarBrand.car_brand_id) {
                  resultCars.push(jQuery.extend(true, {}, allCars[i]));
                }
              }
            }
          }
          return resultCars;
        }

        //calculate options cost
        $scope.calculateOptionsCost = function () {
          var cost = 0.0;
          var options = $scope.selectedCar.selectedOptions;
          for (var i = 0; i < options.length; i++) {
            cost = cost + options[i].count * options[i].price;
          }
          return cost;
        };

        $scope.showRadioOpetionActionSheet = function (option) {
          var buttions = [];
          for (var i = 0; i < option.group.length; i++) {
            if (option.group[i].option_id == -1) {
              buttions.push({"text": "Not need"});
            } else {
              buttions.push({"text": option.group[i].name});
            }
          }
          $ionicActionSheet.show({
            titleText: $filter('translate')('easybook_return_cars.jsSelect_option_name', {option_name: option.name}),
            buttons: buttions,
            cancelText: $filter('translate')('easybook_return_cars.jsCancel'),
            cancel: function () {
            },
            buttonClicked: function (index) {
              option.selectedOptionIndex = index;
              $scope.optionDidChanged(option.group[index]);
              return true;
            },
            destructiveButtonClicked: function () {
              console.log('DESTRUCT');
              return true;
            }
          });
        };

        $scope.numberOptionDidChanged = function (option, isAdd) {
          if (isAdd) {
            if (option.count < option.add_max) {
              option.count++;
            } else {
              //nothing to do..
            }
          } else {
            if (option.count > 0) {
              option.count--;
            } else {
              //nothing to do..
            }
          }
          $scope.optionDidChanged(option);
        };

        $scope.optionDidChanged = function (option) {
          if (option.type == "CHECKBOX") {
            if (option.selected == true) {
              option.count = 1;
              $scope.selectedCar.selectedOptions.push(option);
            } else {
              for (var i = 0; i < $scope.selectedCar.selectedOptions.length; i++) {
                if ($scope.selectedCar.selectedOptions[i].option_id == option.option_id) {
                  $scope.selectedCar.selectedOptions.splice(i, 1);
                  break;
                }
              }
            }
          } else if (option.type == "NUMBER") {
            if (option.add_max > 1) {
              var findIndex = -1;
              for (var i = 0; i < $scope.selectedCar.selectedOptions.length; i++) {
                if ($scope.selectedCar.selectedOptions[i].option_id == option.option_id) {
                  findIndex = i;
                  break;
                }
              }
              if (option.count == 0) {
                if (findIndex >= 0) {
                  $scope.selectedCar.selectedOptions.splice(i, 1);
                } else {
                  //nothing to do...
                }
              } else {
                if (findIndex == -1) {
                  $scope.selectedCar.selectedOptions.push(option);
                } else {
                  //nothing to do...
                }
              }
            } else {
              if (option.selected == true) {
                option.count = 1;
                $scope.selectedCar.selectedOptions.push(option);
              } else {
                for (var i = 0; i < $scope.selectedCar.selectedOptions.length; i++) {
                  if ($scope.selectedCar.selectedOptions[i].option_id == option.option_id) {
                    $scope.selectedCar.selectedOptions.splice(i, 1);
                    break;
                  }
                }
              }
            }
          } else if (option.type == "RADIO") {
            for (var i = 0; i < $scope.selectedCar.selectedOptions.length; i++) {
              if ($scope.selectedCar.selectedOptions[i].type == option.type && $scope.selectedCar.selectedOptions[i].parent_id == option.parent_id) {
                $scope.selectedCar.selectedOptions.splice(i, 1);
                break;
              }
            }
            if (option.option_id > -1) {
              option.count = 1;
              $scope.selectedCar.selectedOptions.push(option);
            } else {
              //nothing to do...
            }
          } else {
            //nothing to do...
          }
          $scope.optionsTotalPrice = $scope.calculateOptionsCost();
          if ($scope.optionsTotalPrice == 0) {
            $scope.hadSelectedOption = false;
          } else {
            $scope.hadSelectedOption = true;
          }

          if ($scope.re_d_is_airport == 1) {
            if ($scope.re_a_is_airport == 1) {
              $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost + $scope.offer.d_port_price + $scope.offer.a_port_price) * (1 + $scope.offer.tva / 100);
            } else {
              $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost + $scope.offer.d_port_price) * (1 + $scope.offer.tva / 100);
            }
          } else {
            if ($scope.re_a_is_airport == 1) {
              $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost + $scope.offer.a_port_price) * (1 + $scope.offer.tva / 100);
            } else {
              $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost) * (1 + $scope.offer.tva / 100);
            }
          }

          // $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost) * (1 + $scope.offer.tva / 100);
          if ($scope.totalCost > 0 && $scope.totalCost < 1) {
            $scope.totalCost = 1.00;
          }
          console.log($scope.totalCost)
        };


        $scope.passengerNumberDidChanged = function (isAdd) {
          if (isAdd) {
            if($scope.countInput.maxPassengers == $scope.selectedCar.seats_max){
              $scope.maxPassenAlertContent = $filter('translate')('easybook_cars.jsMax_passengers_alert');
              $ionicPopup.alert ({
                template: '<p>{{maxPassenAlertContent}}</p>',
                cssClass: 'location-permission-popup',
                scope: $scope,
                buttons: [ {
                  text: 'OK',
                  type: 'button-positive',
                  onTap: function(e) {
                    console.log(e);
                  }
                }]
              });
            }
            if ($scope.countInput.maxPassengers < $scope.selectedCar.seats_max) {
              $scope.countInput.maxPassengers++;
              if ($scope.selectedCar.seats_max > 6) {
                if ($scope.countInput.maxPassengers < 7) {
                  $scope.passengers.push({name: ''});
                }
              } else {
                $scope.passengers.push({name: ''});
              }
            }
          } else {
            if ($scope.countInput.maxPassengers > 0) {
              $scope.countInput.maxPassengers--;
              if ($scope.countInput.maxPassengers < 6) {
                $scope.passengers.splice($scope.passengers.length - 1, 1);
              }
            }
          }
        };

        $scope.bagNumberDidChanged = function (isAdd) {
          if (isAdd) {
            if($scope.countInput.maxBags == $scope.selectedCar.bags_max){
              $scope.maxBagAlertContent = $filter('translate')('easybook_cars.jsMax_bags_alert');
              $ionicPopup.alert ({
                template: '<p>{{maxBagAlertContent}}</p>',
                cssClass: 'location-permission-popup',
                scope: $scope,
                buttons: [ {
                  text: 'OK',
                  type: 'button-positive',
                  onTap: function(e) {
                    console.log(e);
                  }
                }]
              });
            }
            if ($scope.countInput.maxBags < $scope.selectedCar.bags_max) {
              $scope.countInput.maxBags++;
            }
          } else {
            if ($scope.countInput.maxBags > 0) {
              $scope.countInput.maxBags--;
            }
          }
        };

        //ionic actionsheet for carCategorys
        $scope.showCarCategorysActionsheet = function () {
          var buttons = [];
          for (var i = 0; i < allCategorys.length; i++) {
            buttons.push({"text": allCategorys[i].car_category_name});
          }
          $ionicActionSheet.show({
            titleText: $filter('translate')('easybook_return_cars.jsSelect_car_category'),
            buttons: buttons,
            cancelText: $filter('translate')('easybook_return_cars.jsCancel'),
            buttonClicked: function (index) {
              selectedCarCategoryIndex = index;
              if ($scope.selectedCarCategory.car_category_id == allCategorys[index].car_category_id) {
                return true;
              }
              $scope.selectedCarCategory = allCategorys[index];
              $scope.cars = filterCars();

              if ($scope.cars.length > 0) {
                $ionicSlideBoxDelegate.update();
                $ionicSlideBoxDelegate.slide(0);
                selectedCarIndex = 0;
                $scope.integrateCarData(0);
                $scope.optionsTotalPrice = 0;
                $scope.hadSelectedOption = false;
                if ($scope.re_d_is_airport == 1) {
                  if ($scope.re_a_is_airport == 1) {
                    $scope.totalCost = ($scope.offer.basic_cost + $scope.offer.d_port_price + $scope.offer.a_port_price) * (1 + $scope.offer.tva / 100);
                  } else {
                    $scope.totalCost = ($scope.offer.basic_cost + $scope.offer.d_port_price) * (1 + $scope.offer.tva / 100);
                  }
                } else {
                  if ($scope.re_a_is_airport == 1) {
                    $scope.totalCost = ($scope.offer.basic_cost + $scope.offer.a_port_price) * (1 + $scope.offer.tva / 100);
                  } else {
                    $scope.totalCost = ($scope.offer.basic_cost) * (1 + $scope.offer.tva / 100);
                  }
                }
                // $scope.totalCost = $scope.offer.basic_cost * (1 + $scope.offer.tva / 100);
                if ($scope.totalCost > 0 && $scope.totalCost < 1) {
                  $scope.totalCost = 1.00;
                }
                $scope.hasCars = true;
              } else {
                $scope.hasCars = false;
              }
              return true;
            }
          });
        };

        //ionic actionsheet for carMakes
        $scope.showCarBrandsActionsheet = function () {
          var buttons = [];
          for (var i = 0; i < allBrands.length; i++) {
            buttons.push({"text": allBrands[i].car_brand_name});
          }
          $ionicActionSheet.show({
            titleText: $filter('translate')('easybook_return_cars.jsSelect_car_make'),
            buttons: buttons,
            cancelText: $filter('translate')('easybook_return_cars.jsCancel'),
            buttonClicked: function (index) {
              selectedCarBrandIndex = index;
              if ($scope.selectedCarBrand.car_brand_id == allBrands[index].car_brand_id) {
                return true;
              }
              $scope.selectedCarBrand = allBrands[index];
              $scope.cars = filterCars();
              if ($scope.cars.length > 0) {
                $ionicSlideBoxDelegate.update();
                $ionicSlideBoxDelegate.slide(0);
                selectedCarIndex = 0;
                $scope.integrateCarData(0);
                $scope.optionsTotalPrice = 0;
                $scope.hadSelectedOption = false;

                if ($scope.re_d_is_airport == 1) {
                  if ($scope.re_a_is_airport == 1) {
                    $scope.totalCost = ($scope.offer.basic_cost + $scope.offer.d_port_price + $scope.offer.a_port_price) * (1 + $scope.offer.tva / 100);
                  } else {
                    $scope.totalCost = ($scope.offer.basic_cost + $scope.offer.d_port_price) * (1 + $scope.offer.tva / 100);
                  }
                } else {
                  if ($scope.re_a_is_airport == 1) {
                    $scope.totalCost = ($scope.offer.basic_cost + $scope.offer.a_port_price) * (1 + $scope.offer.tva / 100);
                  } else {
                    $scope.totalCost = ($scope.offer.basic_cost) * (1 + $scope.offer.tva / 100);
                  }
                }
                // $scope.totalCost = $scope.offer.basic_cost * (1 + $scope.offer.tva / 100);
                if ($scope.totalCost > 0 && $scope.totalCost < 1) {
                  $scope.totalCost = 1.00;
                }
                $scope.hasCars = true;
              } else {
                $scope.hasCars = false;
              }
              return true;
            }
          });
        };

        $scope.slideHasChanged = function (index) {
          selectedCarIndex = index;
          $scope.integrateCarData(index);
          $scope.notes.text = '';
          $scope.optionsTotalPrice = $scope.calculateOptionsCost();
          if ($scope.optionsTotalPrice == 0) {
            $scope.hadSelectedOption = false;
          } else {
            $scope.hadSelectedOption = true;
          }

          if ($scope.re_d_is_airport == 1) {
            if ($scope.re_a_is_airport == 1) {
              $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost + $scope.offer.d_port_price + $scope.offer.a_port_price) * (1 + $scope.offer.tva / 100);
            } else {
              $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost + $scope.offer.d_port_price) * (1 + $scope.offer.tva / 100);
            }
          } else {
            if ($scope.re_a_is_airport == 1) {
              $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost + $scope.offer.a_port_price) * (1 + $scope.offer.tva / 100);
            } else {
              $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost) * (1 + $scope.offer.tva / 100);
            }
          }
          // $scope.totalCost = ($scope.optionsTotalPrice + $scope.offer.basic_cost) * (1 + $scope.offer.tva / 100);
          if ($scope.totalCost > 0 && $scope.totalCost < 1) {
            $scope.totalCost = 1.00;
          }
        };

        $scope.notesToggleDidChanged = function () {
          if (!$scope.notesToggle.isOpen) {
            $scope.notes.text = '';
          }
        };

        $scope.form_selectCar_submit = function () {
          EasybookService.enableReturnBookingParam();
          EasybookService.saveBookingCar($scope.selectedCar, true);
          //含税
          EasybookService.saveBookingCost($scope.totalCost, true);
          EasybookService.saveShowPrice($scope.totalCost, true);
          EasybookService.saveBookingNote($scope.notes.text, true);
          EasybookService.saveBookingPassengerCount($scope.countInput.maxPassengers, true);
          EasybookService.saveBookingPassengers($scope.passengers, true);
          EasybookService.saveBookingBagCount($scope.countInput.maxBags, true);
          EasybookService.saveBookingCouponCount($scope.coupon.couponCode, true);
          EasybookService.saveBookingCouponAmount($scope.rs_amountOff, true);
          EasybookService.saveBookingCouponPercent($scope.rs_percentOff, true);
          EasybookService.saveBookingOffer($scope.offer, true);

          var options = [];
          for (var i = 0; i < $scope.selectedCar.selectedOptions.length; i++) {
            var option = {};
            option.option_id = $scope.selectedCar.selectedOptions[i].option_id;
            option.name = $scope.selectedCar.selectedOptions[i].name;
            option.count = $scope.selectedCar.selectedOptions[i].count;
            options.push(option);
          }
          EasybookService.saveBookingOptions(options, true);

          //保存选择记录
          var selectedCache = {};
          selectedCache.carCategoryIndex = selectedCarCategoryIndex;
          selectedCache.carBrandIndex = selectedCarBrandIndex;
          selectedCache.carIndex = selectedCarIndex;
          selectedCache.noteIsOpen = $scope.notesToggle.isOpen;
          selectedCache.note = $scope.notes.text;
          selectedCache.options = $scope.selectedCar.options;
          selectedCache.selectedOptions = $scope.selectedCar.selectedOptions;
          if ($scope.re_d_is_airport == 1) {
            if ($scope.re_a_is_airport == 1) {
              selectedCache.basicCost = ($scope.offer.basic_cost + $scope.offer.d_port_price + $scope.offer.a_port_price) * (1 + $scope.offer.tva / 100);
            } else {
              selectedCache.basicCost = ($scope.offer.basic_cost + $scope.offer.d_port_price) * (1 + $scope.offer.tva / 100);
            }
          } else {
            if ($scope.re_a_is_airport == 1) {
              selectedCache.basicCost = ($scope.offer.basic_cost + $scope.offer.a_port_price) * (1 + $scope.offer.tva / 100);
            } else {
              selectedCache.basicCost = ($scope.offer.basic_cost) * (1 + $scope.offer.tva / 100);
            }
          }
          // selectedCache.basicCost = $scope.offer.basic_cost * (1 + $scope.offer.tva / 100);
          // selectedCache.basicCost = $scope.totalCost;
          selectedCache.optionsCost = $scope.optionsTotalPrice * (1 + $scope.offer.tva / 100);
          selectedCache.totalCost = $scope.totalCost;
          selectedCache.countInput = $scope.countInput;
          selectedCache.passengers = $scope.passengers;
          selectedCache.rs_couponCode = $scope.coupon.couponCode;
          selectedCache.rs_amountOff = $scope.rs_amountOff;
          selectedCache.rs_percentOff = $scope.rs_percentOff;
          EasybookService.returnServiceCache.selects = selectedCache;

          $ionicHistory.goBack();
        };

        $scope.initialize($stateParams.offers,
          $stateParams.car,
          $stateParams.appointedTime,
          $stateParams.passengerNumber,
          $stateParams.passengers,
          $stateParams.bagNumber,
          $stateParams.cache);

        function finalAddress(address) {
          var data = address.address_components;
          var finalAddressDate = [];

          //处理第一行
          //格式:'street_address route premise political'
          var line_1 = '';
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'street_number') {
              line_1 += data[i].long_name + '  ';
              break;
            }
          }
          var hasRoute = false;
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'route') {
              line_1 += data[i].long_name + ' ';
              hasRoute = true;
              break;
            }
          }

          if (!hasRoute) {
            for (var i = 0; i < data.length; i++) {
              if (data[i].types[0] == 'street_address') {
                line_1 += data[i].long_name + ' ';
                break;
              }
            }
          }

          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'premise') {
              line_1 += data[i].long_name + ' ';
              break;
            }
          }
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'political') {
              line_1 += data[i].long_name + ' ';
              break;
            }
          }
          finalAddressDate.push(line_1);

          //处理第二行
          //格式:'locality,administrative_area_level_1 postal_code'
          var line_2 = '';
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'locality') {
              line_2 += data[i].long_name;
              break;
            }
          }
          var hasState = false;
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'administrative_area_level_1') {
              line_2 += ',' + data[i].short_name;
              hasState = true;
              break;
            }
          }
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'postal_code') {
              if (hasState) {
                line_2 += ' ' + data[i].long_name;
              } else {
                line_2 += ',' + data[i].long_name;
              }
              break;
            }
          }
          finalAddressDate.push(line_2);
          return finalAddressDate;
        }



        $scope.promo_code_shown = false;
        $scope.showPromoCodeLine = function () {
          $scope.promo_code_shown = true;
          $scope.checkingCode = false;
        };

        $scope.dismissPromoCodeLine = function () {
          if ($scope.checkingCode) {
            return;
          }
          $scope.promo_code_shown = false;
          $scope.checkingCode = true;
        };
        $scope.coupon = {};
        $scope.rs_amountOff = 0;
        $scope.rs_percentOff = 0;

        $scope.getCouponCode = function ($event) {
          if($scope.company_id != User.company_id){
            $scope.checkingCode = false;
            $ionicPopup.alert({
              title: $filter('translate')('easybook_cars.jsPromotion_code_error'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
            return;
          }
          if ($scope.checkingCode) {
            return;
          }
          $scope.checkingCode = true;

          if ($scope.coupon.couponCode == null || $scope.coupon.couponCode == undefined || $scope.coupon.couponCode.trim(' ') == '') {
            $scope.checkingCode = false;
            $ionicPopup.alert({
              title: $filter('translate')('easybook_cars.jsPromotion_code_not_allow_null'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
            return;
          }
          EasybookService.verifyCoupon($scope.coupon.couponCode,function (result) {
            if (!result.result.valid) {
              $ionicPopup.alert({
                title: $filter('translate')('easybook_cars.jsPromotion_code_used'),
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            } else {
              if (result.result.percent_off == null) {
                $scope.rs_percentOff = 0;
              } else {
                $scope.rs_percentOff = result.result.percent_off;
              }
              $scope.rs_amountOff = result.result.amount_off / 100;
              $scope.haveVerifyCode = true;
            }
            $scope.checkingCode = false;
          }, function (error) {
            console.log(error);
            $scope.checkingCode = false;
            $ionicPopup.alert({
              title: $filter('translate')('easybook_cars.jsCoupon_code_not_valid'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
          });
        };




      }
    );
})();
