(function() {
  'use strict';

  angular.module('passengerApp')
    .controller('SignupCtrl',
      function($scope, $state, $ionicPopup, $cordovaCamera,
               StorageService,UserService, HttpService, $cordovaFileTransfer,
               $ionicActionSheet, $cordovaImagePicker,
               $ionicModal, $ionicLoading,LoginService,$filter) {


        $scope.avatar_url = null;
        $scope.newUserInfo = {};
        $scope.newUserInfo.first_name     = "";
        $scope.newUserInfo.last_name      = "";
        $scope.newUserInfo.email          = "";
        $scope.newUserInfo.password       = "";
        $scope.newUserInfo.passwordVerify       = "";
        $scope.newUserInfo.mobile         = "";
        $scope.newUserInfo.gender = 2;
        $scope.newUserInfo.timemode = 0;
        $scope.stringTimeMode = "24 Hr";
        $scope.country= StorageService.getCompanyInfo().country;
        if ($scope.newUserInfo.gender == 1) {
          $scope.newUserInfo.genderString = $filter('translate')('signup.jsMrs');
        } else {
          $scope.newUserInfo.genderString =  $filter('translate')('signup.jsMr');
        }
        $scope.newUserInfo.lang=localStorage.getItem('lang');

        // Show the action sheet
        $scope.addPhotoActionSheet = function() {
          var hideSheet = $ionicActionSheet.show({
            titleText: $filter('translate')('signup.jsAdd_photo'),
            buttons: [{
              text: $filter('translate')('signup.jsSelect_photo')
            }, {
              text: $filter('translate')('signup.jsTake_photo')
            }],
            cancelText: $filter('translate')('signup.jsCancel'),
            cancel: function() {
              console.log('photo upload cancelled');
            },
            buttonClicked: function(index) {
              if (index === 0) {
                $scope.pickPhoto();
                return true;

              }else if (index === 1) {
                $scope.addPicture();
                return true;
              }
            },
            destructiveButtonClicked: function() {
              return true;
            }

          });
        };

        $scope.selectTimeMode = function() {
          var hideSheet = $ionicActionSheet.show({
            titleText: "Time Mode",
            buttons: [{
              text: "24 Hr"
            }, {
              text: "12 Hr"
            }],
            cancelText: $filter('translate')('signup.jsCancel'),
            cancel: function() {
              console.log('photo upload cancelled');
            },
            buttonClicked: function(index) {
              if (index === 0) {
                $scope.newUserInfo.timemode = 0;

                $scope.stringTimeMode = "24 Hr";
                return true;

              }else if (index === 1) {
                $scope.newUserInfo.timemode = 1;

                $scope.stringTimeMode = "12 Hr";
                return true;
              }
            },
            destructiveButtonClicked: function() {
              return true;
            }

          });
        };

        //sourceType PHOTOLIBRAY . CAMERA
        $scope.addPicture = function() {
          var options = {
            quality: 50,
            destinationType: window.Camera.DestinationType.FILE_URI,
            sourceType: window.Camera.PictureSourceType.CAMERA, //window.PHOTOLIBRARY to test on emulator
            allowEdit: true,
            encodingType: window.Camera.EncodingType.JPEG,
            targetWidth: 240,
            popoverOptions: CameraPopoverOptions,
            saveToPhotoAlbum: true
          };

          $cordovaCamera.getPicture(options)
            .then(function(imageData) {
              console.log(imageData);
              $scope.avatar_url = imageData;
            }, function(err) {
              console.error(err);
            });
        };

        ////////////////////////////////////////
        ////I M A G E - P I C K E R
        ////////////////////////////////////////
        ////http://ngcordova.com/docs/plugins/imagePicker/
        $scope.pickPhoto = function() {
          var options = {
            maximumImagesCount: 1,
            width: 240,
            height: 240,
            quality: 50
          };

          $cordovaImagePicker.getPictures(options).then(function(results) {
            if(results[0] && results[0].length > 0){
              $scope.avatar_url = results[0];
            }else {
              console.log('User not selecet any photo');
            }
          }, function(error) {
            console.log('Error: ' + JSON.stringify(error));
          });
        };

        $scope.signupConfirm = function() {
          console.log($scope.newUserInfo)
          if(!$scope.newUserInfo.first_name){
            $ionicLoading.show({
              template: $filter('translate')('signup.h5first_name_required'),
              duration:1200
            });
            return;
          }
          if($scope.newUserInfo.first_name.length>50){
            $ionicLoading.show({
              template: $filter('translate')('signup.h5first_name_too_long'),
              duration:1200
            });
            return;
          }
          if(!$scope.newUserInfo.last_name){
            $ionicLoading.show({
              template: $filter('translate')('signup.h5last_name_required'),
              duration:1200
            });
            return;
          }
          if ($scope.newUserInfo.last_name.length>50) {
            $ionicLoading.show({
              template: $filter('translate')('signup.h5last_name_too_long'),
              duration:1200
            });
            return;
          }
          if(!$scope.newUserInfo.email){
            $ionicLoading.show({
              template: $filter('translate')('signup.h5email_required'),
              duration:1200
            });
            return;
          }
          var reg = new RegExp("^[0-9a-z][_.0-9a-z-]{0,31}@([0-9a-z][0-9a-z-]{0,30}[0-9a-z]\.){1,4}[a-z]{2,4}$");
          if(!reg.test($scope.newUserInfo.email)){
            $ionicLoading.show({
              template: $filter('translate')('signup.h5enter_valid_email'),
              duration:1200
            });
            return;
          }
          if(!$scope.newUserInfo.password){
            $ionicLoading.show({
              template: $filter('translate')('signup.h5password_required'),
              duration:1200
            });
            return;
          }
          if ($scope.newUserInfo.password.length<6) {
            $ionicLoading.show({
              template: $filter('translate')('signup.h5password_too_short'),
              duration:1200
            });
            return;
          }
          if ($scope.newUserInfo.password.length>16) {
            $ionicLoading.show({
              template: $filter('translate')('signup.h5password_too_long'),
              duration:1200
            });
            return;
          }
          if(!$scope.newUserInfo.passwordVerify){
            $ionicLoading.show({
              template: $filter('translate')('signup.h5does_not_match'),
              duration:1200
            });
            return;
          }
          if ($scope.newUserInfo.password != $scope.newUserInfo.passwordVerify) {
            $ionicLoading.show({
              template:  $filter('translate')('signup.jsMake_sure_password'),
              duration:1200
            });
            return;
          }
          if(!$scope.newUserInfo.mobile){
            $ionicLoading.show({
              template: $filter('translate')('signup.h5enter_mobile_number'),
              duration:1200
            });
            return;
          }
          var tleReg = new RegExp("^[0-9]{5,18}$");
          if (!tleReg.test($scope.newUserInfo.mobile.replace(/\s/g, ""))) {
            $ionicLoading.show({
              template: $filter('translate')('signup.h5enter_valid_digits'),
              duration:1200
            });
            return;
          }

          $ionicLoading.show({
            template: $filter('translate')('signup.jsSubmit')
          });
          $scope.newUserInfo.mobile = $scope.newUserInfo.mobile.replace(/\s/g, "");
          //signup
          HttpService.post(Api.register, $scope.newUserInfo, function(response) {
            LoginService.login($scope.newUserInfo.email, $scope.newUserInfo.password, function (loginResponse) {
              if($scope.avatar_url && $scope.avatar_url.length > 0){
                //upload avatar
                uploadPicture($scope.avatar_url,function(picResponse){
                  $scope.avatar_url = null;
                  $scope.newUserInfo = {};
                  $ionicLoading.hide();
                  var code = picResponse.code;
                  var avatar = picResponse.result;
                  if(code == 2000){
                    UserService.setAvatar(avatar);
                  }
                  $state.go("app.easybook");
                },function(error){
                  $scope.avatar_url = null;
                  $scope.newUserInfo = {};
                  $ionicLoading.hide();
                  console.log(error);
                  $state.go("app.easybook");
                });
              }else {
                //go to easybook when login success
                $scope.newUserInfo = {};
                $ionicLoading.hide();
                $state.go("app.easybook");
              }
            }, function (errorString,loginResponse) {
              $scope.avatar_url = null;
              $scope.newUserInfo = {};
              $ionicLoading.hide();
              $ionicPopup.alert({
                title: $filter('translate')('signup.jsSign_up_success'),
                okText: $filter('translate')('ionicPopup.jsOK')
              });
              //back to login when login fault
              $state.go("login");
            });
          }, function(errorString,response) {
            $ionicLoading.hide();
            if(errorString){
              $ionicPopup.alert({
                title: errorString,
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            }else {
              $ionicPopup.alert({
                title: $filter('translate')('signup.jsSign_up_fault'),
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            }
          });

        };

        //upload photo to server
        function uploadPicture(imageURI,successHandle,faultHandle) {
          console.log("=====");
          console.log($scope.avatar_url);
          console.log(imageURI);
          console.log("=====");
          var options = {
            fileKey: 'avatar',
            fileName: 'avatar.jpeg',
            httpMethod: 'POST',
            params: {
              token: UserService.getLoginUser().token,
              avatar: imageURI
            }
          };
          $cordovaFileTransfer.upload(Api.addAvatar, imageURI, options)
            .then(function(re) {
              var response = JSON.parse(re.response);
              successHandle(response);
            }, function(error) {
              faultHandle(error);
            })
        }

        //change gender
        $scope.showGenderActionSheet = function () {
          $ionicActionSheet.show({
            titleText: $filter('translate')('signup.jsSelect_gender'),
            buttons: [{
              text: $filter('translate')('signup.jsMrs')
            }, {
              text:  $filter('translate')('signup.jsMr')
            }],
            cancelText: $filter('translate')('signup.jsCancel'),
            cancel: function () {
            },
            buttonClicked: function (index) {
              if (index == 0) {
                $scope.newUserInfo.gender = 1;
                $scope.newUserInfo.genderString = $filter('translate')('signup.jsMrs');
              } else {
                $scope.newUserInfo.gender = 2;
                $scope.newUserInfo.genderString = $filter('translate')('signup.jsMr');
              }
              return true;
            },
            destructiveButtonClicked: function () {
              return true;
            }
          });
        };

        $scope.formatPhone = function () {
          $scope.newUserInfo.mobile = $filter('phoneNumFormatter')($scope.newUserInfo.mobile, $scope.country);
        }
      });
})();
