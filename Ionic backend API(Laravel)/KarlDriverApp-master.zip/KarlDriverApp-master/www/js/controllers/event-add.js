// IIFE START //
(function () {
  'use strict';

  angular.module('starter')
    .controller('AddEventCtrl',
      function ($scope, $timeout, $ionicSideMenuDelegate, $state, $ionicPopup, $ionicLoading, $ionicActionSheet, $ionicHistory, CalendarService, UserService,LoginService,$filter) {
        $scope.content = {
          value: ""
        };
        $scope.datetime = {
          startDatetimeValue: "",
          endDatetimeValue: ""
        };
        $scope.pickerTitle=$filter('translate')('event_add.jsPickerTitle');
        $scope.buttonOk=$filter('translate')('event_add.jsButtonOk');
        $scope.buttonCancel=$filter('translate')('event_add.jsButtonCancel');
        //重复类型选择
        var buttons = [
          {text:  $filter('translate')('event_add.jsNo_repeat'), value: ""},
          {text: $filter('translate')('event_add.jsDay'), value: 0},
          {text: $filter('translate')('event_add.jsWeek'), value: 1},
          {text: $filter('translate')('event_add.jsMonth'), value: 2},
          {text: $filter('translate')('event_add.jsYear'), value: 3}
        ];
        $scope.type = buttons[0];
        $scope.selectRepeat = function () {
          // Show the action sheet
          var hideSheet = $ionicActionSheet.show({
            buttons: buttons,
            buttonClicked: function (index) {
              console.log(buttons[index]);
              $scope.type = buttons[index];
              return true;
            },
            cancelText: $filter('translate')('event_add.jsCancel'),
            cancel: function () {
              // add cancel code..
            }
          });
        };

        //日历日期选择
        var date = new Date();
        date.setHours(date.getHours() + 1);
        date.setMinutes(0);
        $scope.datetime.startDatetimeValue = date;

        var date2 = new Date(date);
        date2.setHours(date2.getHours() + 1);
        $scope.datetime.endDatetimeValue = date2;


        $scope.eventSubmit = function () {

          if ($scope.content.value == "") {
            $ionicPopup.alert({
              title: $filter('translate')('event_add.jsContent_empty'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
            return;
          }

          if ($scope.type.value == 1) {
            $scope.repeatDays = new Date($scope.datetime.startDatetimeValue).getDay() + 1;
          } else {
            $scope.repeatDays = "";
          }

          CalendarService.addCalendarEvent(
            {
              start_time: parseInt((new Date($scope.datetime.startDatetimeValue).valueOf() + "").substr(0, 10)),
              end_time: parseInt((new Date($scope.datetime.endDatetimeValue).valueOf() + "").substr(0, 10)),
              content: $scope.content.value,
              owner_id: UserService.getLoginUser().driver.driver_id,
              repeat_type: $scope.type.value,
              repeat_days: $scope.repeatDays,
              time_zone: jstz.determine().name()
            }, function (response) {
              $ionicLoading.show({
                template: $filter('translate')('event_add.jsAdd_event_success')
              });
              $timeout(function () {
                $ionicLoading.hide();
              }, 2000);
              $ionicHistory.goBack();
            }, function (errorString,response) {
              if(!LoginService.logoutWhenAuthExpired(response.code)){
                if(errorString){
                  $ionicPopup.alert({
                    title: errorString,
                    okText: $filter('translate')('ionicPopup.jsOK')
                  });
                }else {
                  $ionicPopup.alert({
                    title: $filter('translate')('event_add.jsAdd_event_fault'),
                    okText: $filter('translate')('ionicPopup.jsOK')
                  });
                }
              }
            });
        }
      });
})();
