StripeInfo={
    card_url:'https://api.stripe.com/v1/tokens',
    publish_key : 'pk_live_OPMfJbR7x1fu61Mf197QRiln',
};

WebsiteUrl = "http://karl.limo";
DashboardUrl ='http://karldash.com';
