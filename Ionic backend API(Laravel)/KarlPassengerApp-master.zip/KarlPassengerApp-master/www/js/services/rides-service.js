/**
 * Created by wangyuanzhi on 16/3/5.
 */
(function() {
  'use strict';
  angular.module('passengerApp')
    .service('RidesService', function(HttpService) {

      var self = this;

      self.getRidesData = function(params,successHandle,faultHandle){
        HttpService.get(Api.bookRides,params,function (response) {
          if (response.code != 2100) {
            angular.forEach(response.result.bookings, function (booking) {
              if (booking.d_address) {
                if(booking.d_address.indexOf('formatted_address') > 0){
                  booking.d_address = JSON.parse(booking.d_address);
                }
              }
              if (booking.a_address) {
                if(booking.a_address.indexOf('formatted_address') > 0){
                  booking.a_address = JSON.parse(booking.a_address);
                }
              }
            });
          }
          successHandle(response);
        },faultHandle);
      }
    });
})();
