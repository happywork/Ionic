'use strict';

/**
 * Created by Alur on 2017-12-10.
 */
angular.module('EasySignUp.Services', []);
