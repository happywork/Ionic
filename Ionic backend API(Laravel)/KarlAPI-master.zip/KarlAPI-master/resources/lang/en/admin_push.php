<?php
/**
 * Created by PhpStorm.
 * User: lqh
 * Date: 2017/7/6
 * Time: 上午9:59
 */

return [
    "driverStartTrip"=>"It looks like one of your drivers has started a trip! Go to your Home page to track their location!",
    "driverStartTripTitle"=>"A Trip has started!",

    "comNewBookingTitle"=>"Your company has a new booking",
    "comNewBooking"=>"A new booking has been made! Go to your dashboard's calendar to review the details!",

    "anNoticeTitle"=>"Immediate Attention Needed!",
    "anNotice"=>"Immediate Attention Needed! An affiliate partner has sent a booking back to you. Go to your dashboard's calendar to resolve the matter.",

    "groupSycTitle"=>"MailChimp synch completed!",
    "groupSyc"=>"Customers have sync to MailChimp!",

    "groupSycFieldTitle"=>"MailChimp Sync Fail",
    "groupSycField"=>"Please check your MailChimp Setting"
];