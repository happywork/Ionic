(function () {
  'use strict';
  angular.module('starter')
    .controller('BookingDetailCtrl',
      function ($scope, $stateParams, $ionicHistory, $state, $ionicPopup, $ionicLoading, $timeout, BookingsService, TripService, MapService, LoginService, UserService,$filter) {
        $scope.canEnterTrip = true;
        $scope.$on('$ionicView.beforeEnter', function () {
          $timeout(function () {
            if (!map) {
              loadMap();
            }
            $scope.currentBooking = $stateParams.booking;
            if($scope.currentBooking.d_address.address_components){
              $scope.isLangAddress = false;
            }else{
              $scope.isLangAddress = true;
            }
            if($scope.currentBooking.hide_driver_fee == 0){
              $scope.isDisplayCost = true;
            }if($scope.currentBooking.hide_driver_fee == 1){
              $scope.isDisplayCost = false;
            }
            if ($scope.currentBooking.exe_company_id != $scope.currentBooking.own_company_id) {
              $scope.companyRemind = $filter('translate')('booking_detail.jsPassenger_from', {name: $scope.currentBooking.own_company_name});
            } else {
              $scope.companyRemind = '';
            }

            if (TripService.currentTrip && TripService.currentTrip.tripState > 0 && TripService.currentTrip.tripState <= 4) {
              if (TripService.currentTrip.bookingId == $scope.currentBooking.id) {
                $scope.canEnterTrip = true;
              } else {
                $scope.canEnterTrip = false;
              }
            } else {
              if ($scope.currentBooking.trip_state >= 0 && $scope.currentBooking.trip_state <= 4) {
                $scope.canEnterTrip = true;
              } else {
                $scope.canEnterTrip = false;
              }
            }

            if ($scope.currentBooking.type > 1) {
              if ($scope.currentBooking.type == 2) {
                $scope.currentBookingType = $filter('translate')('booking_detail.jsHourly');
              } else {
                $scope.currentBookingType = $filter('translate')('booking_detail.jsCUSTOM_QUOTE');
              }

              //标记起点
              var pickupMarker = new google.maps.Marker({
                position: {lat: $scope.currentBooking.d_lat, lng: $scope.currentBooking.d_lng},
                map: map
              });
              map.setCenter({lat: $scope.currentBooking.d_lat, lng: $scope.currentBooking.d_lng});
            } else {
              $scope.currentBookingType = $filter('translate')('booking_detail.jsTransfer');

              //绘制线路
              var startLatlng = new google.maps.LatLng({
                lat: $scope.currentBooking.d_lat,
                lng: $scope.currentBooking.d_lng
              });
              var endLatlng = new google.maps.LatLng({
                lat: $scope.currentBooking.a_lat,
                lng: $scope.currentBooking.a_lng
              });
              MapService.calculateAndDisplayRoute(map, directionsService, directionsDisplay, startLatlng, endLatlng);
            }
          }, 0);
        });

        //Fix Map
        function resizeMapFix() {
          $timeout(function () {
            angular.element($("#booking-detail-map")).css("height", window.screen.availHeight * 0.4 + "px");
            angular.element($("#booking-detail-map")).css("left", window.screen.availWidth * 0.05 + "px");
            angular.element($("#booking-detail-map")).css("width", window.screen.availWidth * 0.9 + "px");
          }, 0);
        }

        resizeMapFix();

        //init DirectionsService,DirectionsRenderer,Map
        var directionsService = new google.maps.DirectionsService;
        var directionsDisplay = new google.maps.DirectionsRenderer;
        var map;
        var mapCenter = {lat: 34.1017614, lng: -118.3450541};

        //load map
        function loadMap() {
          map = new google.maps.Map(document.getElementById('booking-detail-map'), {
            zoom: 12,
            center: mapCenter,
            draggable: false,
            mapTypeControl: false,
            disableDefaultUI: true
          });
          directionsDisplay.setMap(map);
        }

        $scope.enterCurrentTrip = function () {
          var requestParams = {
            "start_time": parseInt($scope.currentBooking.appointed_at - 1),
            "end_time": parseInt($scope.currentBooking.appointed_at + 1),
            "trip_state": '0,1,2,3,4'
          };
          $ionicLoading.show();
          BookingsService.loadBookings(requestParams, function (response) {
            $ionicLoading.hide();
            if (response.code == 2100) {
              $scope.canEnterTrip = false;
              $ionicPopup.alert({
                title: $filter('translate')('booking_detail.jsBooking_end'),
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            } else {
              if (response.result.bookings[0].id == $scope.currentBooking.id) {
                $ionicHistory.nextViewOptions({
                  disableAnimate: false,
                  disableBack: true,
                  historyRoot: true
                });
                $state.go('app.current-trip', {"booking": angular.copy($scope.currentBooking)});
              } else {
                $scope.canEnterTrip = false;
                $ionicPopup.alert({
                  title: $filter('translate')('booking_detail.jsBooking_end'),
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
              }
            }
          }, function (errorString, response) {
            $ionicLoading.hide();
            if (!LoginService.logoutWhenAuthExpired(response.code)) {
              if (errorString) {
                $ionicPopup.alert({
                  title: errorString,
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
              } else {
                $ionicPopup.alert({
                  title: $filter('translate')('booking_detail.jsRequest_clients_fault'),
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
              }
            }
          });
        }
      });
})();
