# KARL Driver APP

This project is Driver APP for KARL. 

This project will publish both iOS & Android APPs.

## About KARL

For more information, see http://www.karl.limo

## About Passenger APP

This project is private property of KARL, which is technical support by Inov.tech, 
see http://www.inov.tech

This project is:
- Language: JavaScript, CSS;
- IDE: WebStorm;
- Main Framework: IONIC1.


## Contact

CTO of Inov.tech: heroalur@qq.com