<?php
/**
 * Created by PhpStorm.
 * User: lqh
 * Date: 2017/3/24
 * Time: 下午2:19
 */

namespace App\Method;


class MainChimpMethod
{
    public static function createList($url,$listName)
    {
        return "";
    }

    public static function addMemberToList($url,$listId,$email)
    {

    }
}