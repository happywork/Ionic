#### Create your own theme and put it into a subfolder here.

For example ```/myawesometheme/angular-datepicker.css```
