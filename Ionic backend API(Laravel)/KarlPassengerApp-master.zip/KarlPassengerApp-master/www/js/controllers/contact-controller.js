(function () {
  'use strict';

  angular.module('passengerApp')
    .controller('ContactCtrl',
      function ($scope, $state, $ionicLoading, $ionicPopup, $cordovaSms, ContactService, LoginService,UserService,$filter) {

        $ionicLoading.show({
          template: $filter('translate')('contact.jsFetching')
        });
        ContactService.getCompanyDetail(function (response) {
          $ionicLoading.hide();
          var userObject = response.result;
          $scope.telephone = userObject.phone1;
          $scope.companyEmail = userObject.email;
          $scope.smsPhone = userObject.phone1;
        }, function (errorString, response) {
          $ionicLoading.hide();
          if (!LoginService.logoutWhenAuthExpired(response.code)) {
            if(errorString){
              $ionicPopup.alert({
                title: errorString,
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            }else {
              $ionicPopup.alert({
                title: $filter('translate')('contact.jsRequest_fault'),
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            }
          }
        });

        $scope.sendSMS = function () {
          ContactService.sendText($scope.smsPhone + '', '');
        };
      });
})();
