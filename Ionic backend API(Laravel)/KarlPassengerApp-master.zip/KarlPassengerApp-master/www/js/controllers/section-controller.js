(function () {
  "use strict";
  angular.module('passengerApp')
    .controller('SectionCtrl', function ($scope,$ionicPlatform, $window, $ionicModal, $ionicPopup, $timeout, $state,
                                     ContactService, UserService,ConciergeService) {
      $timeout(function () {
        var sectionHeight = 0.0;
        if($ionicPlatform.is('android')){
          sectionHeight =   (window.screen.availHeight - 64.0)/2;
        }else if($ionicPlatform.is('ios')){
          sectionHeight =   (window.screen.availHeight - 70.0)/2;
        }
        angular.element($("#section_concierge")).css("height",sectionHeight+"px");
        angular.element($("#section_car")).css("height",sectionHeight+"px");

      },0);

      console.log("", $window.screen.height);
      var user = UserService.getLoginUser();
      $scope.companyName = user.company_name;
      $scope.goToConciergeService = function(){
        $state.go("app.easybook");
        var confirmPopup = $ionicPopup.confirm({
          title: $filter('translate')('section.jsPrivate_concierge'),
          template: $filter('translate')('section.jsConcierge_info')
        });
        confirmPopup.then(function(res) {
          confirmPopup.close();
          if(res) {
            ContactService.sendText(ConciergeService.conciergeNumber,"");
          }
        });
      };
      $scope.goToCarService = function(){
        $state.go("app.easybook");
      };
    });
})();
