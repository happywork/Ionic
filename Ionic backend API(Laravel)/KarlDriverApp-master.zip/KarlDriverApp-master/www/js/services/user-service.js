(function () {
  "use strict";
  angular.module('starter').service('UserService', function ($localStorage,$ionicPickerI18n,$translate) {

    var self = this;

    self.getLoginUser = function () {
      if (!this.user) {
        this.user = $localStorage.user;
      }
      return this.user;
    };

    //saveLoginUser
    self.saveLoginUser = function (userObject) {
      // todo
      console.log(userObject)
      if(userObject.lang=='en'){
        $ionicPickerI18n.weekdays = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
        $ionicPickerI18n.months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
      } else {
        $ionicPickerI18n.weekdays = ["Di", "Lu", "Ma", "Me", "Je", "Ve", "Sa"];
        $ionicPickerI18n.months = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
      }
      $translate.use(userObject.lang);
      moment.locale(userObject.lang);
      localStorage.setItem('lang',userObject.lang);
      this.user = userObject;
      $localStorage.user = userObject;
    };

    //clearLoginUser
    self.clearLoginUser = function () {
      delete $localStorage.user;
      delete this.user;
    };

    // set users avatar on sidemenu
    self.setAvatar = function (avatarURI) {
      var user = self.getLoginUser();
      user.avatar_url = avatarURI;
      self.saveLoginUser(user);
    }
  });
})();
