/**
 * Created by wangyuanzhi on 16/2/27.
 */
angular.module('starter')
  .controller('MapLocateCtrl', function ($scope, $rootScope,$stateParams,$ionicHistory, $ionicPlatform, $timeout, LocationService,UserService,$filter) {
    var selectLocationMap;
    var geocoder = new google.maps.Geocoder;
    var locateResult;

    $scope.location = {};
    $scope.loadding = true;
    $scope.$on('$ionicView.beforeLeave', function () {
      $scope.$broadcast('CancelLocate');
    });

    $scope.initialize = function (latlng) {
      selectLocationMap = new google.maps.Map(document.getElementById('map_locate'), {
        zoom: 12,
        center: latlng,
        mapTypeControl: false
      });

      $('<div/>').addClass('centerMarker').appendTo(selectLocationMap.getDiv());

      $scope.initMapListener(selectLocationMap);
      $scope.geocodeAddress(selectLocationMap.getCenter());
    };

    $scope.initMapListener = function (map) {
      google.maps.event.addListener(map, 'center_changed', function () {
        $scope.geocodeAddress(map.getCenter());
      });

      google.maps.event.addListener(map, 'dragstart', function () {
        $timeout(function () {
          $scope.loadding = true;
          $scope.placeholder = $filter('translate')('map_locate.jsLoading_locations');
          $scope.location.address = "";
          angular.element($("#locateInputID")).val("");
          angular.element($("#locateInputID")).attr('placeholder', "Loading locations...");
        }, 0);
      });
    };

    $scope.locate = function (location) {
      selectLocationMap.setCenter({lat: location.latlng.lat, lng: location.latlng.lng}, 12);
    };

    $scope.geocodeAddress = function (latlng) {
      geocoder.geocode({'location': latlng}, function (results, status) {
          if (status === google.maps.GeocoderStatus.OK || status === google.maps.GeocoderStatus.ZERO_RESULTS) {
            if (results[0]) {
              $timeout(function () {
                $scope.loadding = false;
                $scope.location.address = results[0].formatted_address;
                angular.element($("#locateInputID")).val(results[0].formatted_address);
                locateResult = results[0];
              }, 0);
            } else {
              // Noting to do
            }
          } else {
            console.log(error);
          }
        }
      );
    };

    $scope.done = function () {
      if (locateResult && $stateParams.locateSuccessEvent) {
        $stateParams.locateSuccessEvent(locateResult);
      }
      $ionicHistory.goBack();
    };

    $scope.locationPlaceholder = $filter('translate')('map_locate.jsLoading_locations');
    $timeout(function () {
      angular.element($("#locateInputID")).css("width", window.screen.availWidth - 95.0 + "px");
      if ($ionicPlatform.is('android')) {
        angular.element($("#map_locate_background")).css("height", window.screen.availHeight - 64.0 + "px");
        angular.element($("#map_locate")).css("margin-top", 64.0 - window.screen.availHeight + "px");
        angular.element($("#map_locate")).css("height", window.screen.availHeight - 64.0 + "px");
      } else {
        angular.element($("#map_locate_background")).css("height", window.screen.availHeight - 44.0 + "px");
        angular.element($("#map_locate")).css("margin-top", 44.0 - window.screen.availHeight + "px");
        angular.element($("#map_locate")).css("height", window.screen.availHeight - 44.0 + "px");
        if (window.StatusBar) {
          angular.element($("#locateInputID")).css("top", 26.0 + "px");
        }
      }
    }, 0);

    LocationService.getCurrentPosition(function (position) {
      var latlng = {
        lat: position.coords.latitude,
        lng: position.coords.longitude
      };
      $scope.initialize(latlng);
    }, function (error) {
      var latlng = {
        lat: 34.1017614,
        lng: -118.3450541
      };
      $scope.initialize(latlng);
      console.log('Locate fault!!!!');
    });
  });
