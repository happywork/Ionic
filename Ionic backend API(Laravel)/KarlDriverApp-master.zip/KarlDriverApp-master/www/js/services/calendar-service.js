// IIFE START //
(function () {
  'use strict';
  angular.module('starter')
    .service("CalendarService", function ($http, $q, $filter, HttpService) {

      var self = this;
      self.addCalendarEvent = function (params,successHandle, faultHandle) {
        HttpService.post(Api.addCalendarEvent, params, successHandle, faultHandle);
      };

      self.deleteCalendarEvent = function (id,params,successHandle, faultHandle) {
        HttpService.delete(Api.deleteCalendarEvent + "/"  + id, params, successHandle, faultHandle);
      };
    });
})();
