Api = {
  login: ApiServer.serverUrl + ApiServer.version + '/driver/login',
  logout: ApiServer.serverUrl + ApiServer.version + '/logout',
  driverUpdate: ApiServer.serverUrl + ApiServer.version + '/drivers/info',
  addAvatar: ApiServer.serverUrl + ApiServer.version + '/drivers/avatar',
  bookRides: ApiServer.serverUrl + ApiServer.version + '/drivers/bookings',
  bookEventRides: ApiServer.serverUrl + ApiServer.version + '/drivers/calendars/events',
  addCalendarEvent: ApiServer.serverUrl + ApiServer.version + '/drivers/calendars/events',
  deleteCalendarEvent: ApiServer.serverUrl + ApiServer.version + '/drivers/calendars/events',
  uploadDrvierLocation: ApiServer.serverUrl + ApiServer.version + '/companies/orders/driver/location',
  uploadTripState: ApiServer.serverUrl + ApiServer.version + '/order/state',
  uploadPushToken: ApiServer.serverUrl + ApiServer.version + '/users/device/',
  resetPassword: ApiServer.serverUrl + ApiServer.version + '/driver/template/password',
  checkAppVersion: ApiServer.serverUrl +"/app/check/update/driver/",
  getAppUrl: ApiServer.serverUrl +"/app/company/0/"
};
