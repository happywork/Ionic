(function () {
  'use strict';
  angular.module('passengerApp')
    .controller("TripFeedBackCtrl", function ($scope, $state,$stateParams, $ionicLoading, $ionicPopup, $ionicHistory, $ionicSideMenuDelegate, TripFeedbackService,LoginService,UserService,$filter) {
      var driverAndCar = $stateParams.params;
      $scope.driverData = driverAndCar.driverData;
      $scope.carImg = driverAndCar.carImg;
      $scope.carName = driverAndCar.carName;
      $scope.notes = {};
      $scope.notes.text = '';

      $scope.appearanceObject = {
        callback: function (rating) {    //Mandatory
          $scope.ratingsCallback(rating, 0);
        }
      };

      $scope.professionalismObject = {
        callback: function (rating) {
          $scope.ratingsCallback(rating, 1);
        }
      };

      $scope.drivingAbilityObject = {
        callback: function (rating) {
          $scope.ratingsCallback(rating, 2);
        }
      };
      $scope.cleanlinessObject = {
        callback: function (rating) {
          $scope.ratingsCallback(rating, 3);
        }
      };
      $scope.qualityObject = {
        callback: function (rating) {
          $scope.ratingsCallback(rating, 4);
        }
      };

      var feedbackParams = {};
      feedbackParams.appearance = 2;
      feedbackParams.professionalism = 2;
      feedbackParams.driving_ability = 2;
      feedbackParams.cleanliness = 2;
      feedbackParams.quality = 2;
      feedbackParams.booking_id = driverAndCar.bookingId;

      $scope.ratingsCallback = function (rating, type) {
        if (type == 0) {
          feedbackParams.appearance = rating*2;
        } else if (type == 1) {
          feedbackParams.professionalism = rating*2;
        } else if (type == 2) {
          feedbackParams.driving_ability = rating*2;
        } else if (type == 3) {
          feedbackParams.cleanliness = rating*2;
        } else if (type == 4) {
          feedbackParams.quality = rating*2;
        } else {
          //nothing to do
        }
      };

      $scope.cancel = function () {
        $ionicHistory.nextViewOptions({
          disableAnimate:true,
          disableBack:true,
          historyRoot:true
        });
        $state.go('app.easybook');
      };

      //send feedback
      $scope.form_feedback_submit = function () {
        feedbackParams.comment = $scope.notes.text;
        $ionicLoading.show({
          template: $filter('translate')('trip_feedback.jsSubmit')
        });
        TripFeedbackService.feedback(feedbackParams, function (response) {
          $ionicLoading.hide();
          $ionicPopup.alert({
            title: $filter('translate')('trip_feedback.jsThank_you'),
            okText: $filter('translate')('ionicPopup.jsOK')
          }).then(function (res) {
            $ionicHistory.nextViewOptions({
              disableAnimate:true,
              disableBack:true,
              historyRoot:true
            });
            $state.go('app.easybook');
          });
        }, function (errorString,response) {
          $ionicLoading.hide();
          if(!LoginService.logoutWhenAuthExpired(response.code)){
            if(errorString){
              $ionicPopup.alert({
                title: errorString,
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            } else {
              $ionicPopup.alert({
                title: $filter('translate')('trip_feedback.jsFeedback_fault'),
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            }
          }
        });
      }
    });
})();
