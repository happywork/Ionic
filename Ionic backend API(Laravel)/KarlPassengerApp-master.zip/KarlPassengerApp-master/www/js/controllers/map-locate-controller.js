/**
 * Created by wangyuanzhi on 16/2/27.
 */
angular.module('passengerApp')
  .controller('MapLocateCtrl', function ($scope, $stateParams, $ionicHistory, StorageService,
                                         $ionicPlatform, $timeout,
                                         EasybookService, LocationService,UserService,$ionicLoading,
                                         $filter,$ionicPopup,$rootScope) {
    var selectLocationMap;
    var geocoder = new google.maps.Geocoder;
    var locateResult;
    var tempLocation;
    var addressObj = undefined;
    var dropSelected = false;
    $scope.location = {};
    $scope.loadding = true;

    $scope.$on('$ionicView.afterEnter', function() {
      function getPos () {
        $scope.initialize = function (latlng) {
          selectLocationMap = new google.maps.Map(document.getElementById('map_locate'), {
            zoom: 12,
            center: latlng,
            mapTypeControl: false
          });

          $('<div/>').addClass('centerMarker').appendTo(selectLocationMap.getDiv());

          $scope.initMapListener(selectLocationMap);
          $scope.geocodeAddress(selectLocationMap.getCenter());
        };
        var latlng={};
        if(localStorage.getItem('ngStorage-currentPosition')){
          var positions=JSON.parse(localStorage.getItem('ngStorage-currentPosition'));
          latlng = {lat:positions.coords.latitude, lng:positions.coords.longitude}
        }/*else {
          latlng = {lat: 34.1017614, lng: -118.3450541};
        }*/
        $scope.initialize(latlng);
      }
      getPos();

      LocationService.getCurrentPosition(function (position) {
        var latlng = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };
        console.log(latlng);
        selectLocationMap.setCenter(latlng);
        $scope.initMapListener(selectLocationMap);
        $scope.geocodeAddress(selectLocationMap.getCenter());
      }, function (error) {
        // $ionicLoading.show({
        //   template: $filter('translate')('map_locate.jsGet_position_error'),
        //   duration:1000
        // });
        $ionicPopup.alert({
          title: $filter('translate')('map_locate.jsGet_position_error'),
          okText: $filter('translate')('ionicPopup.jsOK')
        });
        console.log('Locate fault!!!!');
      });

    });

    $scope.$on('$ionicView.beforeLeave', function () {
      $scope.$broadcast('CancelLocate');
    });

    $scope.initMapListener = function (map) {
      google.maps.event.addListener(map, 'center_changed', function () {
        if(dropSelected){
          $scope.geocodeAddress(map.getCenter());
        }else{
          afterGetLocation();
        }
        dropSelected = false;
      });
      google.maps.event.addListener(map, 'dragstart', function () {
        dropSelected = true;
        $timeout(function () {
          $scope.loadding = true;
          $scope.placeholder = $filter('translate')('map_locate.jsLoading_locations');
          $scope.location.address = "";
          angular.element($("#locateInputID")).val("");
          angular.element($("#locateInputID")).attr('placeholder', $filter('translate')('map_locate.jsLoading_locations'));
        }, 0);
      });
    };

    $scope.locate = function (location) {
      addressObj = location;
      tempLocation = location;
      dropSelected = false;

      selectLocationMap.setCenter({lat: location.latlng.lat, lng: location.latlng.lng}, 12);
    };

    $scope.geocodeAddress = function (latlng) {
      geocoder.geocode({'location': latlng}, function (results, status) {
          if (status === google.maps.GeocoderStatus.OK || status === google.maps.GeocoderStatus.ZERO_RESULTS) {
            if (results[0]) {
              $timeout(function () {
                $scope.loadding = false;
                addressObj = results[0];
              }, 0);
            } else {
              // nothing to do
            }
          } else {
            console.log(google.maps.GeocoderStatus);
          }
        }
      );
    };

    $scope.done = function () {
      //save location to EasybookService
      if (locateResult) {
        if ($stateParams.locateType == 'pickup') {
          EasybookService.savePickupLocation(locateResult);
        } else if ($stateParams.locateType == 'dropoff') {
          EasybookService.saveDropoffLocation(locateResult);
        } else if ($stateParams.locateType == LocateType.billing_address){
          //...
          UserService.setBillingAddress(addressObj);
        }

        $scope.addLocationHistory(tempLocation);
      }
      $ionicHistory.goBack(clearStyle());
    };

    $rootScope.$ionicGoBack = function() {
      $ionicHistory.goBack(clearStyle());
    };

    function adjustmentNavBar() {
      angular.element($(".bar.bar-dark")).css("height",75+'px');
      angular.element($(".item-input-inset")).css("height",75+'px');
      angular.element($(".has-header")).addClass('android-bar-has-header-top');
      angular.element($("#locateInputID")).css("top", 13.0 + "px");
      angular.element($("#locateInputID")).css("height", 50.0 + "px");
      angular.element($("#locateInputID")).css("fontSize", 16.0 + "px");
      angular.element($("#locateInputID")).css("paddingRight", 20.0 + "px");
      angular.element($("#locateInputID")).css("width", window.screen.availWidth - 95.0 + "px");
      angular.element($(".bar.item-input-inset .item-input-wrapper input")).css("height", 50.0 + "px");
      angular.element($(".bar.item-input-inset .item-input-wrapper input")).css("fontSize", 17.0 + "px");
      angular.element($(".buttons-right")).css("top", 22.0 + "px");
      angular.element($(".button-clear")).css("maxHeight", 75.0 + "px");
    }

    function clearStyle() {   //...返回销毁样式
      $timeout(function () {
        angular.element($(".bar.bar-dark")).css("height",'');
        angular.element($(".item-input-inset")).css("height",'');
        angular.element($(".has-header")).removeClass('ios-bar-has-header-top');
        angular.element($(".has-header")).removeClass('android-bar-has-header-top');
        angular.element($("#locateInputID")).css("top", '');
        angular.element($("#locateInputID")).css("height",'');
        angular.element($("#locateInputID")).css("fontSize", '');
        angular.element($("#locateInputID")).css("paddingRight", '');
        angular.element($(".bar.item-input-inset .item-input-wrapper input")).css("height", '');
        angular.element($(".buttons-right")).css("top", '');
        angular.element($(".button-clear")).css("maxHeight", '');
        angular.element($(".button-clear")).css("marginTop", "");
        angular.element($("#map_locate_background")).css("marginTop", '');
        angular.element($(".bar.item-input-inset .item-input-wrapper")).css("height", '');
        angular.element($(".bar.item-input-inset .item-input-wrapper")).css("marginTop", '');
        angular.element($(".bar .button.back-button")).css("marginTop",'');
      },150)
    }


    $scope.locationPlaceholder = 'Loading locations...';
    $timeout(function () {
      // angular.element($("#locateInputID")).css("width", window.screen.availWidth - 95.0 + "px");
      if ($ionicPlatform.is('android')) { // 安卓地址输入框样式
        adjustmentNavBar();
        angular.element($("#map_locate_background")).css("height", window.screen.availHeight - 90.0 + "px");
        angular.element($("#map_locate")).css("margin-top", 90.0 - window.screen.availHeight + "px");
        angular.element($("#map_locate")).css("height", window.screen.availHeight - 90.0 + "px");
      } else { // iOS地址输入框样式
        angular.element($(".bar.bar-dark")).css("height",80+'px');
        angular.element($(".item-input-inset")).css("height",80+'px');
        angular.element($(".has-header")).addClass('ios-bar-has-header-top');
        angular.element($("#locateInputID")).css("height", 50.0 + "px");
        angular.element($("#locateInputID")).css("fontSize", 16.0 + "px");
        angular.element($("#locateInputID")).css("paddingRight", 20.0 + "px");
        angular.element($("#locateInputID")).css("width", window.screen.availWidth - 95.0 + "px");
        angular.element($(".bar.item-input-inset .item-input-wrapper")).css("height", 45.0 + "px");
        angular.element($(".bar.item-input-inset .item-input-wrapper")).css("marginTop", 5.0 + "px");
        angular.element($(".bar.item-input-inset .item-input-wrapper input")).css("fontSize", 17.0 + "px");
        angular.element($(".buttons-right")).css("top", 19.0 + "px");
        // angular.element($(".button-clear")).css("marginTop", 5.0 + "px");

        angular.element($("#map_locate_background")).css("height", window.screen.availHeight - 80.0 + "px");
        angular.element($("#map_locate")).css("margin-top", 80.0 - window.screen.availHeight + "px");
        angular.element($("#map_locate")).css("height", window.screen.availHeight - 80.0 + "px");
        if (window.StatusBar) {
          angular.element($("#locateInputID")).css("top", 26.0 + "px");
          angular.element($(".button-clear")).css("marginTop", 10.0 + "px");
          angular.element($(".button-clear")).css("maxHeight", 75.0 + "px");
          angular.element($(".bar .button.back-button")).css("marginTop", 20.0 + "px");
          angular.element($("#map_locate_background")).css("height", window.screen.availHeight - 60.0 + "px");
          angular.element($("#map_locate")).css("margin-top", 60.0 - window.screen.availHeight + "px");
          angular.element($("#map_locate")).css("height", window.screen.availHeight - 60.0 + "px");
        }
      }
    }, 0);



    // LocationService.getCurrentPosition(function (position) {
    //   var latlng = {
    //     lat: position.coords.latitude,
    //     lng: position.coords.longitude
    //   };
    //   $scope.initialize(latlng);
    // }, function (error) {
    //   //洛杉矶
    //   var latlng = {
    //     lat: 34.1017614,
    //     lng: -118.3450541
    //   };
    //   //海景国际
    //   // var latlng = {
    //   //   lat: 34.3185392,
    //   //   lng: 108.93369050000001
    //   // };
    //   $scope.initialize(latlng);
    //   console.log('Locate fault!!!!');
    // });

    //最多只保留5个
    $scope.addLocationHistory = function (location) {
      if (!location) {
        return;
      }
      var locations;
      if (!StorageService.getLocationHistories() || StorageService.getLocationHistories().length == 0) {
        locations = [];
      } else {
        locations = StorageService.getLocationHistories();
      }
      var find = false;
      for (var i = 0; i < locations.length; i++) {
        if (locations[i].place_id == location.place_id) {
          find = true;
          break;
        }
      }
      if (!find) {
        locations.unshift(location);
        if (locations.length > 5) {
          locations.splice(5, 1);
        }
        StorageService.setLocationHistories(locations);
      }
    };

    var afterGetLocation = function () {
      addressObj.isAirport=$.inArray("airport",addressObj.types) != -1;
      $scope.location.address = addressObj.formatted_address;
      locateResult = {
        "lat": selectLocationMap.getCenter().lat(),
        "lng": selectLocationMap.getCenter().lng(),
        "address": addressObj
      };
      $timeout(function () {
        angular.element($("#locateInputID")).val(addressObj.formatted_address);
      },0);

    }

  });
