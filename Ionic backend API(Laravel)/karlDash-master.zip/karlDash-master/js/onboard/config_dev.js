StripeInfo={
    card_url:'https://api.stripe.com/v1/tokens',
    publish_key : 'pk_test_Jhgu0wWQ5IngFw6iffVdmLcE'
};

WebsiteUrl = "http://dev.karl.limo";
DashboardUrl ="http://dev.karldash.com";
