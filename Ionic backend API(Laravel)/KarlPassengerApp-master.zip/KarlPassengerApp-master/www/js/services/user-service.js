(function () {
  "use strict";

  angular.module('passengerApp').service('UserService',
    function (StorageService,$ionicPickerI18n,$translate) {
    var self = this;

    //getLoginUser
    self.getLoginUser = function () {
      if (!this.user) {
        this.user = StorageService.getUserInfo();
        console.log("user is ",JSON.stringify(this.user));
      }
      return this.user;
    };

    //saveLoginUser
    self.saveLoginUser = function (userObject) {
      // todo
      console.log(userObject)
      if(userObject.lang=='en'){
        $ionicPickerI18n.weekdays = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
        $ionicPickerI18n.months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
      }else {
        $ionicPickerI18n.weekdays = ["Di", "Lu", "Ma", "Me", "Je", "Ve", "Sa"];
        $ionicPickerI18n.months = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
      }
      $translate.use(userObject.lang);
      moment.locale(userObject.lang);
      StorageService.setLang(userObject.lang);
      this.user = userObject;
      StorageService.setUserInfo(userObject);
    };

    //clearLoginUser
    self.clearLoginUser = function () {
      StorageService.cleanUserInfo();
      delete this.user;
    };

    // set users avatar on sidemenu & profile
    self.setAvatar = function (avatarURI) {
      var user = self.getLoginUser();
      user.avatar_url = avatarURI;
      self.saveLoginUser(user);
    };

    self.getUserAddress = function () {
      var user = self.getLoginUser();
      return user.address;
    };

    self.getBillingAddress = function () {
      var billAddress = StorageService.getBillingAddress();
      if (!billAddress) {
        var billingAddress = self.getUserAddress();
        if (billingAddress == undefined || billingAddress == '') {
          billAddress = {
            formatted_address: ''
          };
        } else {
          if(billingAddress.indexOf('formatted_address') < 0){
            billAddress = {
              formatted_address: billingAddress
            };
          }else {
            billAddress = JSON.parse(billingAddress);
          }
        }
      }
      return billAddress;
    };
    self.setBillingAddress = function (billingAddress) {
      StorageService.setBillingAddress(billingAddress);
    };
    self.clearBillingAddress = function () {
      StorageService.cleanBillAddress();
    }
  });
})();
