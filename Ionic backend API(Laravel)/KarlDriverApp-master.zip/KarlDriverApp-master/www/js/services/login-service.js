(function () {
  'use strict';

  angular.module('starter')
    .service('LoginService', function ($state, $ionicPopup, $ionicViewSwitcher,UserService,TripService, HttpService,PushService,$filter) {

      //login
      this.login = function (userName, userPassword, successHandler, faultHandler) {
        HttpService.post(Api.login, {
          "username": userName,
          "password": userPassword
        }, function (response) {
          var user = response.result;
          if (user) {
            if (!user.driver || !user.driver.driver_id) {
              if (faultHandler) {
                faultHandler($filter('translate')('login.jsLogin_Fault'));
              }
              return;
            }
            user.loginAccount = userName;
            user.loginPwd = userPassword;
            UserService.saveLoginUser(user);
            PushService.tryUploadPushToken();
            if (successHandler) {
              successHandler();
            }
          } else {
            if (faultHandler) {
              faultHandler($filter('translate')('login.jsLogin_Fault'));
            }
          }
        }, function (errorString) {
          if (faultHandler) {
            if(errorString){
              faultHandler(errorString);
            }else {
              faultHandler('Login Fault');
            }
          }
        });
      };

      //logout
      this.logout = function () {
        HttpService.post(Api.logout,{},function(){
        },function(){});
        UserService.clearLoginUser();
        TripService.cleanTrip();
      };

      //异点登录被踢
      this.logoutWhenAuthExpired = function (errorCode) {
        if(errorCode == 3007){
          UserService.clearLoginUser();
          TripService.cleanTrip();
          // var errorString = ErrorCode.getErrorMessage(3007);
          var errorString = $filter('translate')(3007);
          console.log($filter('translate')(3007))
          $ionicPopup.alert({
            title: errorString,
            okText: $filter('translate')('ionicPopup.jsOK')
          }).then(function (res) {
            $state.go('login');
            $ionicViewSwitcher.nextDirection("back")
          });
          return true;
        }else {
          return false;
        }
      };
    });
})();
