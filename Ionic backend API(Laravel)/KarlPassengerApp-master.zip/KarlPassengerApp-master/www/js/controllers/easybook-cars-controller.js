(function () {
  'use strict';
  angular.module('passengerApp')
    .controller('EasybookCarsCtrl',
      function ($stateParams, $scope, $ionicActionSheet, $timeout, $state,
                $ionicSlideBoxDelegate, $ionicPopup, $ionicLoading, EasybookService, LoginService, UserService,$filter) {
        //限制notes字数为999
        $("#easybook-notes-textarea").on("input propertychange", function () {
          var $this = $(this),
            _val = $this.val();
          if (_val.length > 999) {
            $this.val(_val.substring(0, 999));
          }
        });
        $scope.langStyle=localStorage.getItem('lang')!=='en';
        function totalCostFunction() {
          console.log('offer ',$scope.offer);
          $scope.totalCost = $scope.optionsTotalPrice + $scope.offer.basic_cost;
          if ($scope.d_is_airport === 1) {
            $scope.totalCost += $scope.offer.d_port_price;
          }

          if ($scope.a_is_airport === 1) {
            $scope.totalCost += $scope.offer.a_port_price;
          }

          $scope.actualCost = $scope.totalCost * (1 + $scope.offer.tva / 100);

          if ($scope.showCoupon) {
            if($scope.percentOff != 0)
              $scope.totalCost = ($scope.totalCost - $scope.amountOff) * (1 - $scope.percentOff/100);
            else
              $scope.totalCost = $scope.totalCost - $scope.amountOff;
          }

          if ($scope.totalCost < 0) {
            $scope.totalCost = 0.00;
          }

          $scope.totalCost = $scope.totalCost * (1 + $scope.offer.tva / 100);
          if ($scope.totalCost > 0 && $scope.totalCost < 1) {
            $scope.totalCost = 1.00;
          }
        }


        function getOfferBookingPrice() {
            if ($scope.offer) {
                var testPrice = angular.copy($scope.totalCost);
                if ($scope.d_is_airport === 1) {
                    testPrice = $scope.offer.d_port_price + $scope.totalCost;
                }
                if ($scope.a_is_airport === 1) {
                    testPrice = $scope.offer.a_port_price + $scope.totalCost;
                }
                if ($scope.a_is_airport && $scope.d_is_airport) {
                    testPrice = $scope.offer.a_port_price + $scope.offer.d_port_price + $scope.totalCost;
                }
                var price = testPrice * (1 + $scope.offer.tva / 100);
                if (price > 0 && price < 1) {
                    price = 1;
                }
            }
            if (price - $scope.amountOff - $scope.percentOff / 100 * (price - $scope.amountOff) < 0) {
                $scope.totalCost = 0;
            } else if (price - $scope.amountOff - $scope.percentOff / 100 * (price - $scope.amountOff) > 0 && price - $scope.amountOff - $scope.percentOff / 100 * (price - $scope.amountOff) < 1) {
                $scope.totalCost = 1;
            } else {
                $scope.totalCost = price - $scope.amountOff - $scope.percentOff / 100 * (price - $scope.amountOff);
            }
        };

        $scope.pickerTitle=$filter('translate')('easybook.jsPickerTitle');
        $scope.buttonOk=$filter('translate')('easybook.jsButtonOk');
        $scope.buttonCancel=$filter('translate')('easybook.jsButtonCancel');

        var User = UserService.getLoginUser();
        $scope.d_is_airport = $stateParams.is_airport.d_is_airport;
        $scope.a_is_airport = $stateParams.is_airport.a_is_airport;
        $scope.$on("$ionicView.beforeEnter", function () {
          if ($scope.hasReturnService()) {
            $scope.rsToggle.isOpen = true;
            $scope.rs = {};
            console.log(EasybookService.returnBookingParam);
            console.log(EasybookService.rebookingOffer);
            $scope.rs.appointedTime = EasybookService.returnBookingParam.appointed_time;
            var cache = EasybookService.returnServiceCache.selects;
            $scope.rs.basicCost = Math.round(cache.basicCost * 100) / 100;
            $scope.rs.optionsCost = Math.round(cache.optionsCost * 100) / 100;
            $scope.rs.totalCost = Math.round(cache.totalCost * 100) / 100;
            $scope.rs_amountOff = cache.rs_amountOff;
            $scope.rs_percentOff = cache.rs_percentOff;
            $scope.rs_couponCode = cache.rs_couponCode;
            $scope.rs_offer = EasybookService.rebookingOffer;
          } else {
            appointedTimeWatch = $scope.$watch('rsToggle.returnDate', function (newValue, oldValue, scope) {
              if (!newValue) {
                return;
              }
              if (!canSetRsDate) {
                return;
              }
              canSetRsDate = false;
              $timeout(function () {
                if (Date.parse($scope.rsToggle.returnDate) <= Date.parse(EasybookService.bookingParam.appointed_time)) {
                  $ionicPopup.alert({
                    title: $filter('translate')('easybook_cars.jsAppointed_time_invalid'),
                    okText: $filter('translate')('ionicPopup.jsOK')
                  });
                  return;
                }
                $ionicLoading.show();
                EasybookService.getReturnServiceOffersFromRemote($scope.rsToggle.returnDate,
                  function (response) {
                    $ionicLoading.hide();
                    $state.go('app.easybook-return-cars',
                      {
                        "offers": response.result,
                        "car": $scope.selectedCar,
                        "appointedTime": $scope.rsToggle.returnDate,
                        'passengerNumber': angular.copy($scope.countInput.maxPassengers),
                        'passengers': angular.copy($scope.passengers),
                        'bagNumber': angular.copy($scope.countInput.maxBags),
                        'cache': false,
                        "is_airport": {"is_airport": $stateParams.is_airport}
                      });
                  }, function (errorString, response) {
                    $ionicLoading.hide();
                    if (!LoginService.logoutWhenAuthExpired(response.code)) {
                      if (errorString) {
                        $ionicPopup.alert({
                          title: errorString,
                          okText: $filter('translate')('ionicPopup.jsOK')
                        });
                      } else {
                        $ionicPopup.alert({
                          title: $filter('translate')('easybook_cars.jsRequest_fault'),
                          okText: $filter('translate')('ionicPopup.jsOK')
                        });
                      }
                    }
                  }
                )
              }, 0);
            });
          }
        });

        $scope.$on("$ionicView.leave", function () {
          appointedTimeWatch();
          canSetRsDate = false;
        });

        var originalOffers;
        var allCars;
        var allCategorys;
        var allBrands;
        var appointedTimeWatch;
        var canSetRsDate = false;
        $scope.initialize = function () {
          originalOffers = $stateParams.offers;
          allCars = [];
          allCategorys = [];
          allBrands = [];
          $scope.canReturnService = EasybookService.bookingParam.canReturn;
          $scope.rsToggle = {};
          $scope.rsToggle.isOpen = false;
          var appointedTimestamp = Date.parse(EasybookService.bookingParam.appointed_time) + 3 * 60 * 60 * 1000;
          $scope.rsToggle.returnDate = new Date(appointedTimestamp);
          $scope.optionsTotalPrice = 0;
          $scope.hadSelectedOption = false;
          $scope.notesToggle = {};
          $scope.notesToggle.isOpen = true;
          $scope.notes = {};
          $scope.notes.text = '';
          $scope.initCarsAndCategorysAndBrands(originalOffers);
          $scope.selectedCarCategory = allCategorys[0];
          $scope.selectedCarBrand = allBrands[0];
          $scope.cars = filterCars();
          $scope.hasCars = true;
          $scope.showCoupon = false;
          $scope.amountOff=0;
          $scope.percentOff=0;
          $scope.integrateCarData(0);
          totalCostFunction();
        };

        //集合所有的car到allCars中
        //集合所有的category到allCategorys中
        //集合所有的brand到allBrands中
        $scope.initCarsAndCategorysAndBrands = function (offers) {
          for (var i = 0; i < offers.length; i++) {
            var option = $scope.initOptionData(offers[i].options);
            for (var j = 0; j < offers[i].car_categories.length; j++) {
              var category = {};
              category.car_category_id = offers[i].car_categories[j].category_id;
              category.car_category_name = offers[i].car_categories[j].category;

              var carArray = [];
              
              for (var k = 0; k < offers[i].car_categories[j].cars.length; k++) {
                
                //Added by Pham 3/29/2018
                var eachCar = Object();
                eachCar.car_brand_id = offers[i].car_categories[j].cars[k].car_brand_id;
                eachCar.car_model_id = offers[i].car_categories[j].cars[k].car_model_id;

                var is_car_brandId_exist = carArray.findIndex(x => x.car_brand_id == eachCar.car_brand_id);
                var is_car_modelId_exist = carArray.findIndex(x => x.car_model_id == eachCar.car_model_id);
                
                if(is_car_brandId_exist == -1 || is_car_modelId_exist == -1)
                {

                  carArray.push(eachCar);
                  //集合allCars
                  offers[i].car_categories[j].cars[k].offer_id = offers[i].offer_id;
                  offers[i].car_categories[j].cars[k].company_id = offers[i].company_id;
                  offers[i].car_categories[j].cars[k].combine = offers[i].combine;
                  offers[i].car_categories[j].cars[k].options = jQuery.extend(true, {}, option);
                  offers[i].car_categories[j].cars[k].selectedOptions = [];
                  allCars.push(offers[i].car_categories[j].cars[k]);

                  //集合allBrands
                  var findBrand = false;
                  for (var m = 0; m < allBrands.length; m++) {
                    if (allBrands[m].car_brand_id == offers[i].car_categories[j].cars[k].car_brand_id) {
                      findBrand = true;
                    }
                  }
                  if (findBrand == false) {
                    var brand = {};
                    brand.car_brand_id = offers[i].car_categories[j].cars[k].car_brand_id;
                    brand.car_brand_name = offers[i].car_categories[j].cars[k].brand;
                    allBrands.push(brand);
                  }
                }

              }

              //集合allCategorys
              var findCategory = false;
              for (var k = 0; k < allCategorys.length; k++) {
                if (allCategorys[k].car_category_id == category.car_category_id) {
                  findCategory = true;
                }
              }
              if (findCategory == false) {
                allCategorys.push(category);
              }
            }
          }

          //添加"All categorys"到allCategorys的第一项
          if (allCategorys.length > 1) {
            var allCategory = {"car_category_name": $filter('translate')('easybook_cars.jsAll_categorys'), "car_category_id": -1};
            allCategorys.splice(0, 0, allCategory);
          }

          //添加"All makes"到allBrands的第一项
          if (allBrands.length > 1) {
            var allBrand = {"car_brand_name": $filter('translate')('easybook_cars.jsAll_makes'), "car_brand_id": -1};
            allBrands.splice(0, 0, allBrand);
          }
        };

        $scope.integrateCarData = function (selectedIndex) {
          if (!$scope.selectedCar || $scope.selectedCar.car_id != $scope.cars[selectedIndex].car_id) {
            $scope.countInput = {maxPassengers: 0, maxBags: 0};
            $scope.passengers = [];
          }

          $scope.selectedCar = $scope.cars[selectedIndex];
          for (var i = 0; i < originalOffers.length; i++) {
            if (originalOffers[i].offer_id == $scope.selectedCar.offer_id) {
              $scope.offer = originalOffers[i];
              $scope.company_id = $scope.offer.company_id;
              console.log($scope.offer);
              break;
            }
          }
          if ($scope.offer.options.length > 0) {
            $scope.hasOptions = true;
          } else {
            $scope.hasOptions = false;
          }
          if ($scope.company_id == User.company_id) {
            $scope.showCoupon = true;
          } else {
            $scope.showCoupon = false;
          }
        };

        $scope.initOptionData = function (options) {
          var formatOptions = {number: [], checkBox: [], radioGroup: [], checkBoxGroup: [], numberGroup: []};
          for (var i = 0; i < options.length; i++) {
            var option = options[i];
            if (option.type == "NUMBER") {
              if (option.add_max > 1) {
                option.count = 0;
                formatOptions.number.push(option);
              } else {
                option.selected = false;
                formatOptions.checkBox.push(option);
              }
            } else if (option.type == "CHECKBOX") {
              option.selected = false;
              formatOptions.checkBox.push(option);
            } else if (option.type == "GROUP") {
              if (option.group == undefined) {
                continue;
              }
              if (option.group[0].type == "NUMBER") {
                for (var j = 0; j < option.group.length; j++) {
                  option.group[j].count = 0;
                }
                formatOptions.numberGroup.push(option);
              } else if (option.group[0].type == "RADIO") {
                option.selectedOptionIndex = 0;
                var noNeed = {
                  "option_id": -1,
                  "type": option.group[0].type,
                  "parent_id": option.group[0].parent_id,
                  "price": "0",
                  "name": ""
                };
                option.group.unshift(noNeed);
                formatOptions.radioGroup.push(option);
              } else if (option.group[0].type == "CHECKBOX") {
                for (var j = 0; j < option.group.length; j++) {
                  option.group[j].selected = false;
                }
                formatOptions.checkBoxGroup.push(option);
              }
            }
          }
          return formatOptions;
        };

        function filterCars() {
          var resultCars = [];
          if ($scope.selectedCarCategory.car_category_id == -1) {
            if ($scope.selectedCarBrand.car_brand_id == -1) {
              resultCars = jQuery.extend(true, [], allCars);
            } else {
              for (var i = 0; i < allCars.length; i++) {
                if (allCars[i].car_brand_id == $scope.selectedCarBrand.car_brand_id) {
                  resultCars.push(jQuery.extend(true, {}, allCars[i]));
                }
              }
            }
          } else {
            if ($scope.selectedCarBrand.car_brand_id == -1) {
              for (var i = 0; i < allCars.length; i++) {
                if (allCars[i].car_category_id == $scope.selectedCarCategory.car_category_id) {
                  resultCars.push(jQuery.extend(true, {}, allCars[i]));
                }
              }
            } else {
              for (var i = 0; i < allCars.length; i++) {
                if (allCars[i].car_category_id == $scope.selectedCarCategory.car_category_id && allCars[i].car_brand_id == $scope.selectedCarBrand.car_brand_id) {
                  resultCars.push(jQuery.extend(true, {}, allCars[i]));
                }
              }
            }
          }
          return resultCars;
        }

        //calculate options cost
        $scope.calculateOptionsCost = function () {
          var cost = 0.0;
          var options = $scope.selectedCar.selectedOptions;
          for (var i = 0; i < options.length; i++) {
            cost = cost + options[i].count * options[i].price;
          }
          console.log(cost);
          return cost;
        };

        $scope.showRadioOpetionActionSheet = function (option) {
          var buttions = [];
          for (var i = 0; i < option.group.length; i++) {
            if (option.group[i].option_id == -1) {
              buttions.push({"text": "Not need"});
            } else {
              buttions.push({"text": option.group[i].name});
            }
          }
          $ionicActionSheet.show({
            titleText: $filter('translate')('easybook_cars.jsSelect_option_name', {option_name: option.name}),
            buttons: buttions,
            cancelText: $filter('translate')('easybook_cars.jsCancel'),
            cancel: function () {
            },
            buttonClicked: function (index) {
              option.selectedOptionIndex = index;
              $scope.optionDidChanged(option.group[index]);
              return true;
            },
            destructiveButtonClicked: function () {
              console.log('DESTRUCT');
              return true;
            }
          });
        };

        $scope.numberOptionDidChanged = function (option, isAdd) {
          if (isAdd) {
            if (option.count < option.add_max) {
              option.count++;
            } else {
              //nothing to do..
            }
          } else {
            if (option.count > 0) {
              option.count--;
            } else {
              //nothing to do..
            }
          }
          $scope.optionDidChanged(option);
        };

        $scope.optionDidChanged = function (option) {
          if (option.type == "CHECKBOX") {
            if (option.selected == true) {
              option.count = 1;
              $scope.selectedCar.selectedOptions.push(option);
            } else {
              for (var i = 0; i < $scope.selectedCar.selectedOptions.length; i++) {
                if ($scope.selectedCar.selectedOptions[i].option_id == option.option_id) {
                  $scope.selectedCar.selectedOptions.splice(i, 1);
                  break;
                }
              }
            }
          } else if (option.type == "NUMBER") {
            if (option.add_max > 1) {
              var findIndex = -1;
              for (var i = 0; i < $scope.selectedCar.selectedOptions.length; i++) {
                if ($scope.selectedCar.selectedOptions[i].option_id == option.option_id) {
                  findIndex = i;
                  break;
                }
              }
              if (option.count == 0) {
                if (findIndex >= 0) {
                  $scope.selectedCar.selectedOptions.splice(i, 1);
                } else {
                  //nothing to do...
                }
              } else {
                if (findIndex == -1) {
                  $scope.selectedCar.selectedOptions.push(option);
                } else {
                  //nothing to do...
                }
              }
            } else {
              if (option.selected == true) {
                option.count = 1;
                $scope.selectedCar.selectedOptions.push(option);
              } else {
                for (var i = 0; i < $scope.selectedCar.selectedOptions.length; i++) {
                  if ($scope.selectedCar.selectedOptions[i].option_id == option.option_id) {
                    $scope.selectedCar.selectedOptions.splice(i, 1);
                    break;
                  }
                }
              }
            }
          } else if (option.type == "RADIO") {
            for (var i = 0; i < $scope.selectedCar.selectedOptions.length; i++) {
              if ($scope.selectedCar.selectedOptions[i].type == option.type && $scope.selectedCar.selectedOptions[i].parent_id == option.parent_id) {
                $scope.selectedCar.selectedOptions.splice(i, 1);
                break;
              }
            }
            if (option.option_id > -1) {
              option.count = 1;
              $scope.selectedCar.selectedOptions.push(option);
            } else {
              //nothing to do...
            }
          } else {
            //nothing to do...
          }
          $scope.optionsTotalPrice = $scope.calculateOptionsCost();
          if ($scope.optionsTotalPrice == 0) {
            $scope.hadSelectedOption = false;
          } else {
            $scope.hadSelectedOption = true;
          }
          totalCostFunction();
        };

        $scope.passengerNumberDidChanged = function (isAdd) {
          if (isAdd) {
            if($scope.countInput.maxPassengers==$scope.selectedCar.seats_max){
              $scope.maxPassenAlertContent = $filter('translate')('easybook_cars.jsMax_passengers_alert');
              $ionicPopup.alert ({
                template: '<p>{{maxPassenAlertContent}}</p>',
                cssClass: 'location-permission-popup',
                scope: $scope,
                buttons: [ {
                  text: 'OK',
                  type: 'button-positive',
                  onTap: function(e) {
                    console.log(e);
                  }
                }]
              });
            }
            if ($scope.countInput.maxPassengers < $scope.selectedCar.seats_max) {
              $scope.countInput.maxPassengers++;
              if ($scope.selectedCar.seats_max > 6) {
                if ($scope.countInput.maxPassengers < 7) {
                  $scope.passengers.push({name: ''});
                }
              } else {
                $scope.passengers.push({name: ''});
              }
            }
          } else {
            if ($scope.countInput.maxPassengers > 0) {
              $scope.countInput.maxPassengers--;
              if ($scope.countInput.maxPassengers < 6) {
                $scope.passengers.splice($scope.passengers.length - 1, 1);
              }
            }
          }
        };

        $scope.bagNumberDidChanged = function (isAdd) {
          if (isAdd) {
            if($scope.countInput.maxBags == $scope.selectedCar.bags_max){
              $scope.maxBagAlertContent = $filter('translate')('easybook_cars.jsMax_bags_alert');
              $ionicPopup.alert ({
                template: '<p>{{maxBagAlertContent}}</p>',
                cssClass: 'location-permission-popup',
                scope: $scope,
                buttons: [ {
                  text: 'OK',
                  type: 'button-positive',
                  onTap: function(e) {
                    console.log(e);
                  }
                }]
              });
            }
            if ($scope.countInput.maxBags < $scope.selectedCar.bags_max) {
              $scope.countInput.maxBags++;
            }
          } else {
            if ($scope.countInput.maxBags > 0) {
              $scope.countInput.maxBags--;
            }
          }
        };

        //ionic actionsheet for carCategorys
        $scope.showCarCategorysActionsheet = function () {
          var buttons = [];
          for (var i = 0; i < allCategorys.length; i++) {
            buttons.push({"text": allCategorys[i].car_category_name});
          }
          $ionicActionSheet.show({
            titleText: $filter('translate')('easybook_cars.jsSelect_car_category'),
            buttons: buttons,
            cancelText:  $filter('translate')('easybook_cars.jsCancel'),
            buttonClicked: function (index) {
              if ($scope.selectedCarCategory.car_category_id == allCategorys[index].car_category_id) {
                return true;
              }
              $scope.selectedCarCategory = allCategorys[index];
              $scope.cars = filterCars();

              if ($scope.cars.length > 0) {
                $ionicSlideBoxDelegate.update();
                $ionicSlideBoxDelegate.slide(0);
                $scope.integrateCarData(0);
                $scope.optionsTotalPrice = 0;
                $scope.hadSelectedOption = false;

                totalCostFunction();
                $scope.hasCars = true;
              } else {
                $scope.hasCars = false;
              }
              return true;
            }
          });
        };

        //ionic actionsheet for carMakes
        $scope.showCarBrandsActionsheet = function () {
          var buttons = [];
          for (var i = 0; i < allBrands.length; i++) {
            buttons.push({"text": allBrands[i].car_brand_name});
          }
          $ionicActionSheet.show({
            titleText: $filter('translate')('easybook_cars.jsSelect_car_make'),
            buttons: buttons,
            cancelText:  $filter('translate')('easybook_cars.jsCancel'),
            buttonClicked: function (index) {
              if ($scope.selectedCarBrand.car_brand_id == allBrands[index].car_brand_id) {
                return true;
              }
              $scope.selectedCarBrand = allBrands[index];
              $scope.cars = filterCars();
              if ($scope.cars.length > 0) {
                $ionicSlideBoxDelegate.update();
                $ionicSlideBoxDelegate.slide(0);
                $scope.integrateCarData(0);
                $scope.optionsTotalPrice = 0;
                $scope.hadSelectedOption = false;


                totalCostFunction();
                $scope.hasCars = true;
              } else {
                $scope.hasCars = false;
              }
              return true;
            }
          });
        };

        $scope.slideHasChanged = function (index) {
          $scope.integrateCarData(index);
          $scope.notes.text = '';
          $scope.optionsTotalPrice = $scope.calculateOptionsCost();
          if ($scope.optionsTotalPrice == 0) {
            $scope.hadSelectedOption = false;
          } else {
            $scope.hadSelectedOption = true;
          }

          totalCostFunction();
        };

        $scope.rsToggleDidChanged = function () {
          $timeout(function () {
            if (!$scope.needDatePicker()) {
              if ($scope.rsToggle.isOpen) {
                if (EasybookService.returnBookingParam) {
                  EasybookService.returnBookingParam.enable = true;
                }
              } else {
                if (EasybookService.returnBookingParam) {
                  EasybookService.returnBookingParam.enable = false;
                }
              }
            } else {
              $scope.rsToggle.isOpen = false;
              canSetRsDate = true;
            }
          }, 0);
        };

        $scope.editReturnService = function () {
          $state.go('app.easybook-return-cars',
            {
              "offers": EasybookService.returnServiceCache.offers,
              "car": $scope.selectedCar,
              "appointedTime": $scope.rs.appointedTime,
              'passengerNumber': angular.copy($scope.countInput.maxPassengers),
              'passengers': angular.copy($scope.passengers),
              'bagNumber': angular.copy($scope.countInput.maxBags),
              'cache': true,
              "is_airport": {"is_airport": $stateParams.is_airport}
            });
        };

        $scope.hasReturnService = function () {
          if (EasybookService.returnBookingParam && EasybookService.returnBookingParam.enable) {
            return true;
          } else {
            return false;
          }
        };

        $scope.needDatePicker = function () {
          if (EasybookService.returnBookingParam && EasybookService.returnBookingParam.appointed_time) {
            return false;
          } else {
            return true;
          }
        };

        $scope.notesToggleDidChanged = function () {
          if (!$scope.notesToggle.isOpen) {
            $scope.notes.text = '';
          }
        };

        $scope.form_selectCar_submit = function () {
          EasybookService.saveBookingCar($scope.selectedCar, false);
          //含税
          EasybookService.saveBookingCost($scope.actualCost, false);
          EasybookService.saveShowPrice($scope.totalCost, false);
          EasybookService.saveBookingNote($scope.notes.text, false);
          EasybookService.saveBookingPassengerCount($scope.countInput.maxPassengers, false);
          EasybookService.saveBookingPassengers($scope.passengers, false);
          EasybookService.saveBookingBagCount($scope.countInput.maxBags, false);
          EasybookService.saveBookingCouponCount($scope.coupon.couponCode, false);
          EasybookService.saveBookingCouponAmount($scope.amountOff, false);
          EasybookService.saveBookingCouponPercent($scope.percentOff, false);
          EasybookService.saveBookingOffer($scope.offer, false);

          var options = [];
          for (var i = 0; i < $scope.selectedCar.selectedOptions.length; i++) {
            var option = {};
            option.option_id = $scope.selectedCar.selectedOptions[i].option_id;
            option.name = $scope.selectedCar.selectedOptions[i].name;
            option.count = $scope.selectedCar.selectedOptions[i].count;
            options.push(option);
          }
          EasybookService.saveBookingOptions(options, false);
          $state.go('app.easybook-payment');
        };

        $scope.initialize();

        $scope.promo_code_shown = false;
        $scope.showPromoCodeLine = function () {
          $scope.promo_code_shown = true;
          $scope.checkingCode = false;
        };

        $scope.dismissPromoCodeLine = function () {
          if ($scope.checkingCode) {
            return;
          }
          $scope.promo_code_shown = false;
          $scope.checkingCode = true;
        };
        $scope.coupon = {};
        $scope.amountOff = 0;
        $scope.percentOff = 0;

        $scope.getCouponCode = function ($event) {
          if ($scope.company_id != User.company_id) {
            $scope.checkingCode = false;
            $ionicPopup.alert({
              title: $filter('translate')('easybook_cars.jsPromotion_code_error'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
            return;
          }
          if ($scope.checkingCode) {
            return;
          }
          $scope.checkingCode = true;

          if ($scope.coupon.couponCode == null || $scope.coupon.couponCode == undefined || $scope.coupon.couponCode.trim(' ') == '') {
            $scope.checkingCode = false;
            $ionicPopup.alert({
              title: $filter('translate')('easybook_cars.jsPromotion_code_not_allow_null'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
            return;
          }

          EasybookService.verifyCoupon($scope.coupon.couponCode, $scope.offer.company_id, $scope.loginUser.customer.customer_id, function (result) {
            /*if (!result.result.valid) {
              $ionicPopup.alert({
                title: $filter('translate')('easybook_cars.jsPromotion_code_used'),
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            } else {*/
              if (result.result[0].discount_type == 1) {
                $scope.percentOff = result.result[0].discount_amount;
                $scope.amountOff = 0;
              } else {
                
                $scope.percentOff = 0;
                $scope.amountOff = result.result[0].discount_amount;
              }
              //$scope.amountOff = result.result[0].discount_amount;
              $scope.haveVerifyCode = true;
            //}
            $scope.checkingCode = false;
            getOfferBookingPrice();
          }, function (error) {
            console.log(error);
            $scope.coupon.couponCode = '';
            $scope.checkingCode = false;
            $ionicPopup.alert({
              title: $filter('translate')('easybook_cars.jsCoupon_code_not_valid'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
          });
        };
      }
    );
})();
