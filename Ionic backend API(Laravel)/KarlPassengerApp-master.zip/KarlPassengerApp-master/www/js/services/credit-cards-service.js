(function () {
  'use strict';

  angular.module('passengerApp')
    .service('CreditCardsService', function ($state, $ionicPopup, HttpService) {
      this.getMyCards = function (successHandler, faultHandler) {
        HttpService.get(Api.getCreditCards, {}, successHandler, faultHandler);
      };

      this.deleteCard = function (cardToken, successHandler, faultHandler) {
        HttpService.delete(Api.getCreditCards + "/" + cardToken, {}, successHandler, faultHandler);
      }
    });
})();
