(function () {
  'use strict';

  angular.module('passengerApp')
    .service('LocationService', function ($cordovaGeolocation,StorageService) {

      //initiating Service inside here its self
      var self = this;

      this.position = {coords: {latitude: null, longitude: null}};

      this.watchId = null;

      self.getCurrentPosition = function (successHandle, faultHandle) {
        var options = {timeout: 5000, enableHighAccuracy: true};
        $cordovaGeolocation.getCurrentPosition(options).then(function (position) {
          successHandle(position);
          self.position = position;
          var currentPosition = {
            coords: {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude
            }
          };
          StorageService.setPosition(currentPosition);
        }, function (error) {
          if (self.position.coords.latitude && self.position.coords.longitude) {
            successHandle(self.position);
          } else {
            faultHandle(error);
          }
        });
      };

      self.watchPosition = function () {
        self.clearWatch();
        var options = {timeout: 10000, maximumAge: 1000 * 60 * 2, enableHighAccuracy: false};
        self.watch = $cordovaGeolocation.watchPosition(options).then(null, function (error) {
          console.log(error);
          console.log("LocationService的watchPosition失败,错误:" + JSON.stringify(error));
        }, function (position) {
          self.position = position;
          var currentPosition = {
            coords: {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude
            }
          };
          localStorage.setItem('currentPosition',currentPosition);
          console.log('LocationService的watchPosition成功,结果  ' + 'lat:' + position.coords.latitude + '   ' + 'lng:' + position.coords.longitude);
        });
      };

      self.clearWatch = function () {
        if (self.watch) {
          $cordovaGeolocation.clearWatch(self.watch);
        }
      };
    });

})();
