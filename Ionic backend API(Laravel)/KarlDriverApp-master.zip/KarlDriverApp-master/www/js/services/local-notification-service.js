/**
 * Created by liqihai on 2016/10/11.
 */
(function () {
  'use strict';
  angular.module('starter')
    .service('LocalNotificationService', function ($cordovaLocalNotification) {
      var notificationIds = [];
      this.sendNotification = function (id, title, noticeText) {
        if (window.cordova) {
          if (notificationIds.indexOf(id) >= 0) {
            return;
          }
          notificationIds.push(id);
          $cordovaLocalNotification.schedule({
            id: id,
            title: title,
            text: noticeText,
            at: new Date(new Date().getTime() + 5 * 1000)
          })
        }
      };
      this.cancelNotification = function (id) {
        if (window.cordova) {
          var position = notificationIds.indexOf(id);
          if (position < 0) {
            return;
          }
          $cordovaLocalNotification.cancel(id, function () {
            notificationIds.splice(position, 1);
          });
        }
      };

      /**
       * callback 有入参
       * LocalNotificationService.checkNotificationPermission(function(granted){
             *      showToast(granted?'yes':'no');
             * });
       * @param callback
       */
      this.checkNotificationPermission = function (callback) {
        if (window.cordova) {
          $cordovaLocalNotification.hasPermission(callback);
        }
      };
      /**
       * callback 有入参
       * LocalNotificationService.registerPermission(function(granted){
             *      showToast(granted?'yes':'no');
             * });
       * @param callback
       */
      this.registerPermission = function (callback) {
        if (window.cordova) {
          $cordovaLocalNotification.registerPermission(callback);
        }
      }

    });
})();
