ApiServer = {
  serverUrl: "http://test.api.karldash.com",
  version: "/1",
  companyId: "365",
  companyName:"Colorado Prestige"
};
