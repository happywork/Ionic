(function() {
  'use strict';

  angular.module('starter')
    .service('LocationService', function($cordovaGeolocation,$localStorage) {

      //initiating Service inside here its self
      var self = this;

      this.position = {coords:{latitude:null,longitude:null}};

      this.watchId = null;

      self.getCurrentPosition = function(successHandle,faultHandle){
        var options = {timeout: 10000, enableHighAccuracy: true};
        $cordovaGeolocation.getCurrentPosition(options).then(function (position) {
          $localStorage.havePosition=1;
          successHandle(position);
          self.position = position;
          $localStorage.currentPosition = {coords:{latitude:position.coords.latitude,longitude:position.coords.longitude}};
        },function (error) {
          $localStorage.havePosition=2;
          if(self.position.coords.latitude && self.position.coords.longitude){
            successHandle(self.position);
          }else {
            faultHandle(error);
          }
        });
      };

      self.watchPosition = function(){
        self.clearWatch();
        var options = {timeout: 10000,maximumAge:1000*60*2, enableHighAccuracy: false};
        self.watch = $cordovaGeolocation.watchPosition(options).then(null,function (error) {
          console.log("LocationService的watchPosition失败,错误:"+error);
        },function (position) {
          self.position = position;
          $localStorage.currentPosition = {coords:{latitude:position.coords.latitude,longitude:position.coords.longitude}};
          console.log('LocationService的watchPosition成功,结果  '+'lat:' + position.coords.latitude+'   '+'lng:'+position.coords.longitude);
        });
      };

      self.clearWatch = function () {
        if(self.watch){
          $cordovaGeolocation.clearWatch(self.watch);
        }
      };
    });

})();
