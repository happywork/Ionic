/**
 * Created by wangyuanzhi on 16/3/23.
 */
(function () {
  'use strict';
  angular.module('passengerApp')
    .service('PushService', function (HttpService, StorageService ,$ionicPopup) {
      var self = this;


    });
})();
