/**
 * Created by wangyaunzhi on 16/11/22.
 */
angular.module('passengerApp.filters',[])
  .filter('TimeFormatFilter', function ($filter)
  {
    //入参time单位为分钟
    return function (time)
    {
      if(!time){
        return ""
      }else {
        time = Math.round(time);
        if(time <= 1){
          return 1 + $filter('translate')('time_format.jsMin');
        }else if(time > 1 && time <= 60){
          return time + $filter('translate')('time_format.jsMins');
        }else {
          if(time % 60 == 0){
            return parseInt(time / 60) + ":00" + $filter('translate')('time_format.jsHrs');
          }else if(time % 60 > 0 && time % 60 < 10){
            return parseInt(time / 60) + ":0" + time % 60 + $filter('translate')('time_format.jsHrs');
          } else {
            return parseInt(time / 60) + ":" + time % 60 + $filter('translate')('time_format.jsHrs');
          }
        }
      }
    }
  });
