<?php
/**
 * Created by PhpStorm.
 * User: lqh
 * Date: 2017/7/6
 * Time: 上午9:59
 */

return [
    "driverEvents"=>"Car service for :clientName  which takes :time",
    "carEvent"=>":driverName : Car service for :clientName which takes :time",
];