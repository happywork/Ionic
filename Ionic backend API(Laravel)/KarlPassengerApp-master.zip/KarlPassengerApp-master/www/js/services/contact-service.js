(function () {
  'use strict';

  angular.module('passengerApp')
    .service('ContactService', function ($state, $ionicPlatform, $cordovaSms, HttpService) {
      var self = this;
      this.getCompanyDetail = function(successHandler, faultHandler){
        HttpService.get(Api.getCompanyDetail, {}, function (response) {
          if (successHandler) {
            successHandler(response);
          }
        }, faultHandler);
      };

      this.getCompanyInfo = function(successHandler, faultHandler){
        HttpService.get(Api.getCompanyInfor, {}, function (response) {
          if (successHandler) {
            successHandler(response);
          }
        }, faultHandler);
      };

      this.sendText = function (number, message) {
        if(window.cordova){
          var options = {
            replaceLineBreaks: false,
            android: {
              intent: 'INTENT'
            }
          };

          $cordovaSms.send(number, message, options)
            .then(function () {
              console.log('sms send success');
            }, function (error) {
              console.log(error);
            });
        }
      }
    });
})();
