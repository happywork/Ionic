/**
 * Created by liqihai on 16/8/15.
 */
angular.module('OnBoard.Controllers', []);