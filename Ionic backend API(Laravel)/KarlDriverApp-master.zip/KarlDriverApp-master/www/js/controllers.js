//test comment

(function () {
  "use strict";

  angular.module('starter.controllers', [])

    .controller('AppCtrl', function ($scope, $ionicSideMenuDelegate) {
      // With the new view caching in Ionic, Controllers are only called
      // when they are recreated or on app start, instead of every page change.
      // To listen for when this page is active (for example, to refresh data),
      // listen for the $ionicView.enter event:
    })

    //sideMenuCtl holds logic for Side Menu links and functions..
    .controller('sideMenuCtl', function ($scope, $state, $timeout, UserService, LoginService, BookingsService, TripService, $ionicPopup, $rootScope,$filter,$localStorage) {
      $scope.state = $state;
      $scope.loginUser = UserService.getLoginUser();
      console.log($scope.loginUser);
      $scope.logout = function () {
        if (TripService.isTripping) {
          $ionicPopup.alert({
            title:  $filter('translate')('menu.jsHave_current_trip')
          });
        } else {
          $ionicPopup.confirm({
            title: $filter('translate')('menu.jsExit'),
            template: $filter('translate')('menu.jsSure_log_out'),
            okText: $filter('translate')('ionicPopup.jsOK'),
            cancelText:$filter('translate')('ionicPopup.jsCancel')
          }).then(function (res) {
            if (res) {
              if($localStorage.havePosition==2 && $localStorage.canNetWork==1){
                $localStorage.canPosition=2
              }else {
                $localStorage.canPosition=1
              }
              LoginService.logout();
              $state.go("login");
            } else {
              //nothing to do...
            }
          });
        }
      };

      $scope.$on('ProfileChanged', function () {
        $timeout(function () {
          $scope.loginUser = UserService.getLoginUser();
          $scope.$apply();
        }, 0);
      });

      $scope.enterProfile = function () {
        $scope.$broadcast('SideMenuProfileDidClick');
      };

// reset `isFormDirty` when state changes
      $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        $rootScope.isFormDirty = false;
        if (window.cordova) {
          window.mixpanel.track('KARL Driver Entry Page', {"pageName": toState.url}, function () {
            console.log('mixpanel track success');
          }, function () {
            console.log('mixpanel track fail');
          });
          if ($scope.loginUser.driver.driver_id) {
            var id = '' + $scope.loginUser.driver.driver_id;
            window.mixpanel.identify(id, function () {
              console.log('mixpanel identify success' + ' ' + id);
            }, function () {
              console.log('mixpanel identify fail' + ' ' + id);
            });
            window.mixpanel.people.set({
              'first_name': $scope.loginUser.first_name,
              'last_name': $scope.loginUser.last_name,
              'email': $scope.loginUser.email,
              'gender': ($scope.loginUser.gender == 2) ? 'female' : 'male',
              $email: $scope.loginUser.email
            }, function () {
              console.log('mixpanel people set Success');
            }, function () {
              console.log('mixpanel people set Fail');
            });
          }
        }
      });
///////////////////////////////////////////////////////////////////////
// IF Driver exits profile without saving changes.
      $scope.sidemenuIsOpen = false;
      $scope.toggleLeftSideMenu = function () {//ng-click from menu.html
        // console.log($scope.toggleLeftSideMenu);
        $scope.sidemenuIsOpen = !$scope.sidemenuIsOpen;

        if ($scope.sidemenuIsOpen && $rootScope.isFormDirty) {
          var confirmPopup = $ionicPopup.confirm({
            title: $filter('translate')('menu.jsChanges_not_saved'),
            template: $filter('translate')('menu.jsSave_changes'),
            okText: $filter('translate')('ionicPopup.jsOK'),
            cancelText:$filter('translate')('ionicPopup.jsCancel')
          });

          confirmPopup.then(function (res) {
            if (res) {
              console.log('Run updateDriverProfile()');
            } else {
              $rootScope.isFormDirty = false;
              console.log('Allow user to continue w/o changes');
            }
          });
        }
      };

///////////////////////////////////////////////////////
//IF DRIVER Navigates to Curren Trip BEFORE starting a trip:
      $scope.checkCurrentTrip = function () {
        if (!BookingsService.currentBooking) {
          var currentTripPopup = $ionicPopup.confirm({
            title: $filter('translate')('menu.jsStart_a_trip'),
            template: $filter('translate')('menu.jsStart_trip_first'),
            okText: $filter('translate')('ionicPopup.jsOK'),
            cancelText:$filter('translate')('ionicPopup.jsCancel')
          });
          currentTripPopup.then(function (res) {
            if (res) return;
          });
        } else
          $state.go('app.current-trip');
      }
    })

})();
//test comment
