<?php
/**
 * Created by PhpStorm.
 * User: lqh
 * Date: 2017/7/6
 * Time: 上午9:32
 */

return [
    "title"=>"Invoice",
    "downloadAndPrint"=>"Download To Print",
    "dearClient"=>"Dear Client",
    "bookingDetail"=>"Below are your booking details.",
    "contactInfo"=>"If you have any questions please contact us at",
    "yourTrip"=>"Your Trip",
    "client"=>"Client",
    "rate"=>"Rate",
    "driver"=>"Driver",
    "distance"=>"Distance",
    "totalTime"=>"Total Time",
    "totalCost"=>"Total Cost",
    "fareBreakdown"=>"Fare Breakdown",
    "baseFare"=>" Base Fare",
    "addOns"=>" Add-Ons",
    "additionalMileage"=>"Additional Mileage",
    "itemDescription"=>"Item Description",
    "subtotal"=>"Subtotal",
    "amountOff"=>"Amount Off",
    "tax"=>"Tax",
    "total"=>"Total",
    "appDownload"=>"Have you downloaded the passenger App",
];