ApiServer = {
  serverUrl: "http://dev.api.karldash.com",
  version: "/1"
};

