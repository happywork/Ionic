// IIFE START //
(function () {
  'use strict';
  angular.module('starter')
    .service("BookingsService", function ($filter, HttpService) {

      var self = this;

      self.loadBookingEvents = function (requestParame, successHandle, faultHandle) {
        HttpService.get(Api.bookEventRides, requestParame, successHandle, faultHandle);
      };

      self.loadBookings = function (params, successHandle, faultHandle) {
        HttpService.get(Api.bookRides, params, function (response) {
          if (response.code != 2100) {
            angular.forEach(response.result.bookings, function (booking) {
              if (booking.d_address) {
                if(booking.d_address.indexOf('formatted_address') > 0){
                  booking.d_address = JSON.parse(booking.d_address);
                }
              }
              if (booking.a_address) {
                if(booking.a_address.indexOf('formatted_address') > 0){
                  booking.a_address = JSON.parse(booking.a_address);
                }
              }
            });
          }
          successHandle(response);
        }, faultHandle);
      };
    });
})();
