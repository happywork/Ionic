/**
 * Created by wangyaunzhi on 16/12/1.
 */
'use strict';

angular.module('Common.Filters', []);