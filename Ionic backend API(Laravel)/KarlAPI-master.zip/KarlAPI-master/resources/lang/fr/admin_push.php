<?php
/**
 * Created by PhpStorm.
 * User: lqh
 * Date: 2017/7/6
 * Time: 上午9:59
 */

return [
    "driverStartTrip" => "Un de vos chauffeurs a commencé une course. Accédez à votre page d'accueil pour suivre localiser vos chauffeurs.",
    "driverStartTripTitle" => "Une course a commencé.",

    "comNewBookingTitle" => "Vous avez une nouvelle réservation",
    "comNewBooking" => "Vous avez reçu une nouvelle réservation. Accédez au calendrier de votre Dashboard pour voir les détails.",

    "anNoticeTitle" => "Alerte !",
    "anNotice" => "Alerte ! Un Membre KARL vous a rejeté une réservation. Accédez au calendrier du Dashboard pour résoudre le problème.",

    "groupSycTitle" => "La synchronisation MailChimp est terminée.",
    "groupSyc" => "Clients synchronisés avec MailChimp.",

    "groupSycFieldTitle" => "Erreur de synchronisation MailChimp",
    "groupSycField" => "Vérifiez vos paramètres MailChimp"
];