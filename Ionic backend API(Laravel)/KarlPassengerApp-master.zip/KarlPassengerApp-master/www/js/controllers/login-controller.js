// IIFE START //

(function () {
  'use strict';
  angular.module('passengerApp')
    .controller('LoginCtrl',
      function ($scope, $ionicModal, $ionicSideMenuDelegate, $state, $ionicPopup,
                $ionicPlatform,$ionicLoading, LoginService, UserService, RegionService,
                ForgetPwdService, ConciergeService,$filter,$timeout) {
        function resizeLogoFix() {
          var screenHeight = window.screen.availHeight;
          if ($ionicPlatform.is('android')) {
            if (window.AndroidFullScreen) {
              AndroidFullScreen.isImmersiveModeSupported(function () {
                AndroidFullScreen.getAppScreenHeight(function (value) {
                  screenHeight = value;
                }, function (error) {
                });
              }, function (error) {
              });
            }
          }
          angular.element($("#company-logo")).css("width", screenHeight*0.4 + "px");
          angular.element($("#company-logo")).css("height", screenHeight*0.2 + "px");
          angular.element($("#company-logo")).css("margin-top", screenHeight*0.15 + "px");
        }


        window.ionic.Platform.ready(function () {
          if (window.cordova && window.cordova.plugins.Keyboard) {
            window.cordova.plugins.Keyboard.hideKeyboardAccessoryBar(false);
            if (window.ionic.Platform.isIOS()) {
              window.cordova.plugins.Keyboard.disableScroll(true);
            }
          }
        });

        resizeLogoFix();
        RegionService.initialize();
        $ionicSideMenuDelegate.canDragContent(false);
        $scope.loginForm = {};
        $scope.showPas=false;
        var countryInfo = localStorage.getItem("companyInfo");
        console.log("country info ",countryInfo);

        function autoLogin() {
          var user = UserService.getLoginUser();
          if (user && user.loginAccount && user.loginPwd) {
            $scope.loginForm.Username = user.loginAccount;
            $scope.loginForm.Password = user.loginPwd;
            $ionicLoading.show({
              template:  $filter('translate')('login.jsSigning_in')
            });
            LoginService.login(user.loginAccount, user.loginPwd, function () {
              $ionicLoading.hide();
              if (ConciergeService.needConcierge()) {
                $state.go("section");
              }else {
                $state.go("app.easybook");
              }
            }, function (errorString) {
              $ionicLoading.hide();
            });
          }
        }

        //
        $scope.startLogin = function () {
          var userName = $scope.loginForm.Username;
          var userPassword = $scope.loginForm.Password;
          if (!userName || !userPassword) {
            $ionicPopup.alert({
              title: $filter('translate')('login.jsMissing_fields'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
            return;
          }
          $ionicLoading.show({
            template: $filter('translate')('login.jsSigning_in')
          });
          LoginService.login(userName, userPassword, function () {
            $ionicLoading.hide();
            if (ConciergeService.needConcierge()) {
              $state.go("section");
            }else {
              $state.go("app.easybook");
            }
          }, function (errorString) {
            $ionicLoading.hide();
            $ionicPopup.alert({
              title: errorString,
              okText: $filter('translate')('ionicPopup.jsOK')
            });
          });
        };

        $scope.closeForgetPwdShow = function () {
          $scope.popup.close();
        };
        $scope.showForgetPwdDialog = function () {
          $scope.popup = $ionicPopup.show({
            cssClass: 'my-custom-popup',
            templateUrl: "templates/forget-password.html",
            scope: $scope
          });
        };

        $scope.param = {};
        $scope.commitEmail = function () {
          ForgetPwdService.resetPassword($scope.param.email,
            function () {
              $scope.popup.close();
              $scope.param.email = null;
            }, function (errorString, response) {
              if (!LoginService.logoutWhenAuthExpired(response.code)) {
                if (errorString) {
                  $ionicPopup.alert({
                    title: errorString,
                    okText: $filter('translate')('ionicPopup.jsOK')
                  })
                } else {
                  $ionicPopup.alert({
                    title: $filter('translate')('login.jsEmail_not_found'),
                    okText: $filter('translate')('ionicPopup.jsOK')
                  })
                }
              }
            });
        };


        $scope.showPasClick=function () {
          $scope.showPas=!$scope.showPas;
          $timeout(function () {
            var pass;
            pass = angular.element($('#pas'));
            if($scope.showPas){
              pass[0].type = 'text';
            }else {
              pass[0].type = 'password';
            }
            console.log(pass)
          })
        };
        setTimeout(function () {
          autoLogin();
        },1000);

      });
})();
