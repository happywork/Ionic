<?php 
namespace App\Model;
/**
 * Created by PhpStorm.
 * User: lqh
 * Date: 2018/03/26
 * Time: 19:37
 */
use Illuminate\Database\Eloquent\Model;

class Onetime_couponHistory extends Model{

		protected $table = 'onetime_coupon_histories';

        protected $fillable = [
        
        ];
        
        protected $hidden=[
        
        ];

}
?>       