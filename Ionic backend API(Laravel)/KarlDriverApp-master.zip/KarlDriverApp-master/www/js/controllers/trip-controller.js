(function () {
  'use strict';
  angular.module('starter')
    .controller('TripCtrl',
      function ($scope, $ionicSideMenuDelegate, $filter, $ionicPlatform, $stateParams,
                TripService, $ionicLoading, $cordovaSms,
                BookingsService, MapService, UserService, HttpService, $timeout,
                $ionicPopup, LocationService, LocalNotificationService, LoginService,$localStorage) {
        TripService.bindController($scope);
        $scope.stateString=$filter('translate')('current_trip.jsNo_trip');
        $scope.buttonState=$filter('translate')('current_trip.jsEnd_trip');
        $scope.$on('$ionicView.beforeEnter', function () {
          $ionicSideMenuDelegate.canDragContent(true);

          // 如地图权限没有加载出弹框一次
          $scope.positionAlertContent = $filter('translate')('positionAlert.jsContent');
          if($localStorage.canPosition==2&&$localStorage.canNetWork==1){
            $localStorage.canPosition=1;
            $ionicPopup.show ({
              title: $filter('translate')('positionAlert.jsTitle'),
              template: '<div class="line"></div><p>{{positionAlertContent}}</p>',
              cssClass: 'location-permission-popup',
              scope: $scope,
              buttons: [ {
                text: 'OK',
                type: 'button-positive',
                onTap: function(e) {
                  console.log(e);
                }
              }]
            });
          }

          if (!map) {
            loadMap();
          }
          if ($stateParams.booking.id) {
            TripService.initTrip($stateParams.booking);
            $scope.bookingTrip = angular.copy(TripService.currentTrip);
            if ($scope.bookingTrip.d_address.address_components) {
              $scope.isLangAddress = false;
            } else {
              $scope.isLangAddress = true;
            }
            $scope.finalAddressUp = $scope.bookingTrip.d_address.final_address;
            if($scope.bookingTrip.type == 1){
              $scope.finalAddressOff = $scope.bookingTrip.a_address.final_address;
            }
            if (savePoints.length > 0) {
              var point = savePoints[savePoints.length - 1];
              initTripStateWithLatlng({lat: point.lat, lng: point.lng});
            } else {
              LocationService.getCurrentPosition(function (position) {
                initTripStateWithLatlng({
                  lat: position.coords.latitude,
                  lng: position.coords.longitude
                });
              }, function (error) {
                console.log("获取定位失败,错误:" + JSON.stringify(error));
              });
            }
            getTripState();
            getTripAddress();
          } else {
            console.log(TripService.currentTrip)
            if (!TripService.currentTrip || TripService.currentTrip.tripState == 0) {
              loadTodayBookings();
            } else {
              $scope.bookingTrip = angular.copy(TripService.currentTrip);
              console.log($scope.bookingTrip);
              if ($scope.bookingTrip.d_address.address_components) {
                $scope.isLangAddress = false;
              } else {
                $scope.isLangAddress = true;
              }
              $scope.finalAddressUp = finalAddress($scope.bookingTrip.d_address);
              if($scope.bookingTrip.type == 1){
                $scope.finalAddressOff = finalAddress($scope.bookingTrip.a_address);
              }
              if (savePoints.length > 0) {
                var point = savePoints[savePoints.length - 1];
                initTripStateWithLatlng({lat: point.lat, lng: point.lng});
              } else {
                LocationService.getCurrentPosition(function (position) {
                  initTripStateWithLatlng({
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                  });
                }, function (error) {
                  console.log("获取定位失败,错误:" + error);
                });
              }
              getTripState();
              getTripAddress();
            }
          }
        });

        function loadTodayBookings() {
          $ionicLoading.show({
            template: $filter('translate')('current_trip.jsLoading')
          });

          //先请求trip_state为1、2、3、4,时间为负无穷大到正无穷大,判断是否有正在执行的订单
          //如果有,则继续执行
          //否则,再请求trip_state为0,时间为1小时前到1年后,取第1个订单
          BookingsService.loadBookings({"start_time": 0, "trip_state": '1,2,3,4'}, function (response) {
            console.log(response)
            if (response.code == 2100) {
              //请求trip_state为0的订单
              var now = new Date();
              BookingsService.loadBookings({
                "start_time": parseInt(now.getTime() / 1000) - 60 * 60,
                "trip_state": '0'
              }, function (res) {
                console.log(res)
                if (res.code == 2100) {
                  $ionicLoading.hide();
                  $scope.currentTrip.stateString = $filter('translate')('current_trip.jsNo_trip');
                  $scope.currentTrip.buttonState = "";
                  $scope.currentTrip.duration = "";
                  $scope.finalAddress = ['',''];
                  $scope.bookingTrip = undefined;
                } else {
                  //直接执行第1个
                  var bookings = res.result.bookings;
                  bookings[0].option_data = JSON.parse(bookings[0].option_data);
                  bookings[0].car_data = JSON.parse(bookings[0].car_data);
                  TripService.initTrip(bookings[0]);
                  $scope.bookingTrip = angular.copy(TripService.currentTrip);
                  if ($scope.bookingTrip.d_address.address_components) {
                    $scope.isLangAddress = false;
                  } else {
                    $scope.isLangAddress = true;
                  }
                  $scope.finalAddressUp = finalAddress($scope.bookingTrip.d_address);
                  if($scope.bookingTrip.type == 1){
                    $scope.finalAddressOff = finalAddress($scope.bookingTrip.a_address);
                  }
                  LocationService.getCurrentPosition(function (position) {
                    $ionicLoading.hide();
                    initTripStateWithLatlng({
                      lat: position.coords.latitude,
                      lng: position.coords.longitude
                    });
                    getTripState();
                    getTripAddress();
                  }, function (error) {
                    $ionicLoading.hide();
                    $ionicPopup.alert({
                      title: $filter('translate')('current_trip.jsNo_upcoming_trips'),
                      okText: $filter('translate')('ionicPopup.jsOK')
                    });
                    console.log("获取定位失败,错误:" + error);
                    $scope.currentTrip.stateString =  $filter('translate')('current_trip.jsNo_trip');
                    $scope.currentTrip.buttonState = "";
                    $scope.currentTrip.duration = "";
                    $scope.finalAddress = ['',''];
                    $scope.bookingTrip = undefined;
                  });
                }
              }, function (errorString, response) {
                $ionicLoading.hide();
                if (!LoginService.logoutWhenAuthExpired(response.code)) {
                  if (errorString) {
                    $ionicPopup.alert({
                      title: errorString,
                      okText: $filter('translate')('ionicPopup.jsOK')
                    });
                  } else {
                    $ionicPopup.alert({
                      title:  $filter('translate')('current_trip.jsNo_upcoming_trips'),
                      okText: $filter('translate')('ionicPopup.jsOK')
                    });
                  }
                }
              });
            } else {
              //直接执行第1个
              var trips = response.result.bookings;
              trips[0].option_data = JSON.parse(trips[0].option_data);
              trips[0].car_data = JSON.parse(trips[0].car_data);
              TripService.initTrip(trips[0]);
              console.log(TripService.currentTrip)
              $scope.bookingTrip = angular.copy(TripService.currentTrip);
              $scope.finalAddressUp = finalAddress($scope.bookingTrip.d_address);
              if($scope.bookingTrip.type == 1){
                $scope.finalAddressOff = finalAddress($scope.bookingTrip.a_address);
              }
              LocationService.getCurrentPosition(function (position) {
                $ionicLoading.hide();
                initTripStateWithLatlng({lat: position.coords.latitude, lng: position.coords.longitude});
                getTripState();
                getTripAddress();
              }, function (error) {
                $ionicLoading.hide();
                $ionicPopup.alert({
                  title: $filter('translate')('current_trip.jsNo_upcoming_trips'),
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
                console.log("获取定位失败,错误:" + error);
                $scope.currentTrip.stateString = $filter('translate')('current_trip.jsNo_trip');
                $scope.currentTrip.buttonState = "";
                $scope.currentTrip.duration = "";
                $scope.finalAddress = ['',''];
                $scope.bookingTrip = undefined;
              });
            }
          }, function (errorString, response) {
            $ionicLoading.hide();
            if (!LoginService.logoutWhenAuthExpired(response.code)) {
              if (errorString) {
                $ionicPopup.alert({
                  title: errorString,
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
              } else {
                $ionicPopup.alert({
                  title: $filter('translate')('current_trip.jsNo_upcoming_trips'),
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
              }
            }
          })
        }

        function initTripStateWithLatlng(latlng) {
          if (TripService.currentTrip.exeCompanyId != TripService.currentTrip.ownCompanyId) {
            $scope.companyRemind = $filter('translate')('current_trip.jsPassenger_from', {name: TripService.currentTrip.ownCompanyName});
          } else {
            $scope.companyRemind = '';
          }

          map.setCenter(latlng);
          if (TripService.currentTrip.tripState == 0) {
            var startLatlng = new google.maps.LatLng(latlng);
            var endLatlng = new google.maps.LatLng({
              lat: TripService.currentTrip.d_lat,
              lng: TripService.currentTrip.d_lng
            });
            MapService.calculateAndDisplayRoute(map, directionsService, directionsDisplay, startLatlng, endLatlng);
          } else if (TripService.currentTrip.tripState == 1) {
            startTrip();
            var startLatlng = new google.maps.LatLng(latlng);
            var endLatlng = new google.maps.LatLng({
              lat: TripService.currentTrip.d_lat,
              lng: TripService.currentTrip.d_lng
            });
            MapService.calculateAndDisplayRoute(map, directionsService, directionsDisplay, startLatlng, endLatlng);
          } else if (TripService.currentTrip.tripState == 2) {
            startTrip();
          } else if (TripService.currentTrip.tripState == 3) {
            startTrip();
            if (TripService.currentTrip.type == 1) {
              var startLatlng = new google.maps.LatLng({
                lat: TripService.currentTrip.d_lat,
                lng: TripService.currentTrip.d_lng
              });
              var endLatlng = new google.maps.LatLng({
                lat: TripService.currentTrip.a_lat,
                lng: TripService.currentTrip.a_lng
              });
              MapService.calculateAndDisplayRoute(map, directionsService, directionsDisplay, startLatlng, endLatlng);
            } else {
              //如果是Hourly,当状态为3时,把司机出发点到上车点的路线清掉
              directionsDisplay.setMap(null);
            }
          } else if (TripService.currentTrip.tripState == 4) {
            //提示选择差价
            if (TripService.currentTrip.spreads) {
              billTrip(TripService.currentTrip.bookingId, TripService.currentTrip.total_cost, TripService.currentTrip.total_cost + TripService.currentTrip.spreads,TripService.currentTrip.ccy);
            } else {
              endTrip();
            }
          } else {
            //直接end
            endTrip();
          }
        }

        var map;
        var directionsService = new google.maps.DirectionsService;
        var directionsDisplay = new google.maps.DirectionsRenderer;
        var driverMaker;
        var timeout;
        var savePointInterval = 3000;
        var uploadPointInterval = 30000;

        $scope.currentTrip = {};
        $scope.currentTrip.stateString = $filter('translate')('current_trip.jsNo_trip');
        $scope.bookingTrip = undefined;

        //init map
        function loadMap() {
          //TODO 待优化，以后应该动态加载地图中心点
          map = new google.maps.Map(document.getElementById('trip-map'), {
            center: {lat: 34.1017614, lng: -118.3450541},
            zoom: 12,
            mapTypeControl: false,
            disableDefaultUI: true
          });
          LocationService.getCurrentPosition(function (position) {
            map.setCenter({lat: position.coords.latitude, lng: position.coords.longitude});
          }, function (error) {
            console.log("loadMap获取定位失败,错误:" + error);
          });
        }

        //Fix Map
        function resizeMapFix() {
          angular.element($("#trip-map")).css("height", window.screen.availHeight - 230.0 + "px");
        }

        resizeMapFix();

        //add startMarker and pickupMaker
        function addMarker(latLng) {
          var marker = new google.maps.Marker({
            position: latLng,
            map: map
          });
          return marker;
        }

        //make LatLngBounds
        function makeLatLngBounds(latLngs) {
          var bounds = new google.maps.LatLngBounds();
          for (var i = 0; i < latLngs.length; i++) {
            var latLng = new google.maps.LatLng({
              lat: latLngs[i].lat,
              lng: latLngs[i].lng
            });
            bounds.extend(latLng);
          }
          return bounds;
        }

        //get trip state
        function getTripState() {
          if (!TripService.currentTrip) {
            return;
          }
          if (TripService.currentTrip.tripState == 0) {
            //ready to go
            $scope.currentTrip.stateString = $filter('translate')('current_trip.jsReady_to_go');
            $scope.currentTrip.buttonState = $filter('translate')('current_trip.jsStart_trip');
            $scope.currentTrip.duration =$filter('translate')('current_trip.jsAppointed_at') + " " + $filter('dateFormatter')(TripService.currentTrip.appointed_at * 1000, "shortTime");
            $scope.currentTrip.customerMobile = TripService.currentTrip.mobile;
          } else if (TripService.currentTrip.tripState == 1) {
            //already started
            $scope.currentTrip.stateString = $filter('translate')('current_trip.jsGo_to_pickup');
            $scope.currentTrip.buttonState = $filter('translate')('current_trip.jsArriving');
            $scope.currentTrip.duration = $filter('translate')('current_trip.jsAppointed_at') + " " + $filter('dateFormatter')(TripService.currentTrip.appointed_at * 1000, "shortTime");
            $scope.currentTrip.customerMobile = TripService.currentTrip.mobile;
          } else if (TripService.currentTrip.tripState == 2) {
            //arriving on pickup
            $scope.currentTrip.stateString = $filter('translate')('current_trip.jsArriving_on_pickup');
            $scope.currentTrip.buttonState = $filter('translate')('current_trip.jsPick_up');
            $scope.currentTrip.duration = $filter('translate')('current_trip.jsAppointed_at') + " " + $filter('dateFormatter')(TripService.currentTrip.appointed_at * 1000, "shortTime");
            $scope.currentTrip.customerMobile = TripService.currentTrip.mobile;
          } else if (TripService.currentTrip.tripState == 3) {
            //on trip
            $scope.currentTrip.stateString = $filter('translate')('current_trip.jsOn_trip');
            $scope.currentTrip.buttonState = $filter('translate')('current_trip.jsEnd_trip');
            $scope.currentTrip.customerMobile = TripService.currentTrip.mobile;
            if (TripService.currentTrip.type == 1) {
              LocationService.getCurrentPosition(function (position) {
                var startLatlng = new google.maps.LatLng({
                  lat: position.coords.latitude,
                  lng: position.coords.longitude
                });
                var endLatlng = new google.maps.LatLng({
                  lat: TripService.currentTrip.a_lat,
                  lng: TripService.currentTrip.a_lng
                });
                MapService.getMapMatrixDistance(startLatlng, endLatlng, function (result) {
                  var duration = result.duration;
                  //时间小于五分钟发送本地通知
                  if (duration < 300) {
                    var close_arrival = $filter('translate')('current_trip.jsClose_arrival');
                    var finish_order = $filter('translate')('current_trip.jsFinish_order');
                    LocalNotificationService.sendNotification(TripService.currentTrip.bookingId, close_arrival, finish_order);
                  }

                  var nowDate = new Date();
                  var etaDate = new Date(nowDate.getTime() + duration * 1000);
                  $scope.currentTrip.duration = $filter('translate')('current_trip.jsArrival_eta', {etaDate: $filter('dateFormatter')(etaDate, "shortTime"), duration: JSON.stringify(Math.round(duration / 60))});
                }, function (error) {
                  //nothing to do...
                });
              }, function (error) {
                //nothing to do...
                console.log('getTripState获取定位失败,错误:' + error);
              });
            } else {
              var duration;
              if (TripService.realStartTripTime) {
                var nowDate = new Date();
                duration = parseInt(nowDate.getTime() / 1000) - TripService.realStartTripTime;
              } else {
                duration = 0;
              }
              $scope.currentTrip.duration = $filter('translate')('current_trip.jsLast_duration', {duration: JSON.stringify(Math.round(duration / 60))});
              console.log('trip time is ' + TripService.currentTrip.estimate_time + " and duration time is " + duration);
              if (TripService.currentTrip.estimate_time * 60 - duration < 300) {
                var time_coming = $filter('translate')('current_trip.jsTime_coming');
                var finish_the_order = $filter('translate')('current_trip.jsFinish_order');
                LocalNotificationService.sendNotification(TripService.currentTrip.bookingId, time_coming, finish_the_order);
              }
            }
          } else if (TripService.currentTrip.tripState == 4) {
            //end trip
            $scope.currentTrip.stateString = $filter('translate')('current_trip.jsEnd');
            $scope.currentTrip.buttonState = $filter('translate')('current_trip.jsEnd_trip');
            var now = new Date();
            $scope.currentTrip.duration = $filter('translate')('current_trip.jsArrived') + " " + $filter('dateFormatter')(now.getTime(), "shortTime");
            $scope.currentTrip.customerMobile = TripService.currentTrip.mobile;
          } else {
            $scope.currentTrip.stateString = $filter('translate')('current_trip.jsEnd');
            $scope.currentTrip.buttonState = $filter('translate')('current_trip.jsEnd_trip');
            $scope.currentTrip.customerMobile = TripService.currentTrip.mobile;
          }
        }

        function getTripAddress() {
          if (!TripService.currentTrip) {
            return;
          }
          if (TripService.currentTrip.tripState == 0) {
            //ready to go
            $scope.finalAddress = finalAddress(TripService.currentTrip.d_address);
          } else if (TripService.currentTrip.tripState > 0 && TripService.currentTrip.tripState < 4) {
            if (savePoints.length > 0) {
              var point = savePoints[savePoints.length - 1];
              MapService.geocodeLatLng({lat: point.lat, lng: point.lng}, function (address) {
                $scope.finalAddress = finalAddress(address);
                $scope.$apply();
              }, function (error) {
                console.log('getTripAddress地理编码失败,错误:' + error);
              });
            } else {
              LocationService.getCurrentPosition(function (position) {
                var latlng = {lat: position.coords.latitude, lng: position.coords.longitude};
                MapService.geocodeLatLng(latlng, function (address) {
                  $scope.finalAddress = finalAddress(address);
                  $scope.$apply();
                }, function (error) {
                  $scope.finalAddress = ['',''];
                  console.log('getTripAddress地理编码失败,错误:' + error);
                })
              }, function (error) {
                $scope.finalAddress = ['',''];
                console.log('getTripAddress获取定位失败,错误:' + error);
              });
            }
          } else {
            $scope.finalAddress = ['',''];
          }
        }

        function startTrip() {
          TripService.isTripping = true;
          if ($ionicPlatform.is('android')) {
          } else {
            if (window.cordova) {
              cordova.plugins.backgroundMode.start();
            }
          }
          saveAndShowPonits();
        }

        var savePoints = [];
        var saveTime = 0;
        //保存并显示司机点位
        function saveAndShowPonits() {
          if (timeout) {
            $timeout.cancel(timeout);
          } else {
            //nothing to do
          }

          if (!TripService.currentTrip) {
            return;
          }

          if (TripService.currentTrip.tripState > 3) {
            return;
          }


          if (saveTime == uploadPointInterval / savePointInterval) {
            uploadPointsToServer();
            saveTime = 0;
          }
          saveTime++;

          timeout = $timeout(function () {
            var now = new Date();
            LocationService.getCurrentPosition(function (position) {
              if (!TripService.currentTrip) {
                return;
              }
              var point = {};
              point.tripState = TripService.currentTrip.tripState;
              point.uploadSuccess = false;
              point.pointed_at = parseInt(now.getTime() / 1000);
              point.lat = position.coords.latitude;
              point.lng = position.coords.longitude;
              point.address = '';
              point.distanceToPreviousPoint = 0;
              point.distance = 0;
              if (!position.coords.speed || position.coords.speed < 0) {
                point.speed = 0;
              } else {
                point.speed = position.coords.speed;
              }
              MapService.geocodeLatLng({lat: point.lat, lng: point.lng}, function (address) {
                point.address = JSON.stringify(address);
              }, function (error) {
                console.log('saveAndShowPonits时地理编码失败,错误: ' + error);
              });

              if (savePoints.length == 0 || TripService.currentTrip.tripState < 3) {
                //保存点位
                console.log("保存点位:{" + 'lat:' + point.lat + ',lng:' + point.lng + '}');
                savePoints.push(point);
                //显示点位
                if (driverMaker == undefined) {
                  driverMaker = addMarker({lat: point.lat, lng: point.lng});
                  driverMaker.setIcon('http://duanctest.sinaapp.com/a4c/image/car_blue.png');
                } else {
                  driverMaker.setPosition({lat: point.lat, lng: point.lng});
                }
                map.setCenter({lat: point.lat, lng: point.lng});
                //显示状态
                getTripState();
                getTripAddress();
                //继续执行
                saveAndShowPonits();
              } else {
                var lastPoint = savePoints[savePoints.length - 1];
                var lastLatlng = new google.maps.LatLng({lat: lastPoint.lat, lng: lastPoint.lng});
                var currentLatlng = new google.maps.LatLng({
                  lat: position.coords.latitude,
                  lng: position.coords.longitude
                });
                MapService.getMapDistanceWithWaypoints(lastLatlng, currentLatlng, [], function (result) {
                  //处理距离
                  if($scope.bookingTrip.unit == 1){
                    point.distanceToPreviousPoint = result / 1000 * 0.62;
                  }else{
                    point.distanceToPreviousPoint = result / 1000;
                  }
                  var distanceToPickup = point.distanceToPreviousPoint;
                  for (var i = 0; i < savePoints.length; i++) {
                    distanceToPickup = distanceToPickup + savePoints[i].distanceToPreviousPoint;
                  }
                  point.distance = distanceToPickup;

                  //保存点位
                  console.log("保存点位:{" + 'lat:' + point.lat + ',lng:' + point.lng + '}');
                  savePoints.push(point);
                  //显示点位
                  if (driverMaker == undefined) {
                    driverMaker = addMarker({lat: point.lat, lng: point.lng});
                    driverMaker.setIcon('http://duanctest.sinaapp.com/a4c/image/car_blue.png');
                  } else {
                    driverMaker.setPosition({lat: point.lat, lng: point.lng});
                  }
                  map.setCenter({lat: point.lat, lng: point.lng});
                  //显示状态
                  getTripState();
                  getTripAddress();
                  //计算trip里程
                  calculateTripDistance({lat: point.lat, lng: point.lng});
                  //继续执行
                  saveAndShowPonits();
                }, function (error) {
                  console.log('saveAndShowPonits时获取与上一点距离失败,错误: ' + error);
                  //继续执行
                  saveAndShowPonits();
                });
              }
            }, function (error) {
              console.log('saveAndShowPonits时获取定位失败,错误: ' + error);
              //继续执行
              saveAndShowPonits();
            });
          }, savePointInterval);
        }

        //上传点位
        function uploadPointsToServer() {
          var needUploadPoints = [];
          for (var i = 0; i < savePoints.length; i++) {
            var point = savePoints[i];
            if (!point.uploadSuccess) {
              needUploadPoints.push(point);
            }
          }
          var requestParams = {};
          requestParams.booking_id = TripService.currentTrip.bookingId;
          requestParams.locations = JSON.stringify(needUploadPoints);
          HttpService.post(Api.uploadDrvierLocation, requestParams, function (response) {
            if (response.result && response.result.start_time) {
              TripService.realStartTripTime = response.result.start_time;
            }
            for (var i = 0; i < savePoints.length; i++) {
              var point = savePoints[i];
              point.uploadSuccess = true;
            }
          }, function (errorString, response) {
            if (!LoginService.logoutWhenAuthExpired(response.code)) {
              if (response.code == 7001) {
                if (TripService.currentTrip.tripState < 4) {
                  endTrip(true);
                }
              } else {
                if (errorString) {
                  console.log('uploadPointsToServer失败,错误: ' + errorString);
                } else {
                  console.log('uploadPointsToServer失败,错误: 未知');
                }
              }
            }
          });
        }

        //计算trip里程
        var tripPointArray = [];
        var tripDistanceArray = [];

        function calculateTripDistance(currentLatlng) {
          var hasChange = false;
          if (tripPointArray.length < 10) {
            tripPointArray.push({location: currentLatlng, stopover: false});
          } else {
            var last = tripPointArray[9];
            tripPointArray = [last];
            tripPointArray.push({location: currentLatlng, stopover: false});
            hasChange = true;
          }

          var startLatlng = new google.maps.LatLng(tripPointArray[0].location);
          var endLatlng = new google.maps.LatLng(tripPointArray[tripPointArray.length - 1].location);
          var wayPoints = [];
          if (tripPointArray.length >= 3) {
            for (var i = 1; i < tripPointArray.length - 1; i++) {
              wayPoints.push(tripPointArray[i]);
            }
          }
          MapService.getMapDistanceWithWaypoints(startLatlng, endLatlng, wayPoints, function (result) {
            if (tripDistanceArray.length == 0) {
              tripDistanceArray.push(result / 1000 * 0.62);
            } else {
              if (hasChange) {
                tripDistanceArray.push(result / 1000 * 0.62);
              } else {
                tripDistanceArray[tripDistanceArray.length - 1] = result / 1000 * 0.62;
              }
            }
          }, function (error) {
            console.log('calculateTripDistance失败,错误:' + error);
          });

        }

        //改变trip状态
        function uploadTripToState(tostate) {
          $ionicLoading.show();
          var now = new Date();
          LocationService.getCurrentPosition(function (position) {
            var point = {};
            point.uploadSuccess = false;
            point.pointed_at = parseInt(now.getTime() / 1000);
            point.lat = position.coords.latitude;
            point.lng = position.coords.longitude;
            point.address = '';
            point.distanceToPreviousPoint = 0;
            point.distance = 0;
            if (!position.coords.speed || position.coords.speed < 0) {
              point.speed = 0;
            } else {
              point.speed = position.coords.speed;
            }
            MapService.geocodeLatLng({lat: point.lat, lng: point.lng}, function (address) {
              point.address = JSON.stringify(address);
            }, function (error) {
              console.log('uploadTripToState时地理编码失败,错误: ' + error);
            });

            var requestParams = {};
            requestParams.booking_id = TripService.currentTrip.bookingId;
            requestParams.lat = point.lat;
            requestParams.lng = point.lng;
            requestParams.address = point.address;
            requestParams.distance = point.distance;
            requestParams.state = tostate;

            if (tostate < 4) {
              HttpService.patch(Api.uploadTripState, requestParams, function (response) {
                $ionicLoading.hide();
                //保存点位
                point.tripState = tostate;
                point.uploadSuccess = true;
                console.log("保存点位:{" + 'lat:' + point.lat + ',lng:' + point.lng + '}');
                savePoints.push(point);

                //显示点位
                if (driverMaker == undefined) {
                  driverMaker = addMarker({lat: point.lat, lng: point.lng});
                  driverMaker.setIcon('http://duanctest.sinaapp.com/a4c/image/car_blue.png');
                } else {
                  driverMaker.setPosition({lat: point.lat, lng: point.lng});
                }
                map.setCenter({lat: point.lat, lng: point.lng});

                //其他设置
                TripService.currentTrip.tripState = tostate;
                if (tostate == 1) {
                  startTrip();
                }
                //开始Trip
                if (tostate == 3) {
                  if (TripService.currentTrip.type == 1) {
                    //如果是p2p,画出上车点到终点的线路图
                    var pickUp = new google.maps.LatLng({
                      lat: TripService.currentTrip.d_lat,
                      lng: TripService.currentTrip.d_lng
                    });
                    var dropOff = new google.maps.LatLng({
                      lat: TripService.currentTrip.a_lat,
                      lng: TripService.currentTrip.a_lng
                    });
                    MapService.calculateAndDisplayRoute(map, directionsService, directionsDisplay, pickUp, dropOff);
                  } else {
                    //如果是hourly,删除司机出发点到上车点的线路图
                    directionsDisplay.setMap(null);
                  }
                }
                getTripState();
                getTripAddress();
              }, function (errorString, response) {
                $ionicLoading.hide();
                if (!LoginService.logoutWhenAuthExpired(response.code)) {
                  if (response.code == 7002 && response.result && response.result.indexOf(":") > 0) {
                    var correctSate = parseInt(response.result.substring(response.result.indexOf(":") + 1, response.result.indexOf(":") + 2));
                    if (correctSate == tostate) {
                      //保存点位
                      point.tripState = tostate;
                      point.uploadSuccess = true;
                      console.log("保存点位:{" + 'lat:' + point.lat + ',lng:' + point.lng + '}');
                      savePoints.push(point);

                      //显示点位
                      if (driverMaker == undefined) {
                        driverMaker = addMarker({lat: point.lat, lng: point.lng});
                        driverMaker.setIcon('http://duanctest.sinaapp.com/a4c/image/car_blue.png');
                      } else {
                        driverMaker.setPosition({lat: point.lat, lng: point.lng});
                      }
                      map.setCenter({lat: point.lat, lng: point.lng});

                      //其他设置
                      TripService.currentTrip.tripState = tostate;
                      if (tostate == 1) {
                        startTrip();
                      }
                      //开始Trip
                      if (tostate == 3) {
                        if (TripService.currentTrip.type == 1) {
                          //如果是p2p,画出上车点到终点的线路图
                          var pickUp = new google.maps.LatLng({
                            lat: TripService.currentTrip.d_lat,
                            lng: TripService.currentTrip.d_lng
                          });
                          var dropOff = new google.maps.LatLng({
                            lat: TripService.currentTrip.a_lat,
                            lng: TripService.currentTrip.a_lng
                          });
                          MapService.calculateAndDisplayRoute(map, directionsService, directionsDisplay, pickUp, dropOff);
                        } else {
                          //如果是hourly,删除司机出发点到上车点的线路图
                          directionsDisplay.setMap(null);
                        }
                      }
                      getTripState();
                      getTripAddress();
                    } else {
                      //保存点位
                      point.tripState = correctSate;
                      point.uploadSuccess = true;
                      console.log("保存点位:{" + 'lat:' + point.lat + ',lng:' + point.lng + '}');
                      savePoints.push(point);

                      //其他设置
                      TripService.currentTrip.tripState = correctSate;

                      //开始Trip
                      if (tostate == 3) {
                        if (TripService.currentTrip.type == 1) {
                          //如果是p2p,画出上车点到终点的线路图
                          var pickUp = new google.maps.LatLng({
                            lat: TripService.currentTrip.d_lat,
                            lng: TripService.currentTrip.d_lng
                          });
                          var dropOff = new google.maps.LatLng({
                            lat: TripService.currentTrip.a_lat,
                            lng: TripService.currentTrip.a_lng
                          });
                          MapService.calculateAndDisplayRoute(map, directionsService, directionsDisplay, pickUp, dropOff);
                        } else {
                          //如果是hourly,删除司机出发点到上车点的线路图
                          directionsDisplay.setMap(null);
                        }
                      }

                      startTrip();
                    }
                  } else {
                    if (errorString) {
                      $ionicPopup.alert({
                        title: errorString,
                        okText: $filter('translate')('ionicPopup.jsOK')
                      });
                      console.log('uploadTripToState失败,错误: ' + errorString);
                    } else {
                      $ionicPopup.alert({
                        title: $filter('translate')('current_trip.jsNetwork_Time_Out'),
                        okText: $filter('translate')('ionicPopup.jsOK')
                      });
                      console.log('uploadTripToState失败,错误: 未知');
                    }
                  }
                }
              })
            } else {
              //结束
              var tripDistance = 0;
              for (var i = 0; i < tripDistanceArray.length; i++) {
                tripDistance = tripDistance + tripDistanceArray[i];
              }
              requestParams.distance = tripDistance;
              HttpService.patch(Api.uploadTripState, requestParams, function (response) {
                $ionicLoading.hide();
                TripService.currentTrip.tripState = response.result.trip_state;
                getTripState();
                getTripAddress();
                if (TripService.currentTrip.tripState > 4) {
                  //直接end
                  endTrip();
                } else {
                  //选择价钱
                  if (!response.result.spreads || response.result.spreads == 0) {
                    endTrip();
                  } else {
                    billTrip(TripService.currentTrip.bookingId, TripService.currentTrip.total_cost, TripService.currentTrip.total_cost + response.result.spreads,TripService.currentTrip.ccy);
                  }
                }
              }, function (errorString, response) {
                $ionicLoading.hide();
                if (!LoginService.logoutWhenAuthExpired(response.code)) {
                  if (response.code == 7002) {
                    var correctSate = response.result.substring(response.result.indexOf(":") + 1, response.result.indexOf(":") + 2);
                    if (correctSate == 4) {
                      //去找差价
                      var params = {};
                      params.start_time = TripService.currentTrip.appointed_at;
                      params.end_time = TripService.currentTrip.appointed_at + 24 * 60 * 60;
                      params.trip_state = correctSate;
                      HttpService.get(Api.bookRides, params, function (re) {
                        $ionicLoading.hide();
                        if (re.code == 2100) {
                          $ionicPopup.alert({
                            title: $filter('translate')('current_trip.jsNetwork_Time_Out'),
                            okText: $filter('translate')('ionicPopup.jsOK')
                          });
                          console.log('uploadTripToState失败后去找差价又失败了,错误: ' + error);
                        } else {
                          var spreads = undefined;
                          for (var i = 0; i < re.result.bookings.length; i++) {
                            if (re.result.bookings[i].id == TripService.currentTrip.bookingId) {
                              spreads = re.result.bookings[i].spreads;
                              break;
                            }
                          }
                          if (spreads) {
                            billTrip(TripService.currentTrip.bookingId, TripService.currentTrip.total_cost, TripService.currentTrip.total_cost + spreads,TripService.currentTrip.ccy);
                          } else {
                            $ionicPopup.alert({
                              title: $filter('translate')('current_trip.jsNetwork_Time_Out'),
                              okText: $filter('translate')('ionicPopup.jsOK')
                            });
                            console.log('uploadTripToState失败后去找差价,但是又没有找到对应的差价');
                          }
                        }
                      }, function (errorString, response) {
                        $ionicLoading.hide();
                        if (!LoginService.logoutWhenAuthExpired(response.code)) {
                          $ionicPopup.alert({
                            title: $filter('translate')('current_trip.jsNetwork_Time_Out'),
                            okText: $filter('translate')('ionicPopup.jsOK')
                          });
                          if (errorString) {
                            console.log('uploadTripToState失败后去找差价又失败了,错误: ' + errorString);
                          } else {
                            console.log('uploadTripToState失败后去找差价又失败了,错误: 未知');
                          }
                        }
                      })
                    } else {
                      //直接endtrip
                      $ionicLoading.hide();
                      endTrip();
                    }
                  } else {
                    if (errorString) {
                      $ionicPopup.alert({
                        title: errorString,
                        okText: $filter('translate')('ionicPopup.jsOK')
                      });
                      console.log('uploadTripToState失败,错误: ' + errorString);
                    } else {
                      $ionicPopup.alert({
                        title: $filter('translate')('current_trip.jsNetwork_Time_Out'),
                        okText: $filter('translate')('ionicPopup.jsOK')
                      });
                      console.log('uploadTripToState失败,错误: 未知');
                    }
                  }
                }
              })
            }
          }, function (error) {
            $ionicLoading.hide();
            $ionicPopup.alert({
              title: $filter('translate')('current_trip.jsSomething_wrong'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
            console.log('uploadTripToState时定位失败,错误: ' + error);
          });
        }

        $scope.onBookDetailButtonClick = function () {
          $ionicPopup.show({
            templateUrl: "templates/booking-detail-popup.html",
            title: $filter('translate')('current_trip.jsBook_detail'),
            scope: $scope,
            cssClass: "popstyle",
            buttons: [
              {
                text: $filter('translate')('current_trip.jsOk'),
                onTap: function () {
                }
              }
            ]
          })
        };

        $scope.changeTripState = function () {
          $ionicPopup.confirm({
            title: $filter('translate')('current_trip.jsSure'),
            okText: $filter('translate')('ionicPopup.jsOK'),
            cancelText:$filter('translate')('ionicPopup.jsCancel')
          }).then(function (res) {
            if (res) {
              uploadTripToState(TripService.currentTrip.tripState + 1);
            } else {
              //nothing to do...
            }
          });
        };

        $scope.backgroundModeChanged = function (isBackground) {
          if (isBackground) {
            console.log('TripCtrl' + "到后台了");
          } else {
            console.log('TripCtrl' + "到前台了");
          }
        };

        function endTrip(byAdmin) {
          directionsDisplay.setMap(null);
          loadMap();
          if (timeout) {
            $timeout.cancel(timeout);
          }
          LocalNotificationService.cancelNotification(TripService.currentTrip.bookingId);
          TripService.currentTrip = null;
          TripService.isTripping = false;
          savePoints = [];
          saveTime = 0;
          tripPointArray = [];
          tripDistanceArray = [];
          if (driverMaker) {
            driverMaker.setMap(null);
            driverMaker = undefined;
          }
          if ($ionicPlatform.is('android')) {
          } else {
            if (window.cordova) {
              cordova.plugins.backgroundMode.end();
            }
          }

          var title;
          if (byAdmin) {
            title = $filter('translate')('current_trip.jsAdmin_had_ended_trip')
          } else {
            title = $filter('translate')('current_trip.jsEnd_trip_success')
          }
          $ionicPopup.alert({
            title: title,
            template: $filter('translate')('current_trip.jsCheck_next'),
            okText: $filter('translate')('ionicPopup.jsOK')
          }).then(function (res) {
            if (res) {
              $scope.currentTrip.stateString = $filter('translate')('current_trip.jsNo_trip');
              $scope.currentTrip.buttonState = "";
              $scope.currentTrip.duration = "";
              $scope.finalAddress = ['',''];
              $scope.bookingTrip = undefined;

              loadTodayBookings();
            } else {
              //nothing to do
            }
          });
        }

        function billTrip(bookingId, originalPrice, currentPrice,ccy) {
          console.log(111)
          if ($scope.bookingTrip.hide_driver_fee == 0) {
            $ionicPopup.confirm({
              title: $filter('translate')('current_trip.jsCharge'),
              cssClass: 'trip-perpay-popup',
              buttons: [
                {
                  // text: $filter('translate')('current_trip.jsOriginal_price') + ' $' + Number(originalPrice).toFixed(2),
                  text: $filter('translate')('current_trip.jsOriginal_price') + $filter('princeTranslateFilters')(Number(originalPrice).toFixed(2),false,false,ccy) ,
                  onTap: function (e) {
                    $ionicLoading.show();
                    var url = ApiServer.serverUrl + ApiServer.version + '/bookings/' + bookingId + '/done';
                    var requestParams = {};
                    requestParams.active = 0;
                    HttpService.post(url, requestParams, function (response) {
                      $ionicLoading.hide();
                      endTrip();
                    }, function (errorString, response) {
                      $ionicLoading.hide();
                      if (!LoginService.logoutWhenAuthExpired(response.code)) {
                        endTrip();
                      }
                    });
                    console.log("select original price");
                  }
                },
                {
                  // text: $filter('translate')('current_trip.jsCurrent_price') + ' $' + Number(currentPrice).toFixed(2),
                  text: $filter('translate')('current_trip.jsCurrent_price') + $filter('princeTranslateFilters')(Number(currentPrice).toFixed(2),false,false,ccy) ,
                  onTap: function (e) {
                    $ionicLoading.show();
                    var url = ApiServer.serverUrl + ApiServer.version + '/bookings/' + bookingId + '/done';
                    var requestParams = {};
                    requestParams.active = 1;
                    HttpService.post(url, requestParams, function (response) {
                      $ionicLoading.hide();
                      endTrip();
                    }, function (errorString, response) {
                      $ionicLoading.hide();
                      if (!LoginService.logoutWhenAuthExpired(response.code)) {
                        endTrip();
                      }
                    });
                    console.log("select current price");
                  }
                }
              ]
            });
          } else {
            $ionicPopup.confirm({
              title: $filter('translate')('current_trip.jsCharge'),
              cssClass: 'trip-perpay-popup',
              buttons: [
                {
                  text: $filter('translate')('current_trip.jsOriginal_price'),
                  onTap: function (e) {
                    $ionicLoading.show();
                    var url = ApiServer.serverUrl + ApiServer.version + '/bookings/' + bookingId + '/done';
                    var requestParams = {};
                    requestParams.active = 0;
                    HttpService.post(url, requestParams, function (response) {
                      $ionicLoading.hide();
                      endTrip();
                    }, function (errorString, response) {
                      $ionicLoading.hide();
                      if (!LoginService.logoutWhenAuthExpired(response.code)) {
                        endTrip();
                      }
                    });
                    console.log("select original price");
                  }
                },
                {
                  text:  $filter('translate')('current_trip.jsCurrent_price'),
                  onTap: function (e) {
                    $ionicLoading.show();
                    var url = ApiServer.serverUrl + ApiServer.version + '/bookings/' + bookingId + '/done';
                    var requestParams = {};
                    requestParams.active = 1;
                    HttpService.post(url, requestParams, function (response) {
                      $ionicLoading.hide();
                      endTrip();
                    }, function (errorString, response) {
                      $ionicLoading.hide();
                      if (!LoginService.logoutWhenAuthExpired(response.code)) {
                        endTrip();
                      }
                    });
                    console.log("select current price");
                  }
                }
              ]
            });
          }
        }

        var contactPop;
        $scope.showContactPop = function () {
          contactPop = $ionicPopup.show({
            templateUrl: "templates/current-trip-contact-popup.html",
            title: "",
            scope: $scope,
            cssClass: "trip-contact-popup"
          })
        };

        $scope.closeContactPop = function () {
          contactPop.close();
        };

        $scope.sendSMS = function (type) {
          $scope.closeContactPop();
          var options = {
            replaceLineBreaks: false,
            android: {
              intent: 'INTENT'
            }
          };
          var message;
          if (type == 1) {
            message = $filter('translate')('current_trip.jsFive_min');
          } else if (type == 2) {
            message = $filter('translate')('current_trip.jsTen_min');
          } else {
            message = $filter('translate')('current_trip.jsDriver_arrived');
          }
          if (window.cordova) {
            $cordovaSms.send($scope.currentTrip.customerMobile + '', message, options)
              .then(function () {
                console.log('sms send success');
              }, function (error) {
                console.log(error);
              });
          }
        };

        function finalAddress(address) {
          var data = address.address_components;
          var finalAddressDate = [];

          //处理第一行
          //格式:'street_address route premise political'
          var line_1 = '';
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'street_number') {
              line_1 += data[i].long_name + '  ';
              break;
            }
          }
          var hasRoute = false;
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'route') {
              line_1 += data[i].long_name + ' ';
              hasRoute = true;
              break;
            }
          }

          if (!hasRoute) {
            for (var i = 0; i < data.length; i++) {
              if (data[i].types[0] == 'street_address') {
                line_1 += data[i].long_name + ' ';
                break;
              }
            }
          }

          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'premise') {
              line_1 += data[i].long_name + ' ';
              break;
            }
          }
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'political') {
              line_1 += data[i].long_name + ' ';
              break;
            }
          }
          finalAddressDate.push(line_1);

          //处理第二行
          //格式:'locality,administrative_area_level_1 postal_code'
          var line_2 = '';
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'locality') {
              line_2 += data[i].long_name;
              break;
            }
          }
          var hasState = false;
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'administrative_area_level_1') {
              line_2 += ',' + data[i].short_name;
              hasState = true;
              break;
            }
          }
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'postal_code') {
              if (hasState) {
                line_2 += ' ' + data[i].long_name;
              } else {
                line_2 += ',' + data[i].long_name;
              }
              break;
            }
          }
          finalAddressDate.push(line_2);
          return finalAddressDate;
        }
      });
})();
