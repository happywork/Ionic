/**
 * Created by wangyaunzhi on 16/11/16.
 */
ErrorCodeDictionary =
{
  6000:"username/email/mobile or password incorrect",
  3000:"Missing required parameter",
  3001:"Error required parameter",
  3002:"Can not find object",
  3806:"Event time has been used",

  3003:"Mobile has be used",
  3004:"Email has be used",
  3006:"You do not have access",
  3007:"Authentication expired, please sign in again",
  3102:"Email has be used",
  3101:"Mobile has be used",
  3100:"Username has be used",
  3301:"Driver not exist",
  3702:"Wrong Password",
  3703:"Password not changed",
  3800:"This offer can't provide services",
  3803:"This appoint time in the offer can't provide services",
  7009:"You have running trip,so can't start other trip",
  7200:"Can't change or end this trip because it has been started"
};

ErrorCode =
{
  getErrorMessage : function (code)  {
    return ErrorCodeDictionary[code];
  }
};
