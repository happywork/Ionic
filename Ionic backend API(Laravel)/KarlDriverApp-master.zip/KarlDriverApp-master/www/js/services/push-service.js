
(function () {
  'use strict';
  angular.module('starter')
    .service('PushService', function (HttpService, $localStorage) {
      var self = this;

      self.savePushToken = function (deviceToken) {
        $localStorage.pushToken = deviceToken;
        console.log($localStorage.pushToken + deviceToken);
      };

      self.tryUploadPushToken = function () {
        if ($localStorage.pushToken && $localStorage.user) {
          HttpService.post(Api.uploadPushToken + $localStorage.pushToken, {}, function () {
          }, function () {
          });
        }
      };
    });
})();
