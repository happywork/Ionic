(function () {
  'use strict';

  angular.module('passengerApp')
    .service('EasybookService', function ($q, UserService, $http, $ionicPopup, $state, HttpService, MapService) {
      //initiating Service inside here its self
      var self = this;
      

      self.getPickupLocation = function () {
        return this.pickupLocation;
      };

      self.savePickupLocation = function (location) {
        this.pickupLocation = location;
      };

      self.getDropoffLocation = function () {
        return this.dropoffLocation;
      };

      self.saveDropoffLocation = function (location) {
        this.dropoffLocation = location;
      };

      self.getCompanyDisclaimer = function (successHandler, faultHandler) {
        HttpService.get(Api.getCompanyDisclaimer, {}, function (response) {
          if (successHandler) {
            successHandler(response);
          }
        }, faultHandler);
      };

      //get Offers from remote
      self.getOffersFromRemote = function (requestParams, successHandle, faultHandle) {
        var appointed_time = requestParams.appointed_time;
        requestParams.appointed_time = Date.parse(requestParams.appointed_time) / 1000
        if (requestParams.type == 1) {
          //p2p
          HttpService.get(Api.getOffers, requestParams, function (response) {
            if (response.code == 2000) {
              delete self.returnBookingParam;
              self.bookingParam = {};
              self.returnServiceCache = {};
              self.bookingParam.type = 1;
              self.bookingParam.unit = 2;
              self.bookingParam.d_lng = requestParams.d_lng;
              self.bookingParam.d_lat = requestParams.d_lat;
              self.bookingParam.d_address = requestParams.d_address;
              self.bookingParam.a_lng = requestParams.a_lng;
              self.bookingParam.a_lat = requestParams.a_lat;
              self.bookingParam.a_address = requestParams.a_address;
              self.bookingParam.estimate_distance = requestParams.estimate_distance;
              self.bookingParam.estimate_duration = requestParams.estimate_duration;
              self.bookingParam.appointed_time = appointed_time;
              self.bookingParam.d_is_airport = requestParams.d_is_airport;
              // self.bookingParam.d_airline = requestParams.d_airline;
              self.bookingParam.d_airline = {name: requestParams.d_airline, icao: requestParams.d_fs};
              self.bookingParam.d_flight = requestParams.d_flight;
              self.bookingParam.a_is_airport = requestParams.a_is_airport;
              // self.bookingParam.a_airline = requestParams.a_airline;
              self.bookingParam.a_airline = {name: requestParams.a_airline, icao: requestParams.a_fs};
              self.bookingParam.a_flight = requestParams.a_flight;

              var directionsService = new google.maps.DirectionsService;
              var startPoint = {
                placeId: requestParams.a_address.place_id
              };
              var endPoint = {
                placeId: requestParams.d_address.place_id
              };

              MapService.calculateAndDisplayRoute(
                directionsService,
                startPoint,
                endPoint,
                appointed_time,
                function (res, status) {
                  console.log("result is ",res);
                  console.log("status is ",status);
                  if(res.status === "OK"){
                    var returnDistance = res.routes[0].legs[0].distance.value / 1000;
                    var returnDuration = res.routes[0].legs[0].duration.value / 60;
                    self.returnRequestParams = {};
                    self.returnRequestParams.type = 1;
                    self.returnRequestParams.unit = 2;
                    self.returnRequestParams.d_lat = requestParams.a_lat;
                    self.returnRequestParams.d_lng = requestParams.a_lng;
                    self.returnRequestParams.d_address = requestParams.a_address;
                    self.returnRequestParams.a_lat = requestParams.d_lat;
                    self.returnRequestParams.a_lng = requestParams.d_lng;
                    self.returnRequestParams.a_address = requestParams.d_address;
                    self.returnRequestParams.estimate_distance = returnDistance;
                    self.returnRequestParams.estimate_duration = returnDuration;
                    self.returnRequestParams.d_is_airport = requestParams.a_is_airport;
                    // returnRequestParams.d_airline = requestParams.a_airline;
                    // returnRequestParams.d_airline = {name:requestParams.a_airline,icao:requestParams.a_fs};
                    self.returnRequestParams.d_airline = {name: '', icao: ''};
                    // returnRequestParams.d_flight = requestParams.a_flight;
                    self.returnRequestParams.d_flight = '';
                    self.returnRequestParams.a_is_airport = requestParams.d_is_airport;
                    // returnRequestParams.a_airline = requestParams.d_airline;
                    // returnRequestParams.a_airline = {name:requestParams.d_airline,icao:requestParams.d_fs};
                    self.returnRequestParams.a_airline = {name: '', icao: ''};
                    // returnRequestParams.a_flight = requestParams.d_flight;
                    self.returnRequestParams.a_flight = '';

                    HttpService.get(Api.hasOffers, self.returnRequestParams, function (returnResponse) {
                      if (returnResponse.code == 2000) {
                        self.bookingParam.canReturn = true;
                      } else {
                        //2100
                        self.bookingParam.canReturn = false;
                      }
                      successHandle(response);
                    }, function () {
                      self.bookingParam.canReturn = false;
                      successHandle(response);
                    });
                  }else{
                    self.bookingParam.canReturn = false;
                    successHandle(response);
                  }
                });
            } else {
              //2100
              var user = UserService.getLoginUser();
              var string = 'Sorry we could not find any available vehicles for time or date you selected. Try modifying the time or date. Or call ' + user.company_name + ' at ' + user.company_phone1 + ' and we will be happy to help you.'
              faultHandle(string, response);
            }
          }, faultHandle);

        } else {
          //hourly
          HttpService.get(Api.getOffers, requestParams, function (response) {
            if (response.code == 2000) {
              if (successHandle) {
                successHandle(response);
              }
              delete self.returnBookingParam;
              self.bookingParam = {};
              self.bookingParam.type = 2;
              self.bookingParam.unit = 2;
              self.bookingParam.d_lng = requestParams.d_lng;
              self.bookingParam.d_lat = requestParams.d_lat;
              self.bookingParam.d_address = requestParams.d_address;
              self.bookingParam.estimate_duration = requestParams.estimate_duration;
              self.bookingParam.appointed_time = appointed_time;
              self.bookingParam.canReturn = false;
              self.bookingParam.d_is_airport = requestParams.d_is_airport;
              // self.bookingParam.d_airline = requestParams.d_airline;
              self.bookingParam.d_airline = {name: requestParams.d_airline, icao: requestParams.d_fs};
              self.bookingParam.d_flight = requestParams.d_flight;
            } else {
              //2100
              var user = UserService.getLoginUser();
              var string = 'Sorry we could not find any available vehicles for time or date you selected. Try modifying the time or date. Or call ' + user.company_name + ' at ' + user.company_phone1 + ' and we will be happy to help you.'
              faultHandle(string, response);
            }
          }, faultHandle);
        }
      };

      self.getReturnServiceOffersFromRemote = function (appointedTime, successHandle, faultHandle) {
        var directionsService = new google.maps.DirectionsService;
        self.returnRequestParams.appointed_time = Date.parse(appointedTime) / 1000;

        var startPoint = {
          placeId: self.returnRequestParams.d_address.place_id
        };
        var endPoint = {
          placeId: self.returnRequestParams.a_address.place_id
        };

        MapService.calculateAndDisplayRoute(
          directionsService,
          startPoint,
          endPoint,
          self.returnRequestParams.appointed_time,
          function (res, status) {
            if(status === google.maps.DirectionsStatus.OK ){
              var returnDistance = res.routes[0].legs[0].distance.value / 1000;
              var returnDuration = res.routes[0].legs[0].duration.value / 60;
              self.returnRequestParams.estimate_distance = returnDistance;
              self.returnRequestParams.estimate_duration = returnDuration;
              self.tempReturnDistance = returnDistance;
              self.tempReturnDuration = returnDuration;
              self.tempReturnAppointedTime = appointedTime;
              console.log("param is ",self.returnRequestParams);
              HttpService.get(Api.getOffers, self.returnRequestParams, function (response) {
                if (response.code == 2000) {
                  successHandle(response);
                } else {
                  //2100
                  var user = UserService.getLoginUser();
                  var string = 'Sorry we could not find any available vehicles for time or date you selected. Try modifying the time or date. Or call ' + user.company_name + ' at ' + user.company_phone1 + ' and we will be happy to help you.'
                  faultHandle(string, response);
                }
              }, faultHandle);
            }else{
              faultHandle(null, {code: ''});
            }
          });
      };

      self.enableReturnBookingParam = function () {
        if (!self.returnBookingParam) {
          self.returnBookingParam = {};
          self.returnBookingParam.type = 1;
          self.returnBookingParam.unit = 2;
          self.returnBookingParam.d_lng = self.bookingParam.a_lng;
          self.returnBookingParam.d_lat = self.bookingParam.a_lat;
          self.returnBookingParam.d_address = self.bookingParam.a_address;
          self.returnBookingParam.a_lng = self.bookingParam.d_lng;
          self.returnBookingParam.a_lat = self.bookingParam.d_lat;
          self.returnBookingParam.a_address = self.bookingParam.d_address;
          self.returnBookingParam.estimate_distance = self.tempReturnDistance;
          self.returnBookingParam.estimate_duration = self.tempReturnDuration;
          self.returnBookingParam.d_is_airport = self.bookingParam.a_is_airport;
          // self.returnBookingParam.d_airline = self.bookingParam.a_airline;
          // self.returnBookingParam.d_airline = {name:self.bookingParam.a_airline,icao:self.bookingParam.a_fs};
          self.returnBookingParam.d_airline = {name: '', icao: ''};
          // self.returnBookingParam.d_flight = self.bookingParam.a_flight;
          self.returnBookingParam.d_flight = '';
          self.returnBookingParam.a_is_airport = self.bookingParam.d_is_airport;
          // self.returnBookingParam.a_airline = {name:self.bookingParam.d_airline,icao:self.bookingParam.d_fs};
          self.returnBookingParam.a_airline = {name: '', icao: ''};
          // self.returnBookingParam.a_flight = self.bookingParam.d_flight;
          self.returnBookingParam.a_flight = '';
        }
        self.returnBookingParam.unit = 2;
        self.returnBookingParam.enable = true;
        self.returnBookingParam.appointed_time = self.tempReturnAppointedTime;
      };

      self.saveBookingCar = function (car, isReturn) {
        if (isReturn) {
          self.returnBookingCar = car;
          self.returnBookingParam.car_id = car.car_id;
          self.returnBookingParam.offer_id = car.offer_id;
        } else {
          self.bookingCar = car;
          self.bookingParam.car_id = car.car_id;
          self.bookingParam.offer_id = car.offer_id;
        }
      };

      self.saveBookingOptions = function (options, isReturn) {
        if (isReturn) {
          self.returnBookingParam.options = options;
        } else {
          self.bookingParam.options = options;
        }
      };

      self.saveBookingCost = function (optionsTotalPrice, isReturn) {
        var price = Math.round(optionsTotalPrice * 100) / 100;
        ;
        if (price > 0 && price < 1) {
          price = 1;
        } else if (price < 0) {
          price = 0;
        }
        if (isReturn) {
          //四舍五入
          self.returnBookingParam.cost = price
        } else {
          //四舍五入
          self.bookingParam.cost = price
        }
      };

      self.saveShowPrice = function (showPrice, isReturn) {
        if (isReturn) {
          //四舍五入
          self.returnBookingParam.showPrice = Math.round(showPrice * 100) / 100;
        } else {
          //四舍五入
          self.bookingParam.showPrice = Math.round(showPrice * 100) / 100;
        }
      };

      self.saveBookingNote = function (note, isReturn) {
        if (isReturn) {
          self.returnBookingParam.note = note;
        } else {
          self.bookingParam.note = note;
        }
      };

      self.saveBookingPassengerCount = function (count, isReturn) {
        if (isReturn) {
          self.returnBookingParam.passenger_count = count;
        } else {
          self.bookingParam.passenger_count = count;
        }
      };

      self.saveBookingPassengers = function (passengers, isReturn) {
        var passengerNames = [];
        angular.forEach(passengers, function (passenger) {
          passengerNames.push(passenger.name);
        });
        if (isReturn) {
          self.returnBookingParam.passenger_names = passengerNames.join(',');
        } else {
          self.bookingParam.passenger_names = passengerNames.join(',');
        }
      };

      self.saveBookingBagCount = function (count, isReturn) {
        if (isReturn) {
          self.returnBookingParam.bag_count = count;
        } else {
          self.bookingParam.bag_count = count;
        }
      };

      self.saveBookingCouponCount = function (Count, isReturn) {
        if (isReturn) {
          self.returnBookingParam.coupon = Count;
        } else {
          self.bookingParam.coupon = Count;
        }
      };

      self.saveBookingCouponAmount = function (Count, isReturn) {
        if (isReturn) {
          self.returnBookingParam.amountOff = Count;
        } else {
          self.bookingParam.amountOff = Count;
        }
      };

      self.saveBookingCouponPercent = function (Count, isReturn) {
        if (isReturn) {
          self.returnBookingParam.percentOff = Count;
        } else {
          self.bookingParam.percentOff = Count;
        }
      };

      //booking
      self.booking = function (successHandle, faultHandle) {
        var requestParam = jQuery.extend(true, {}, self.bookingParam);
        requestParam.appointed_time = Date.parse(requestParam.appointed_time);

        var realTime = ((new Date(requestParam.appointed_time)).getYear() + 1900) + "-";

        var month = (new Date(requestParam.appointed_time)).getMonth() + 1 ;

        if(month < 10)
        {
            month = "0" + month;
        }

        realTime = realTime + month + "-";

        var day = (new Date(requestParam.appointed_time)).getDate();

        if(day < 10)
        {
            day = "0" + day;
        }

        realTime = realTime + day + " ";

        var hour = (new Date(requestParam.appointed_time)).getHours();

        if(hour < 10)
        {
            hour = "0" + hour;
        }

        realTime = realTime + hour + ":";

        var minute = (new Date(requestParam.appointed_time)).getMinutes();

        if(minute < 10)
        {
            minute = "0" + minute;
        }

        realTime = realTime + minute + ":00";

        requestParam.real_time = realTime;

        requestParam.appointed_time = requestParam.appointed_time / 1000;
        requestParam.d_address = JSON.stringify(requestParam.d_address);
        if (requestParam.type == 1) {
          requestParam.a_address = JSON.stringify(requestParam.a_address);
        }
        HttpService.post(Api.booking, requestParam, function (response) {
          if (self.returnBookingParam) {
            //请求return booking
            var returnRequestParam = jQuery.extend(true, {}, self.returnBookingParam);
            returnRequestParam.appointed_time = Date.parse(returnRequestParam.appointed_time) / 1000;
            returnRequestParam.card_token = requestParam.card_token;
            returnRequestParam.d_address = JSON.stringify(returnRequestParam.d_address);
            returnRequestParam.a_address = JSON.stringify(returnRequestParam.a_address);
            HttpService.post(Api.booking, returnRequestParam, function (returnResponse) {
              successHandle(response, true, returnResponse);
              self.bookingComplete();
            }, function (error) {
              successHandle(response, true);
              self.bookingComplete();
            });
          } else {
            successHandle(response, false);
            self.bookingComplete();
          }
        }, faultHandle);
      };

      //complete booking
      self.bookingComplete = function () {
        self.clearBookingData();
      };

      //clear booking
      self.clearBookingData = function () {
        delete self.pickupLocation;
        delete self.dropoffLocation;
        delete self.bookingParam;
        delete self.bookingCar;
        delete self.returnBookingParam;
        delete self.returnServiceCache;
        delete self.rebookingOffer;
        delete self.bookingOffer;
      };

      self.matchingAirlineCompany = function (searchString, searchList) {
        var data = angular.copy(searchList);
        if (data && searchString) {
          var tempSearch = [];
          angular.forEach(data, function (rate) {
            if (rate.name.toString().indexOf(searchString.toString()) > -1) {
              tempSearch.push(rate);
            }
          });
          return tempSearch;
        }
        return undefined;
      };

      self.matchingAirlineNumber = function (searchString, searchList) {
        var data = angular.copy(searchList);
        if (data && searchString) {
          var tempSearch = [];
          angular.forEach(data, function (rate) {
            if (rate.flightNumber.toString().indexOf(searchString.toString()) > -1) {
              tempSearch.push(rate);
            }
          });
          return tempSearch;
        }
        return undefined;
      };

      //Created by pham 3/22/2018
      self.make_dateTime_from_timeStamp = function(timeStamp) {

          var dateTime = (timeStamp.getYear() + 1900) + "-";

          var month = timeStamp.getMonth() + 1 ;

          if(month < 10)
          {
              month = "0" + month;
          }

          dateTime = dateTime + month + "-";

          var day = timeStamp.getDate();

          if(day < 10)
          {
              day = "0" + day;
          }

          dateTime = dateTime + day;

          return dateTime;
      }

      self.verifyCoupon = function (code, car_companyId, customer_id, successHandler, faultHandler) {
        
        var requestParam = jQuery.extend(true, {}, self.bookingParam);
        var timeStamp = requestParam.appointed_time;

        var appointedTime = self.make_dateTime_from_timeStamp(timeStamp);

        HttpService.get(Api.verifyCode + code, {car_companyId, appointedTime, customer_id}, successHandler, faultHandler);
      };

      self.saveBookingOffer = function (offer, isReturn) {
        if (isReturn) {
          self.rebookingOffer = offer;
        } else {
          self.bookingOffer = offer;
        }
      };

    });

})();
