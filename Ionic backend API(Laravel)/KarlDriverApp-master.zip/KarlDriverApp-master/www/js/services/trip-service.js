(function () {
  'use strict';
  angular.module('starter')
    .service('TripService', function () {
      var self = this;

      self.bookingParamForTrip = null;
      self.scope = null;
      self.realStartTripTime = null;
      self.isTripping = false;

      self.initTrip = function (booking) {
        var temp = {};
        temp.tripState = booking.trip_state;
        temp.appointed_at = booking.appointed_at;
        temp.d_address = booking.d_address;
        temp.d_lng = booking.d_lng;
        temp.d_lat = booking.d_lat;
        temp.type = booking.type;
        temp.d_airline = booking.d_airline;
        temp.d_flight = booking.d_flight;
        if (temp.type == 1) {
          temp.a_address = booking.a_address;
          temp.a_lng = booking.a_lng;
          temp.a_lat = booking.a_lat;
          temp.a_airline = booking.a_airline;
          temp.a_flight = booking.a_flight;
        }
        temp.estimate_time = booking.estimate_time;
        temp.avatar_url = booking.c_avatar_url;
        temp.total_cost = booking.total_cost;
        temp.spreads = booking.spreads;
        temp.option_cost = booking.option_cost;
        temp.option_data = booking.option_data;
        temp.car_data = booking.car_data;
        temp.first_name = booking.c_first_name;
        temp.last_name = booking.c_last_name;
        temp.gender = booking.c_gender;
        temp.mobile = booking.c_mobile;
        temp.bookingId = booking.id;
        temp.exeCompanyId = booking.exe_company_id;
        temp.ownCompanyId = booking.own_company_id;
        temp.ownCompanyName = booking.own_company_name;
        temp.passenger_count = booking.passenger_count;
        temp.passenger_names = booking.passenger_names;
        temp.bags_count = booking.bags_count;
        temp.message = booking.message;
        temp.unit = booking.unit;
        temp.hide_driver_fee = booking.hide_driver_fee;
        temp.ccy = booking.ccy;
        self.currentTrip = temp;
      };

      self.cleanTrip = function(){
        delete self.bookingParamForTrip;
        delete self.currentTrip;
        delete self.realStartTripTime;
        self.isTripping = false;
      };

      self.bindController = function(tripCtrlScope){
        self.tripCtrl = tripCtrlScope;
      };

      self.backgroundModeChanged = function(isBackground){
        if(self.tripCtrl){
          if(isBackground){
            self.tripCtrl.backgroundModeChanged(isBackground);
          }else {
            self.tripCtrl.backgroundModeChanged(isBackground);
          }
        }
      }
    });
})();
