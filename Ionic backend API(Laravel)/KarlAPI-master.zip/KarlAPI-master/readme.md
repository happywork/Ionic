# KARL API

This project is API backend for KARL. 

This project contains all APIs which using by Dashboard & Apps.

## About KARL

For more information, see http://www.karl.limo

## About API

This project is private property of KARL, which is technical support by Inov.tech, 
see http://www.inov.tech

This project is:
- Language: PHP;
- IDE: PHPStorm;
- Main Framework: Lumen.


## Contact

CTO of Inov.tech: heroalur@qq.com