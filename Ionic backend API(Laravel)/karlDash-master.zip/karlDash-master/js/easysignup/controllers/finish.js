/**
 * Created by Alur on 2017-12-10.
 */
angular.module('EasySignUp.Controllers')
    .controller('FinishCtrl', function ($log, $scope, $rootScope, $state, $uibModal, $location, $timeout, MessageBox, T) {

    });
