ApiServer = {
  serverUrl: "http://test.com",//本地
  // serverUrl: "http://localhost:9000",      //dev
  // serverUrl: "http://dev.api.karldash.com",     //test
  // serverUrl: "http://test.api.karldash.com",     //test
  // serverUrl: "https://api.karldash.com",        //pubulish
  version: "/1",
  companyId: "40",
  companyName:"Driver Generation",
  conciergeNumber:""//+14243260823 dion的电话
};
