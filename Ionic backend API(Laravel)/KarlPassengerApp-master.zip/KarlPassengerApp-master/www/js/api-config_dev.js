ApiServer = {
  serverUrl: "http://dev.api.karldash.com",
  version: "/1",
  companyId: "1",
  companyName:"VIMOLA"
};
