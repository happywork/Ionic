/**
 * Created by wangyaunzhi on 16/11/19.
 */
(function () {
  'use strict';
  angular.module('passengerApp')
    .service('ConciergeService', function () {
      var self = this;
      self.needConcierge = function () {
        if(ApiServer.conciergeNumber && ApiServer.conciergeNumber.length > 0){
          self.conciergeNumber = ApiServer.conciergeNumber;
            return true;
        }else {
            return false;
        }
      }
    });
})();
