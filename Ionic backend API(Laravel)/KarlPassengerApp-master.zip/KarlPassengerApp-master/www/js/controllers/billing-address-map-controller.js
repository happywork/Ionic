/**
 * Created by jian on 17-6-1.
 */
/**
 * Created by wangyuanzhi on 16/2/27.
 */
angular.module('passengerApp')
  .controller('billingAddressMapCtrl', function ($scope, $stateParams, $ionicHistory, StorageService,
                                         $ionicPlatform, $timeout,
                                         EasybookService, LocationService,UserService) {
    var selectLocationMap;
    var geocoder = new google.maps.Geocoder;
    var locateResult;
    var tempLocation;
    var addressObj = undefined;
    $scope.location = {};
    $scope.loadding = true;

    $scope.$on('$ionicView.beforeLeave', function () {
      $scope.$broadcast('CancelLocate');
    });

    $scope.initialize = function (latlng) {
      selectLocationMap = new google.maps.Map(document.getElementById('map_locate'), {
        zoom: 12,
        center: latlng,
        mapTypeControl: false
      });

      $('<div/>').addClass('centerMarker').appendTo(selectLocationMap.getDiv());

      $scope.initMapListener(selectLocationMap);
      $scope.geocodeAddress(selectLocationMap.getCenter());
    };

    $scope.initMapListener = function (map) {
      google.maps.event.addListener(map, 'center_changed', function () {
        $scope.geocodeAddress(map.getCenter());
      });
      google.maps.event.addListener(map, 'dragstart', function () {
        $timeout(function () {
          $scope.loadding = true;
          $scope.placeholder = "Loading locations...";
          $scope.location.address = "";
          angular.element($("#locateInputID")).val("");
          angular.element($("#locateInputID")).attr('placeholder', "Loading locations...");
        }, 0);
      });
    };

    $scope.locate = function (location) {
      selectLocationMap.setCenter({lat: location.latlng.lat, lng: location.latlng.lng}, 12);
      tempLocation = location;
      $scope.geocodeAddress(selectLocationMap.getCenter(),function (position) {
        $timeout(function () {
          if ($stateParams.locateType == LocateType.billing_address){
            UserService.setBillingAddress(position);
          }
          $scope.addLocationHistory(tempLocation);
          $ionicHistory.goBack();

        },0)
      });
    };

    $scope.geocodeAddress = function (latlng,succse) {
      console.log(latlng)
      geocoder.geocode({'location': latlng}, function (results, status) {
          if (status === google.maps.GeocoderStatus.OK || status === google.maps.GeocoderStatus.ZERO_RESULTS) {
            if (results[0]) {
              var isAirport = false;
              for(var i=0;i<results.length;i++){
                isAirport = $.inArray("airport",results[i].types) != -1;
                if(isAirport){
                  break;
                }
              }
              results[0].isAirport=isAirport;
              $timeout(function () {
                $scope.loadding = false;
                addressObj = results[0];
                $scope.location.address = results[0].formatted_address;
                angular.element($("#locateInputID")).val(results[0].formatted_address);
                locateResult = {
                  "lat": selectLocationMap.getCenter().lat(),
                  "lng": selectLocationMap.getCenter().lng(),
                  "address": results[0]
                };
                if(succse){
                  succse(addressObj)
                }
              }, 0);
            } else {
              // nothing to do
            }
          } else {
            console.log(google.maps.GeocoderStatus);
          }
        }
      );
    };

    $scope.done = function () {
      //save location to EasybookService
      if (locateResult) {
        if ($stateParams.locateType == 'pickup') {
          EasybookService.savePickupLocation(locateResult);
        } else if ($stateParams.locateType == 'dropoff') {
          EasybookService.saveDropoffLocation(locateResult);
        } else if ($stateParams.locateType == LocateType.billing_address){
          //...
          console.log(addressObj)
          UserService.setBillingAddress(addressObj);
        }

        $scope.addLocationHistory(tempLocation);
      }
      $ionicHistory.goBack();
    };

    $scope.locationPlaceholder = 'Loading locations...';
    $timeout(function () {
      angular.element($("#locateInputID")).css("width", window.screen.availWidth - 95.0 + "px");
      if ($ionicPlatform.is('android')) {
        angular.element($("#map_locate_background")).css("height", window.screen.availHeight - 64.0 + "px");
        angular.element($("#map_locate")).css("margin-top", 64.0 - window.screen.availHeight + "px");
        angular.element($("#map_locate")).css("height", window.screen.availHeight - 64.0 + "px");
      } else {
        angular.element($("#map_locate_background")).css("height", window.screen.availHeight - 44.0 + "px");
        angular.element($("#map_locate")).css("margin-top", 44.0 - window.screen.availHeight + "px");
        angular.element($("#map_locate")).css("height", window.screen.availHeight - 44.0 + "px");
        if (window.StatusBar) {
          angular.element($("#locateInputID")).css("top", 26.0 + "px");
        }
      }
    }, 0);

    LocationService.getCurrentPosition(function (position) {
      var latlng = {
        lat: position.coords.latitude,
        lng: position.coords.longitude
      };
      $scope.initialize(latlng);
    }, function (error) {
      //洛杉矶
      var latlng = {
        lat: 34.1017614,
        lng: -118.3450541
      };
      //海景国际
      // var latlng = {
      //   lat: 34.3185392,
      //   lng: 108.93369050000001
      // };
      $scope.initialize(latlng);
      console.log('Locate fault!!!!');
    });

    //最多只保留5个
    $scope.addLocationHistory = function (location) {
      if (!location) {
        return;
      }
      var locations;
      var locationHistories = StorageService.getLocationHistories();
      if (!locationHistories || locationHistories.length == 0) {
        locations = [];
      } else {
        locations = locationHistories;
      }
      var find = false;
      for (var i = 0; i < locations.length; i++) {
        if (locations[i].place_id == location.place_id) {
          find = true;
          break;
        }
      }
      if (!find) {
        locations.unshift(location);
        if (locations.length > 5) {
          locations.splice(5, 1);
        }
        StorageService.setLocationHistories(locations);
      }
    };
  });
