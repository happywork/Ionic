// IIFE START //
(function () {
  'use strict';

  angular.module('passengerApp')
    .controller('ProfileCtrl',
      function ($scope, $http, $state, $ionicPopup, $cordovaCamera, UserService, HttpService, $cordovaFileTransfer,StorageService,
                $ionicActionSheet, $cordovaImagePicker, $ionicModal, $ionicLoading, $ionicPlatform, $ionicHistory, $timeout,LoginService,$filter,$translate,$ionicPickerI18n) {

        $scope.profileForm = {};
        $scope.showMask = true;

        $scope.$on('$ionicView.beforeEnter', function () {
          $scope.localLang=localStorage.getItem('lang');
          $scope.isFormDirty = $scope.profileForm.$dirty;
          $scope.showMask = true;
          $timeout(function () {
            $scope.showMask = false;
          }, 500);
        });

        $scope.$on('SideMenuProfileDidClick', function () {
          $scope.showMask = true;
          $timeout(function () {
            $scope.showMask = false;
          }, 500);
        });

        $scope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
          $scope.isFormDirty = $scope.profileForm.$dirty;
          if ($scope.isFormDirty) {
            event.preventDefault();

            var saveChangesPopup = $ionicPopup.confirm({
              title: $filter('translate')('profile.jsProfile_not_saved'),
              template: $filter('translate')('profile.jsContinue_without_saving'),
              buttons: [{
                text: $filter('translate')('profile.jsGO_BACK'),
                onTap: function (e) {
                  return false;
                }
              }, {
                text: $filter('translate')('profile.jsCONTINUE'),
                onTap: function (e) {
                  return true;
                }
              },]
            });

            saveChangesPopup.then(function (res) {
              if (res) {
                $scope.profileForm.$dirty = false;
                $state.go(toState);
              } else {
                return true;
              }
            });
          }
        });
        console.log(UserService.getLoginUser());
        $scope.country=StorageService.getCompanyInfo().country;
        $scope.avatar_url = UserService.getLoginUser().avatar_url;
        $scope.updateProfileInfo = {};
        $scope.updateProfileInfo.pwd = UserService.getLoginUser().loginPwd;
        $scope.updateProfileInfo.passwordVerify = UserService.getLoginUser().loginPwd;
        $scope.updateProfileInfo.first_name = UserService.getLoginUser().first_name;
        $scope.updateProfileInfo.last_name = UserService.getLoginUser().last_name;
        $scope.updateProfileInfo.mobile = $filter('phoneNumFormatter')(UserService.getLoginUser().mobile, $scope.country);
        $scope.updateProfileInfo.email = UserService.getLoginUser().email;
        $scope.updateProfileInfo.gender = UserService.getLoginUser().gender;
        $scope.updateProfileInfo.timemode = UserService.getLoginUser().timemode;
        $scope.updateProfileInfo.lang =localStorage.getItem('lang');
        $scope.changedPhoto = false;
        $scope.selectLang=$scope.updateProfileInfo.lang=='en'?'ENG':'FRE';
        $scope.timeModeText = $scope.updateProfileInfo.timemode == 0 ? '24 Hr':'12 Hr';

        if ($scope.updateProfileInfo.gender == 1) {
          $scope.updateProfileInfo.genderString =  $filter('translate')('profile.jsMrs');
        } else {
          $scope.updateProfileInfo.genderString = $filter('translate')('profile.jsMr');
        }

        $scope.selectTimeMode = function() {
          var hideSheet = $ionicActionSheet.show({
            titleText: "Time Mode",
            buttons: [{
              text: "24 Hr"
            }, {
              text: "12 Hr"
            }],
            cancelText: $filter('translate')('signup.jsCancel'),
            cancel: function() {
              console.log('photo upload cancelled');
            },
            buttonClicked: function(index) {
              if (index === 0) {
                $scope.updateProfileInfo.timemode = 0;

                $scope.timeModeText = "24 Hr";
                return true;

              }else if (index === 1) {
                $scope.updateProfileInfo.timemode = 1;

                $scope.timeModeText = "12 Hr";
                return true;
              }
            },
            destructiveButtonClicked: function() {
              return true;
            }

          });
        };
        // Show the action sheet
        $scope.addPhotoActionSheet = function () {
          var hideSheet = $ionicActionSheet.show({
            titleText: $filter('translate')('profile.jsAdd_photo'),
            buttons: [{
              text: $filter('translate')('profile.jsSelect_photo')
            }, {
              text: $filter('translate')('profile.jsTake_photo')
            }],
            cancelText: $filter('translate')('profile.jsCancel'),
            cancel: function () {
              console.log('photo upload cancelled');
            },
            buttonClicked: function (index) {
              if (index === 0) {
                $scope.pickPhoto();
                return true;

              } else if (index === 1) {
                $scope.addPicture();
                return true;
              }
            },
            destructiveButtonClicked: function () {
              return true;
            }

          });
        };

        ////////////////////////////////////
        //////////C A M E R A - P L U G I N
        ////////////////////////////////////
        //sourceType PHOTOLIBRAY . CAMERA
        $scope.addPicture = function () {
          var options = {
            quality: 50,
            destinationType: window.Camera.DestinationType.FILE_URI,
            sourceType: window.Camera.PictureSourceType.CAMERA, //window.PHOTOLIBRARY to test on emulator
            allowEdit: true,
            encodingType: window.Camera.EncodingType.JPEG,
            targetWidth: 240,
            popoverOptions: CameraPopoverOptions,
            saveToPhotoAlbum: true

          };
          $cordovaCamera.getPicture(options)
            .then(function (imageData) {
              console.log(imageData);
              $scope.avatar_url = imageData;
              $scope.changedPhoto = true;
            }, function (err) {
              console.error(err);
            });
        };

        ////////////////////////////////////////
        ////I M A G E - P I C K E R
        ////////////////////////////////////////
        ////http://ngcordova.com/docs/plugins/imagePicker/
        $scope.pickPhoto = function () {
          var options = {
            maximumImagesCount: 1,
            width: 240,
            height: 240,
            quality: 50
          };

          $cordovaImagePicker.getPictures(options).then(function (results) {
            if (results[0] && results[0].length > 0) {
              $scope.avatar_url = results[0];
              $scope.changedPhoto = true;
            } else {
              console.log('User not selecet any photo');
            }
          }, function (error) {
            console.log('Error: ' + JSON.stringify(error));
          });
        };

        ////////////////////////////////////////
        ////S A V E  P R O F I L E  CHANGES
        ////////////////////////////////////////
        $scope.updateProfile = function () {
          console.log($scope.updateProfileInfo)
          if (!$scope.updateProfileInfo.first_name) {
            $ionicLoading.show({
              template: $filter('translate')('profile.h5first_name_required'),
              duration:1200
            });
            return;
          }
          if($scope.updateProfileInfo.first_name.length>50){
            $ionicLoading.show({
              template: $filter('translate')('profile.h5first_name_too_long'),
              duration:1200
            });
            return;
          }
          if (!$scope.updateProfileInfo.last_name) {
            $ionicLoading.show({
              template: $filter('translate')('profile.h5last_name_required'),
              duration:1200
            });
            return;
          }
          if ($scope.updateProfileInfo.last_name.length>50) {
            $ionicLoading.show({
              template: $filter('translate')('profile.h5last_name_too_long'),
              duration:1200
            });
            return;
          }
          if (!$scope.updateProfileInfo.email) {
            $ionicLoading.show({
              template: $filter('translate')('profile.h5email_required'),
              duration:1200
            });
            return;
          }
          var reg = new RegExp("^[0-9a-z][_.0-9a-z-]{0,31}@([0-9a-z][0-9a-z-]{0,30}[0-9a-z]\.){1,4}[a-z]{2,4}$");
          if(!reg.test($scope.updateProfileInfo.email)){
            $ionicLoading.show({
              template: $filter('translate')('profile.h5enter_valid_email'),
              duration:1200
            });
            return;
          }
          if (!$scope.updateProfileInfo.pwd) {
            $ionicLoading.show({
              template: $filter('translate')('profile.h5password_required'),
              duration:1200
            });
            return;
          }
          if ($scope.updateProfileInfo.pwd.length<6) {
            $ionicLoading.show({
              template: $filter('translate')('profile.h5password_too_short'),
              duration:1200
            });
            return;
          }
          if ($scope.updateProfileInfo.pwd.length>16) {
            $ionicLoading.show({
              template: $filter('translate')('profile.h5password_too_long'),
              duration:1200
            });
            return;
          }
          if (!$scope.updateProfileInfo.passwordVerify) {
            $ionicLoading.show({
              template: $filter('translate')('profile.h5does_not_match'),
              duration:1200
            });
            return;
          }
          if ($scope.updateProfileInfo.pwd != $scope.updateProfileInfo.passwordVerify) {
            $ionicLoading.show({
              template: $filter('translate')('profile.jsMake_sure_password'),
              duration:1200
            });
            return;
          }
          if (!$scope.updateProfileInfo.mobile) {
            $ionicLoading.show({
              template: $filter('translate')('profile.h5enter_mobile_number'),
              duration:1200
            });
            return;
          }
          var tleReg = new RegExp("^[0-9]{5,18}$");
          if (!tleReg.test($scope.updateProfileInfo.mobile.replace(/ /g, ""))) {
            $ionicLoading.show({
              template: $filter('translate')('profile.h5enter_valid_digits'),
              duration:1200
            });
            return;
          }
          $scope.updateProfileInfo.lang=$scope.selectLang=='ENG'?'en':'fr';
          $ionicLoading.show({
            template: $filter('translate')('profile.jsUpdating_profile')
          });

          var profileInfo=angular.copy($scope.updateProfileInfo);
          profileInfo.mobile = profileInfo.mobile.replace(/\s/g, "");
          HttpService.patch(Api.profileUpdate, profileInfo, function (response) {
            $scope.isFormDirty = true;
            if ($scope.changedPhoto) {
              uploadPicture($scope.avatar_url, function (picResponse) {
                $ionicLoading.hide();
                $scope.changedPhoto = false;
                console.log(picResponse);
                var code = picResponse.code;
                var avatar = picResponse.result;
                console.log(code);
                console.log(avatar);
                if (code == 2000) {
                  UserService.setAvatar(avatar);
                }
                saveUserNewInfo(response.result);
                $scope.$emit('ProfileChanged');
                $ionicHistory.nextViewOptions({
                  historyRoot: true
                });
                if($scope.updateProfileInfo.lang!=$scope.localLang){
                  $state.go("multilingual");
                }else {
                  $state.go("app.easybook");
                }
                // $state.go("app.easybook");
              }, function (error) {
                $ionicLoading.hide();
                $scope.changedPhoto = false;
                saveUserNewInfo(response.result);
                $scope.$emit('ProfileChanged');
                $ionicHistory.nextViewOptions({
                  historyRoot: true
                });
                if($scope.updateProfileInfo.lang!=$scope.localLang){
                  $state.go("multilingual");
                }else {
                  $state.go("app.easybook");
                }
                // $state.go("app.easybook");
                console.log(error);
              });
            } else {
              $ionicLoading.hide();
              saveUserNewInfo(response.result);
              $scope.$emit('ProfileChanged');
              $ionicHistory.nextViewOptions({
                historyRoot: true
              });
              if($scope.updateProfileInfo.lang!=$scope.localLang){
                $state.go("multilingual");
              }else {
                $state.go("app.easybook");
              }

            }
          }, function (errorString,response) {
            $ionicLoading.hide();
            if(!LoginService.logoutWhenAuthExpired(response.code)){
              if(errorString){
                $ionicPopup.alert({
                  title: errorString,
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
              }else {
                $ionicPopup.alert({
                  title: $filter('translate')('profile.jsUpdate_fault'),
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
              }
            }
          });
        };

        //save info
        function saveUserNewInfo(info) {
          var loginUser = UserService.getLoginUser();
          loginUser.user_id = info.user_id;
          loginUser.first_name = info.first_name;
          loginUser.last_name = info.last_name;
          loginUser.mobile = info.mobile;
          loginUser.email = info.email;
          loginUser.address = info.address;
          loginUser.address_number = info.address_number;
          loginUser.address_code_postal = info.address_code_postal;
          loginUser.company_id = info.company_id;
          loginUser.company_name = info.company_name;
          loginUser.loginPwd = $scope.updateProfileInfo.pwd;
          loginUser.gender = info.gender;
          loginUser.lang = $scope.selectLang=='ENG'?'en':'fr';
          loginUser.timemode = $scope.updateProfileInfo.timemode;
          UserService.saveLoginUser(loginUser);
          console.log($scope.localLang)
          console.log(loginUser.lang)

          if($scope.localLang!=loginUser.lang){
            var lang;
            if($scope.selectLang=='ENG'){
              lang='en';
              $ionicPickerI18n.weekdays = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
              $ionicPickerI18n.months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            }else {
              lang='fr';
              $ionicPickerI18n.weekdays = ["Di", "Lu", "Ma", "Me", "Je", "Ve", "Sa"];
              $ionicPickerI18n.months = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
            }
            $translate.use(lang);
            moment.locale(lang);
            console.log('momentLang is ', moment.locale());
          }
          // localStorage.setItem('lang',lang)
        }

        //upload photo to server
        function uploadPicture(imageURI, successHandle, faultHandle) {
          var options = {
            fileKey: 'avatar',
            fileName: 'avatar.jpeg',
            httpMethod: 'POST',
            params: {
              token: UserService.getLoginUser().token,
              avatar: imageURI
            }
          };
          $cordovaFileTransfer.upload(Api.addAvatar, imageURI, options)
            .then(function (re) {
              var response = JSON.parse(re.response);
              successHandle(response);
            }, function (error) {
              faultHandle(error);
            })
        }

        //change gender
        $scope.showGenderActionSheet = function () {
          $ionicActionSheet.show({
            titleText: $filter('translate')('profile.jsSelect_gender'),
            buttons: [{
              text: $filter('translate')('profile.jsMrs')
            }, {
              text: $filter('translate')('profile.jsMr')
            }],
            cancelText:  $filter('translate')('profile.jsCancel'),
            cancel: function () {
            },
            buttonClicked: function (index) {
              if (index == 0) {
                $scope.updateProfileInfo.gender = 1;
                $scope.updateProfileInfo.genderString = $filter('translate')('profile.jsMrs');
              } else {
                $scope.updateProfileInfo.gender = 2;
                $scope.updateProfileInfo.genderString = $filter('translate')('profile.jsMr');
              }
              return true;
            },
            destructiveButtonClicked: function () {
              return true;
            }
          });
        };

        $scope.showCreditCards = function () {
          $state.go('app.card-list');
        };

        $scope.showMultilingualActionSheet = function () {
          $ionicActionSheet.show({
            titleText: $filter('translate')('profile.jsSelect_Language'),
            buttons: [{
              text: 'ENG'
            }, {
              text: 'FRE'
            }],
            cancelText:  $filter('translate')('profile.jsCancel'),
            cancel: function () {
            },
            buttonClicked: function (index) {
              if (index == 0) {
               $scope.selectLang='ENG'
              } else {
                $scope.selectLang='FRE'
              }
              return true;
            },
            destructiveButtonClicked: function () {
              return true;
            }
          });
        };

        $scope.formatPhone=function () {
          $scope.updateProfileInfo.mobile = $filter('phoneNumFormatter')($scope.updateProfileInfo.mobile, $scope.country);
          console.log($scope.updateProfileInfo.mobile);
        }
      });
})();
