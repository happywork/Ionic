// IIFE START //
(function () {
  'use strict';

  angular.module('passengerApp')
    .controller("RidesCtrl", function ($scope, $timeout, $ionicLoading, $ionicPopup, $ionicScrollDelegate, RidesService, HttpService, LoginService, UserService,$filter) {
      $scope.$on('$ionicView.enter', function () {
        $scope.isShowPast = false;
        $scope.refreshRidesData();
      });
      var User = UserService.getLoginUser();
      //show past list
      console.log("start load company info");
      var countryInfo = localStorage.getItem('companyInfo');
      console.log("company info ",countryInfo);
      $scope.country= countryInfo.country;
      $scope.showPastList = function () {
        $scope.isShowPast = true;
        if ($scope.pastRides.length == 0) {
          $scope.refreshRidesData();
        }
        $ionicScrollDelegate.$getByHandle('ridesScroll').scrollTop();
      };

      //show upcoming list
      $scope.showUpconmingList = function () {
        $scope.isShowPast = false;
        if ($scope.upcomingRides.length == 0) {
          $scope.refreshRidesData();
        }
        $ionicScrollDelegate.$getByHandle('ridesScroll').scrollTop();
      };

      //past rides data
      $scope.pastRides = [];
      $scope.pastRidesPage = 1;
      $scope.pastRidesHasMore = false;

      //upcomging rides data
      //upcomging rides does not need loadmore mode
      $scope.upcomingRides = [];

      //pull to refresh data
      //upcoming一次获取全部数据,past需要分页
      $scope.refreshRidesData = function () {
        var requestParames = {};
        var now = new Date();
        if ($scope.isShowPast) {
          //获取第1页
          requestParames.page = 1;
          //获取20条数据
          requestParames.per_page = 20;
          //过去到现在
          requestParames.start_time = 0;
          requestParames.end_time = parseInt(now.getTime() / 1000);
          //倒序
          requestParames.order_by = 1;
        } else {
          //现在到1年后
          requestParames.start_time = parseInt(now.getTime() / 1000);
          requestParames.end_time = parseInt(now.getTime() / 1000 + 365 * 24 * 60 * 60);
          //正序
          requestParames.order_by = 0;
        }
        $ionicLoading.show();
        RidesService.getRidesData(requestParames, function (response) {
          //end ui refresh
          $scope.$broadcast('scroll.refreshComplete');
          $ionicLoading.hide();

          //resolve data
          if (response.code == 2000) {
            if ($scope.isShowPast) {
              $scope.pastRides = response.result.bookings;
              if (response.result.bookings.length < 20) {
                $scope.pastRidesHasMore = false;
              } else {
                $scope.pastRidesHasMore = true;
                $scope.pastRidesPage = 2;
              }
            } else {
              $scope.upcomingRides = response.result.bookings;
              console.log($scope.upcomingRides);
              if ($scope.upcomingRides) {
                for (var i = 0; i < $scope.upcomingRides.length; i++) {
                  if ($scope.upcomingRides[i].a_address) {
                    if ($scope.upcomingRides[i].a_address.address_components) {
                      $scope.upcomingRides[i].a_address.final_address = finalAddress($scope.upcomingRides[i].a_address);
                      $scope.upcomingRides[i].d_address.final_address = finalAddress($scope.upcomingRides[i].d_address);
                    }
                  } else {
                    if ($scope.upcomingRides[i].d_address.address_components) {
                      $scope.upcomingRides[i].d_address.final_address = finalAddress($scope.upcomingRides[i].d_address);
                    }
                  }
                }
              }
            }
          } else {
            //2100
          }
        }, function (errorString, response) {
          //end ui refresh
          $scope.$broadcast('scroll.refreshComplete');
          $ionicLoading.hide();
          if (!LoginService.logoutWhenAuthExpired(response.code)) {
          }
        });
      };


      //load more past data
      $scope.loadMorePastRidesData = function () {
        var now = new Date();
        var requestParames = {
          "per_page": 20,
          "page": $scope.pastRidesPage,
          "order_by": 1,
          "start_time": 0,
          "end_time": parseInt(now.getTime() / 1000)
        };
        $ionicLoading.show({});
        RidesService.getRidesData(requestParames, function (response) {
          //end ui loadmore
          $scope.$broadcast('scroll.infiniteScrollComplete');
          $ionicLoading.hide();

          //resolve data
          var result = response.result;
          if (response.code == 2000) {
            Array.prototype.push.apply($scope.pastRides, result.bookings);
            if ($scope.pastRides) {
              for (var i = 0; i < $scope.pastRides.length; i++) {
                if ($scope.pastRides[i].a_address) {
                  if ($scope.pastRides[i].a_address.address_components) {
                    $scope.pastRides[i].a_address.final_address = finalAddress($scope.pastRides[i].a_address);
                    $scope.pastRides[i].d_address.final_address = finalAddress($scope.pastRides[i].d_address);
                  }
                } else {
                  if ($scope.pastRides[i].d_address.address_components) {
                    $scope.pastRides[i].d_address.final_address = finalAddress($scope.pastRides[i].d_address);
                  }
                }
              }
            }
            console.log($scope.pastRides);
            if (result.bookings.length < 20) {
              $scope.pastRidesHasMore = false;
            } else {
              $scope.pastRidesHasMore = true;
              $scope.pastRidesPage++;
            }
          } else {
            //2100
          }
        }, function (errorString, response) {
          //end ui loadmore
          $scope.$broadcast('scroll.infiniteScrollComplete');
          $ionicLoading.hide();
          if (!LoginService.logoutWhenAuthExpired(response.code)) {
          }
        });
      };

      $scope.pastRidesClick = function (index) {
        $scope.currentOrder = $scope.pastRides[index];
        if($scope.currentOrder.coupon == ''){
          $scope.showCoupon = false;
        }else {
          if($scope.currentOrder.coupon_off == 0){
            console.log('d');
            $scope.showCoupon = false;
          }else {
            $scope.showCoupon = true;
          }
        }

        if($scope.currentOrder.company_id != User.company_id){
          $scope.showCoupon = false;
        }

        if ($scope.currentOrder.d_address.address_components) {
          $scope.isLangAddress = false;
        } else {
          $scope.isLangAddress = true;
        }
        try {
          $scope.currentOrder.car_data = JSON.parse($scope.pastRides[index].car_data);
          $scope.currentOrder.driver_data = JSON.parse($scope.pastRides[index].driver_data);
        } catch (e) {

        }
        showPop();
      };

      $scope.upcomingRidesClick = function (index) {
        $scope.currentOrder = $scope.upcomingRides[index];
        if($scope.currentOrder.coupon == ''){
          $scope.showCoupon = false;
        }else {
          if($scope.currentOrder.coupon_off == 0){
            $scope.showCoupon = false;
          }else {
            $scope.showCoupon = true;
          }
        }

        if($scope.currentOrder.company_id != User.company_id){
          $scope.showCoupon = false;
        }

        if ($scope.currentOrder.d_address.address_components) {
          $scope.isLangAddress = false;
        } else {
          $scope.isLangAddress = true;
        }
        try {
          $scope.currentOrder.car_data = JSON.parse($scope.upcomingRides[index].car_data);
          $scope.currentOrder.driver_data = JSON.parse($scope.upcomingRides[index].driver_data);
        } catch (e) {
        }
        showPop();
      };

      var showPop = function () {
        $ionicPopup.show({
          templateUrl: "templates/current-trip-popup.html",
          title: $filter('translate')('rides.jsORDER'),
          scope: $scope,
          cssClass: "popstyle",
          buttons: [
            {
              text: $filter('translate')('rides.jsOk'),
              onTap: function () {
              }
            }
          ]
        })
      };

      $scope.emailInvoice = function () {
        $ionicLoading.show();
        var url = AppServer.serverUrl + AppVersion + '/customers/bookings/' + $scope.currentOrder.id + '/invoice';
        HttpService.get(url, {}, function (response) {
          $ionicLoading.hide();
          var myPop = $ionicPopup.show({
            title: $filter('translate')('rides.jsInvoice_send')
          });
          $timeout(function () {
            myPop.close();
          }, 1500);
        }, function (errorString, response) {
          $ionicLoading.hide();
          if (!LoginService.logoutWhenAuthExpired(response.code)) {
            if (errorString) {
              $ionicPopup.alert({
                title: errorString,
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            } else {
              $ionicPopup.alert({
                title: $filter('translate')('rides.jsRequest_clients_fault'),
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            }
          }
        });

      };

      function finalAddress(address) {
        var data = address.address_components;
        var finalAddressDate = [];

        //处理第一行
        //格式:'street_address route premise political'
        var line_1 = '';
        for (var i = 0; i < data.length; i++) {
          if (data[i].types[0] == 'street_number') {
            line_1 += data[i].long_name + '  ';
            break;
          }
        }
        var hasRoute = false;
        for (var i = 0; i < data.length; i++) {
          if (data[i].types[0] == 'route') {
            line_1 += data[i].long_name + ' ';
            hasRoute = true;
            break;
          }
        }

        if (!hasRoute) {
          for (var i = 0; i < data.length; i++) {
            if (data[i].types[0] == 'street_address') {
              line_1 += data[i].long_name + ' ';
              break;
            }
          }
        }

        for (var i = 0; i < data.length; i++) {
          if (data[i].types[0] == 'premise') {
            line_1 += data[i].long_name + ' ';
            break;
          }
        }
        for (var i = 0; i < data.length; i++) {
          if (data[i].types[0] == 'political') {
            line_1 += data[i].long_name + ' ';
            break;
          }
        }
        finalAddressDate.push(line_1);

        //处理第二行
        //格式:'locality,administrative_area_level_1 postal_code'
        var line_2 = '';
        for (var i = 0; i < data.length; i++) {
          if (data[i].types[0] == 'locality') {
            line_2 += data[i].long_name;
            break;
          }
        }
        var hasState = false;
        for (var i = 0; i < data.length; i++) {
          if (data[i].types[0] == 'administrative_area_level_1') {
            line_2 += ',' + data[i].short_name;
            hasState = true;
            break;
          }
        }
        for (var i = 0; i < data.length; i++) {
          if (data[i].types[0] == 'postal_code') {
            if (hasState) {
              line_2 += ' ' + data[i].long_name;
            } else {
              line_2 += ',' + data[i].long_name;
            }
            break;
          }
        }
        finalAddressDate.push(line_2);
        return finalAddressDate;
      }
    });
})();
