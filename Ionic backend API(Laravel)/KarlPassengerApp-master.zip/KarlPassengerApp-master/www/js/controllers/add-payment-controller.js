// IIFE START //
(function () {
  'use strict';
  angular.module('passengerApp')
    .controller('AddPaymentCtrl',
      function ($scope, HttpService, $state, $ionicPopup, $ionicLoading,
                $ionicHistory,LoginService,UserService,$filter) {

        window.ionic.Platform.ready(function () {
          if (window.cordova && window.cordova.plugins.Keyboard) {
            window.cordova.plugins.Keyboard.hideKeyboardAccessoryBar(false);
            if (window.ionic.Platform.isIOS()) {
              window.cordova.plugins.Keyboard.disableScroll(true);
            }
          }
        });

        $scope.$on("$ionicView.enter", function(event, data){
          // $scope.input.address = UserService.getBillingAddress();
          // console.log('address is ',$scope.input.address);
        });

        $scope.input = {};
        $scope.input.cardType = 1;

        $scope.form_addPayment_submit = function () {
          console.log($scope.input.cardNumber);
          console.log($scope.input.expireMonth);
          console.log($scope.input.expireYear);
          console.log($scope.input.cardCvv2);
          console.log($scope.input.firstName);
          console.log($scope.input.lastName);
          if ($scope.input.cardNumber == undefined || $scope.input.cardNumber == ""
            || $scope.input.expireMonth == undefined || $scope.input.expireMonth == ""
            || $scope.input.expireYear == undefined || $scope.input.expireYear == ""
            || $scope.input.cardCvv2 == undefined || $scope.input.cardCvv2 == ""
            || $scope.input.firstName == undefined || $scope.input.firstName == ""
            || $scope.input.lastName == undefined || $scope.input.lastName == ""
            // || $scope.input.zipCode == undefined || $scope.input.zipCode == ""
            // || $scope.input.address == undefined || $scope.input.address.formatted_address == undefined
            // || $scope.input.address.formatted_address == ''
          ) {
            $ionicPopup.alert({
              title: $filter('translate')('add_Payment.jsMissing_fields'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });

            console.log("dddd");
            return;
          }

          var cardNumberReg;
          var cvv2Reg;
          if($scope.input.cardType == 1){
            //VISA
            cardNumberReg = /^4\d{12}(?:\d{3})?$/g;
            cvv2Reg = /^[0-9]{3}$/g;
          }else if($scope.input.cardType == 2){
            //MasterCard
            cardNumberReg = /^5[1-5][0-9]{14}/g;
            cvv2Reg = /^[0-9]{3}$/g;
          }else if($scope.input.cardType == 3){
            //AmericanExpress
            cardNumberReg = /^3[47][0-9]{13}$/g;
            cvv2Reg = /^[0-9]{4}$/g;
          } else {
            //DISCOVER
            cardNumberReg = /^6(?:011|5[0-9]{2})[0-9]{12}$/g;
            cvv2Reg = /^[0-9]{3}$/g;
          }

          var number = ""+$scope.input.cardNumber;
          var numberResultArray = number.match(cardNumberReg);
          if(!numberResultArray || numberResultArray != number){
            $ionicPopup.alert({
              title: $filter('translate')('add_Payment.jsWrong_card'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
            return;
          }

          var cvv2 = $scope.input.cardCvv2.toString();
          var cvv2ResultArray = cvv2.match(cvv2Reg);
          if(!cvv2ResultArray || cvv2ResultArray != cvv2){
            $ionicPopup.alert({
              title: $filter('translate')('add_Payment.jsWrong_cvv2'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
            return;
          }

          var requestParams = {};
          requestParams.card_type = $scope.input.cardType;
          requestParams.card_number = $scope.input.cardNumber;
          requestParams.expire_month = $scope.input.expireMonth;
          requestParams.expire_year = $scope.input.expireYear;
          requestParams.cvv2 = $scope.input.cardCvv2;
          requestParams.first_name = $scope.input.firstName;
          requestParams.last_name = $scope.input.lastName;
          requestParams.zip = $scope.input.zipCode;
          // requestParams.address = JSON.stringify($scope.input.address);
          $ionicLoading.show();
          HttpService.post(Api.addCreditCard, requestParams, function (response) {
            $ionicLoading.hide();
            $ionicPopup.alert({
              title: $filter('translate')('add_Payment.jsSubmit_success'),
              okText: $filter('translate')('ionicPopup.jsOK')
            }).then(function (res) {
              if (res) {
                $ionicHistory.goBack();
              } else {
                //nothing to do...
              }
            });
          }, function (errorString,response) {
            $ionicLoading.hide();
            if(!LoginService.logoutWhenAuthExpired(response.code)){
              if(errorString) {
                $ionicPopup.alert({
                  title: errorString,
                  okText: $filter('translate')('ionicPopup.jsOK')
                });
              }else {
                if(response.code){
                  $ionicPopup.alert({
                    title: $filter('translate')('add_Payment.jsSubmit_fault'),
                    okText: $filter('translate')('ionicPopup.jsOK')
                  });
                }
              }
            }
          })
        };

        // $scope.selectLocation = function(){
        //   $state.go('app.billing-address-map', {"locateType": LocateType.billing_address});
        // };

        // $scope.$on("$ionicView.leave", function(event, data){
        //   // handle event
        //   UserService.clearBillingAddress();
        // });
      });
})();
