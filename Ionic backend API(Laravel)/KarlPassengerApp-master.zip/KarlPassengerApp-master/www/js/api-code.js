Api = {
  login: ApiServer.serverUrl + ApiServer.version + '/' + ApiServer.companyId +'/login',
  register: ApiServer.serverUrl + ApiServer.version + '/companies/' + ApiServer.companyId + '/customers/register',//register route added
  logout: ApiServer.serverUrl + ApiServer.version + '/logout',
  profileUpdate: ApiServer.serverUrl + ApiServer.version + '/customer',//user profile update route
  addAvatar: ApiServer.serverUrl + ApiServer.version + '/customers/avatar', //user add avatar photo
  getCarCategory: ApiServer.serverUrl + ApiServer.version + '/companies/' + ApiServer.companyId + '/cars/categories',
  getOffers: ApiServer.serverUrl + ApiServer.version + '/companies/' + ApiServer.companyId + '/offers/availability',
  booking: ApiServer.serverUrl + ApiServer.version + '/customers/bookings',
  bookRides: ApiServer.serverUrl + ApiServer.version + '/customers/bookings',
  getCompanyDetail: ApiServer.serverUrl + ApiServer.version + '/companies/' + ApiServer.companyId,
  getCompanyInfor: ApiServer.serverUrl + ApiServer.version + '/companies/'+ ApiServer.companyId + '/info',
  getOrderState: ApiServer.serverUrl + ApiServer.version + '/customers/orders/state',
  feedback: ApiServer.serverUrl + ApiServer.version + '/companies/orders/feedback',
  addCreditCard: ApiServer.serverUrl + ApiServer.version + '/customer/credit_cards',
  getCreditCards: ApiServer.serverUrl + ApiServer.version + '/customer/credit_cards',
  deleteCreditCards: ApiServer.serverUrl + ApiServer.version + '/customer/credit_cards',
  deleteCreditCard: ApiServer.serverUrl + ApiServer.version + '/customer/credit_cards/',
  uploadPushToken: ApiServer.serverUrl + ApiServer.version + '/users/device/',
  hasOffers:ApiServer.serverUrl + ApiServer.version + '/companies/' + ApiServer.companyId + '/has/offers',
  resetPassword: ApiServer.serverUrl + ApiServer.version + '/'+ApiServer.companyId+'/customer/template/password',
  getCompanyDisclaimer: ApiServer.serverUrl + ApiServer.version + '/companies/'+ ApiServer.companyId + '/disclaimer',
  getFlightsList: ApiServer.serverUrl + ApiServer.version + '/airline/flights/list',
  checkAppVersion: ApiServer.serverUrl +'/app/check/update/customer/' + ApiServer.companyId + '/',
  getAppUrl:ApiServer.serverUrl + '/app/company/' +ApiServer.companyId + '/',
  verifyCode : ApiServer.serverUrl + ApiServer.version+'/companies/' + ApiServer.companyId + '/coupon/'
};
