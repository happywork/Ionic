ApiServer = {
    serverUrl: "https://api.karldash.com",
    version: "/1",
    learnmoreUrl:"http://karl.limo",
    flowUrl:"http://karldash.com",
    timeout:30000,
    env:"pub",
    stripeClientId : 'ca_9P5hXLO2hpuwNjmk2hNwjN3IOfgT8Mhr',
    repSalesId: 'FRA02'

};
