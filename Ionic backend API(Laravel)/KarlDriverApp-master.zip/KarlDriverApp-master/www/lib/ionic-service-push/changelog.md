Changelog
=========

## 0.1.13

* Fixed a log typo telling people to set gcm_id instead of gcm_key

## 0.1.12

* Updated dependencies.

## 0.1.11

* Added support for auto-generated $ionicCoreSettings factory, will fall back to $ionicApp.get() if it can't find app ID and API key.
