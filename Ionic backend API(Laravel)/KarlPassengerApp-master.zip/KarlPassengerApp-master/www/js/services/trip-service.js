/**
 * Created by wangyuanzhi on 16/3/19.
 */
(function () {
  'use strict';
  angular.module('passengerApp')
    .service('TripService', function (HttpService) {
      var self = this;

      //当前trip的book
      self.trippingbook = null;

      //refresh order state
      self.refreshOrderState = function (bookingId, successHandle, faultHandle) {
        HttpService.get(Api.getOrderState, {"booking_id": bookingId}, successHandle, faultHandle);
      };

      //start trip
      self.startTrip = function () {
      };

      //end trip
      self.endTrip = function () {
        self.trippingbook = null;
      }
    });
})();
