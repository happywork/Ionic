// IIFE START //
(function () {
  'use strict';

  angular.module('starter')
    .controller('LoginCtrl',
      function ($scope, $ionicSideMenuDelegate, $state, $ionicPopup, $ionicLoading, LoginService, UserService, RegionService, ForgetPwdService,$filter,$timeout) {
        //不知道为啥,加上下面的代码,点击登录按钮,屏幕会刷一下,然后按钮就不能被点击了,所以先屏蔽掉
        // if (window.cordova && window.cordova.plugins.Keyboard) {
        //   window.ga.startTrackerWithId('UA-89070126-1');
        //   window.ga.trackView('Screen Title');
        // }

        RegionService.initialize();
        $ionicSideMenuDelegate.canDragContent(false);
        $scope.loginForm = {};

        function autoLogin() {
          var user = UserService.getLoginUser();
          if (user && user.loginAccount && user.loginPwd) {
            $scope.loginForm.Username = user.loginAccount;
            $scope.loginForm.Password = user.loginPwd;
            $ionicLoading.show({
              template: $filter('translate')('login.jsSigning_in')
            });
            LoginService.login(user.loginAccount, user.loginPwd, function () {
              $ionicLoading.hide();
              $state.go("app.bookings");
            }, function (errorString) {
              $ionicLoading.hide();
              $ionicPopup.alert({
                title: errorString,
                okText: $filter('translate')('ionicPopup.jsOK')
              });
            });
          }
        }

        autoLogin();

        $scope.startLogin = function () {
          var userName = $scope.loginForm.Username;
          var userPassword = $scope.loginForm.Password;
          if (!userName || !userPassword) {
            $ionicPopup.alert({
              title: $filter('translate')('login.jsMissing_fields'),
              okText: $filter('translate')('ionicPopup.jsOK')
            });
            return;
          }
          $ionicLoading.show({
            template: $filter('translate')('login.jsSigning_in')
          });
          LoginService.login(userName, userPassword, function () {
            $ionicLoading.hide();
            $state.go("app.bookings");
          }, function (errorString) {
            $ionicLoading.hide();
            $ionicPopup.alert({
              title: errorString,
              okText: $filter('translate')('ionicPopup.jsOK')
            });
          });
        };

        $scope.closeForgetPwdShow = function () {
          $scope.popup.close();
        };

        $scope.showForgetPwdDialog = function () {
          $scope.popup = $ionicPopup.show({
            cssClass: 'my-custom-popup',
            templateUrl: "templates/forget-password.html",
            scope: $scope
          });
        };

        $scope.param = {};
        $scope.commitEmail = function () {
          ForgetPwdService.resetPassword($scope.param.email,
            function () {
              $scope.popup.close();
              $scope.param.email = null;
            }, function (errorString, response) {
              if (!LoginService.logoutWhenAuthExpired(response.code)) {
                if (errorString) {
                  $ionicPopup.alert({
                    title: errorString,
                    okText: $filter('translate')('ionicPopup.jsOK')
                  })
                } else {
                  $ionicPopup.alert({
                    title: $filter('translate')('login.jsEmail_not_found'),
                    okText: $filter('translate')('ionicPopup.jsOK')
                  })
                }
              }
            });
        };

        $scope.showPasClick=function () {
          $scope.showPas=!$scope.showPas;
          $timeout(function () {
            var pass;
            pass = angular.element($('#pas'));
            if($scope.showPas){
              pass[0].type = 'text';
            }else {
              pass[0].type = 'password';
            }
            console.log(pass)
          })
        }
      });
})();
