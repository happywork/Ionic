/**
 * Created by wangyaunzhi on 16/11/16.
 */
ErrorCodeDictionary =
{
  6000:"username/email/mobile or password incorrect",
  3000:"Missing required parameter",
  3001:"Error required parameter",
  3002:"Can not find object",
  3806:"Event time has been used",

  3003:"This mobile has been used",
  3004:"This email has been used",
  3006:"You do not have access",
  3007:"Authentication expired, please sign in again",
  3100:"Username has be used",
  3101:"This mobile has been used",
  3102:"This email has been used",
  3301:"The passenger does not exist",
  3702:"Wrong Password",
  3703:"Password not changed",
  3800:"This offer can't provide services",
  3803:"This appoint time in the offer can't provide services",
  3808:"Sorry we could not find any available offers for time or date you selected. Try modifying the time or date. Or call company_name at company_phone and we will be happy to help you.",
  3809:"Sorry we could not find any available vehicles for time or date you selected. Try modifying the time or date. Or call company_name at company_phone and we will be happy to help you.",
  3810:"Sorry we could not find any available drivers for time or date you selected. Try modifying the time or date. Or call company_name at company_phone and we will be happy to help you.",
  7200:"Can't change or end this trip because it has been started",
  8801:"Pay Fault!"
};

ErrorCode =
{
  getErrorMessage : function (code)  {
    return ErrorCodeDictionary[code];
  }
};
