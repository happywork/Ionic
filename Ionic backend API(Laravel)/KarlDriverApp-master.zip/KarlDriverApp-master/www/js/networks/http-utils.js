var HttpUtils = {
  patch: function ($http, url, params, successHandler, errorHandler) {
    var timeout = 30000;
    if(url == Api.uploadTripState){
      timeout = 120000
    }
    $http.patch(url, HttpUtils.obj2params(params,url,'PATCH'),
      {
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        responseType: 'json',
        timeout: timeout
      }).then(successHandler, errorHandler);
  },
  post: function ($http, url, params, successHandler, faultHandler) {
    var timeout = 30000;
    $http({
        method: 'POST',
        url: url,
        data: HttpUtils.obj2params(params,url,'POST'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        responseType: 'json',
        timeout: timeout
      }
    ).then(successHandler, faultHandler);
  },
  get: function ($http, url, params, successHandler, faultHandler) {
    $http({
      method: 'GET',
      url: url + "?" + HttpUtils.obj2params(params,url,'GET'),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      responseType: 'json',
      timeout: 30000
    }).then(successHandler, faultHandler);
  },
  delete: function ($http, url, params, successHandler, errorHandler) {
    $http.delete(url + "?" + HttpUtils.obj2params(params,url,'DELETE'),
      { headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        responseType: 'json',
        timeout: 30000
      }).then(successHandler, errorHandler);
  },
  put: function ($http, url, params, successHandler, errorHandler) {
    $http.put(url, HttpUtils.obj2params(params,url,'PUT'),
      {
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        responseType: 'json',
        timeout: 30000
      }).then(successHandler, errorHandler);
  },

  obj2params: function (obj,url,method) {
    if(url == Api.driverUpdate) {
      var requestData = 'token='+obj.token+'&'+'param='+encodeURIComponent(JSON.stringify(obj));
      return requestData;
    } else {
      var p = [];
      for (var key in obj) {
        p.push(key + '=' + encodeURIComponent(obj[key]));
      }
      return p.join('&');
    }
  }
};
