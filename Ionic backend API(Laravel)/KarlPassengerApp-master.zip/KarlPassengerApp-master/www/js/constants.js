/**
 * Created by jian on 16-12-31.
 */
googleAnalytics = "UA-89070126-1";


LocateType = {
  start_locate: 0,
  drop_locate: 1,
  customer_locate: 2,
  billing_address: 3
};
var testAirList = {
  "code": 2000,
  "result": [{
    "fs": "HO",
    "iata": "HO",
    "icao": "DKH",
    "name": "Juneyao Airlines",
    "active": true,
    "flights": [{
      "carrierFsCode": "HO",
      "flightNumber": 1236,
      "departureAirportFsCode": "XIY",
      "arrivalAirportFsCode": "SHA",
      "stops": 0,
      "departureTerminal": 3,
      "arrivalTerminal": 2,
      "departureTime": "2017-03-12T07:30:00.000",
      "arrivalTime": "2017-03-12T09:50:00.000",
      "flightEquipmentIataCode": 320,
      "isCodeshare": false,
      "isWetlease": false,
      "serviceType": "J",
      "trafficRestrictions": [],
      "referenceCode": "57-3954523--"
    }]
  }, {
    "fs": "MU",
    "iata": "MU",
    "icao": "CES",
    "name": "China Eastern Airlines",
    "phoneNumber": "+86 21 95108",
    "active": true,
    "flights": [{
      "carrierFsCode": "MU",
      "flightNumber": 2141,
      "departureAirportFsCode": "XIY",
      "arrivalAirportFsCode": "DSN",
      "stops": 0,
      "departureTerminal": 3,
      "departureTime": "2017-03-12T10:05:00.000",
      "arrivalTime": "2017-03-12T11:30:00.000",
      "flightEquipmentIataCode": 320,
      "isCodeshare": false,
      "isWetlease": false,
      "serviceType": "J",
      "trafficRestrictions": [],
      "referenceCode": "57-3952994--"
    }, {
      "carrierFsCode": "MU",
      "flightNumber": 2125,
      "departureAirportFsCode": "XIY",
      "arrivalAirportFsCode": "WUH",
      "stops": 0,
      "departureTerminal": 3,
      "arrivalTerminal": 2,
      "departureTime": "2017-03-12T07:05:00.000",
      "arrivalTime": "2017-03-12T08:25:00.000",
      "flightEquipmentIataCode": 320,
      "isCodeshare": false,
      "isWetlease": false,
      "serviceType": "J",
      "trafficRestrictions": [],
      "referenceCode": "57-3955148--"
    }, {
      "carrierFsCode": "MU",
      "flightNumber": 2253,
      "departureAirportFsCode": "XIY",
      "arrivalAirportFsCode": "YNZ",
      "stops": 0,
      "departureTerminal": 3,
      "departureTime": "2017-03-12T07:50:00.000",
      "arrivalTime": "2017-03-12T10:00:00.000",
      "flightEquipmentIataCode": 320,
      "isCodeshare": false,
      "isWetlease": false,
      "serviceType": "J",
      "trafficRestrictions": [],
      "referenceCode": "57-3955404--"
    }]
  }]
};
