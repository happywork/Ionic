/**
 * Created by Alur on 2017-12-10.
 */

countryCurrency = [
    {id: 1, title: 'US | USD', country: 'US', currency: 'USD', language: 'en'},
    {id: 2, title: 'FR | EUR', country: 'FR', currency: 'EUR', language: 'fr'},
    {id: 3, title: 'UK | GBP', country: 'UK', currency: 'GBP', language: 'en'}
];

