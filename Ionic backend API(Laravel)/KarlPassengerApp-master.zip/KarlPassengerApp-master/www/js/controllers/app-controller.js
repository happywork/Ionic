(function () {
  "use strict";
  angular.module('passengerApp.AppController', [])
    .controller('AppCtrl', function ($scope, $ionicSideMenuDelegate, $ionicModal, $ionicPopup, $timeout, $state,
                                     $ionicPlatform, UserService, LoginService) {
      // With the new view caching in Ionic, Controllers are only called
      // when they are recreated or on app start, instead of every page change.
      // To listen for when this page is active (for example, to refresh data),
      // listen for the $ionicView.enter event:
      // $scope.$on('$ionicView.enter', function(e) {});
    })

    //sideMenuCtl holds logic for Side Menu links and functions..
    .controller('sideMenuCtrl', function ($scope, $state, $ionicPopup, $ionicSideMenuDelegate, $rootScope, UserService, ContactService, LoginService, ConciergeService,$filter) {
      $ionicSideMenuDelegate.canDragContent(true);
      $scope.loginUser = UserService.getLoginUser();
      $scope.isIPad = ionic.Platform.isIPad();
      $scope.logout = function () {
        $ionicPopup.confirm({
          title: $filter('translate')('menu.jsExit'),
          template: $filter('translate')('menu.jsLog_out_warning'),
          okText: $filter('translate')('ionicPopup.jsOK'),
          cancelText:$filter('translate')('ionicPopup.jsCancel')
        }).then(function (res) {
          if (res) {
            LoginService.logout();
            $state.go("login");
          } else {
            //nothing to do...
          }
        });
      };

      $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
        $rootScope.isFormDirty = false;
        if (window.cordova) {
          var event = ApiServer.companyName + ' Entry Page';
          window.mixpanel.track(event, {"pageName": toState.url}, function () {
            console.log('mixpanel track success');
          }, function () {
            console.log('mixpanel track fail');
          });

          if ($scope.loginUser.customer.customer_id) {
            var id = '' + $scope.loginUser.customer.customer_id;
            window.mixpanel.identify(id, function () {
              console.log('mixpanel identify success' + ' ' + id);
            }, function () {
              console.log('mixpanel identify fail' + ' ' + id);
            });
            window.mixpanel.people.set({
              'first_name': $scope.loginUser.first_name,
              'last_name': $scope.loginUser.last_name,
              'email': $scope.loginUser.email,
              'gender': ($scope.loginUser.gender == 2) ? 'female' : 'male'
            }, function () {
              console.log('mixpanel people set success');
            }, function () {
              console.log('mixpanel people set fail');
            });
          }
        }
      });

      $scope.backToContent = function () {
        $scope.$broadcast('SideMenuBackToContent');
      };

      $scope.enterProfile = function () {
        $scope.$broadcast('SideMenuProfileDidClick');
      };

      $scope.$on('ProfileChanged', function () {
        $scope.loginUser = UserService.getLoginUser();
      });

      $scope.needConcierge = ConciergeService.needConcierge();

      $scope.showConciergeMenu = function () {
        var confirmPopup = $ionicPopup.confirm({
          title: $filter('translate')('menu.jsPrivate_concierge'),
          template: $filter('translate')('menu.jsConcierge_info'),
          okText: $filter('translate')('ionicPopup.jsOK'),
          cancelText:$filter('translate')('ionicPopup.jsCancel')
        });
        confirmPopup.then(function (res) {
          confirmPopup.close();
          if (res) {
            ContactService.sendText(ConciergeService.conciergeNumber, "");
          }
        });
      }
    });

})();
